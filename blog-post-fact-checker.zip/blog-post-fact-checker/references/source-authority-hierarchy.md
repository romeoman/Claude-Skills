# Source Authority Hierarchy

## Overview

When fact-checking blog post claims, not all sources are created equal. This document defines the three-tier authority hierarchy used to evaluate source credibility.

**Key Principle:** Always trace claims to the **ORIGINAL authoritative source** rather than secondary sources citing them.

---

## Tier 1 Sources (ALWAYS ACCEPTABLE)

These are the gold standard for fact-checking. Always prefer Tier 1 sources when available.

### Research Firms & Consulting
- **Gartner** (gartner.com) - IT research and advisory
- **Forrester** (forrester.com) - Market research
- **McKinsey** (mckinsey.com) - Management consulting research
- **Deloitte** (deloitte.com) - Professional services research
- **BCG** (bcg.com) - Boston Consulting Group
- **Bain & Company** (bain.com) - Management consulting
- **IDC** (idc.com) - International Data Corporation

### Academic & Research Institutions
- **Harvard Business Review** (hbr.org)
- **MIT** (mit.edu) - Massachusetts Institute of Technology
- **Stanford** (stanford.edu)
- **Wharton** (wharton.upenn.edu)
- **.edu domains** - Accredited universities
- **Peer-reviewed journals** - Academic publications

### Industry Leaders (In Their Domain)
- **HubSpot Research** (hubspot.com) - For marketing/sales statistics
- **Salesforce Research** (salesforce.com) - For CRM/sales data
- **Adobe** (adobe.com) - For creative/marketing tech
- **Google Research** (research.google) - For search/tech
- **Microsoft Research** (microsoft.com/research) - For tech/AI

### Major Publications
- **Wall Street Journal** (wsj.com)
- **Forbes** (forbes.com)
- **Bloomberg** (bloomberg.com)
- **Reuters** (reuters.com)
- **New York Times** (nytimes.com)
- **Financial Times** (ft.com)
- **The Economist** (economist.com)

---

## Tier 2 Sources (ACCEPTABLE)

Good sources that are acceptable but should be verified with additional sources when possible.

### Industry Publications
- **TechCrunch** (techcrunch.com) - Tech industry news
- **VentureBeat** (venturebeat.com) - Tech and gaming
- **Marketing Land** / **MarketingProfs** - Marketing industry
- **AdWeek** (adweek.com) - Advertising industry
- **CIO Magazine** (cio.com) - IT leadership
- **Information Week** (informationweek.com) - Enterprise IT

### Research & Data Firms
- **Statista** (statista.com) - Statistics portal
- **Nielsen** (nielsen.com) - Market research
- **Pew Research** (pewresearch.org) - Social science research
- **eMarketer** (emarketer.com) - Digital marketing research

### Known SaaS Companies (In Their Domain)
- **Intercom** (intercom.com) - Customer messaging
- **Drift** (drift.com) - Conversational marketing
- **Zendesk** (zendesk.com) - Customer service
- **Mailchimp** (mailchimp.com) - Email marketing
- **Shopify** (shopify.com) - E-commerce
- **Stripe** (stripe.com) - Payments

**Note:** SaaS company blogs are Tier 2 ONLY when discussing their own domain. A random SaaS blog discussing unrelated topics would be Tier 3.

### Government Sources
- **.gov domains** - Government websites
- **Census Bureau** (census.gov)
- **Bureau of Labor Statistics** (bls.gov)
- **SEC** (sec.gov) - Securities and Exchange Commission

---

## Tier 3 Sources (AVOID)

These sources should be avoided or used only as starting points to find the original source.

### Characteristics of Tier 3 Sources:
- Unknown blogs
- Content farms (sites producing high volumes of low-quality content)
- Aggregator sites (sites that compile content from other sources)
- Social media posts
- Forums and discussion boards
- Wikis (including Wikipedia - use it to find original sources, not as a source itself)
- Press releases (without independent verification)
- Marketing materials
- Uncredited statistics

### Red Flags:
- No author attribution
- No publication date
- No original research or data collection
- Citing "studies show" without naming the study
- Obvious bias or promotional intent
- Poorly written or unprofessional content

---

## Tracing to Original Sources

### When You Find a Secondary Source

If a Tier 2 or Tier 3 source cites research:

**Example:**
```
Found in: marketingblog.com (Tier 3)
Text: "According to Gartner Research, 85% of companies..."
```

**Action Required:**
1. Note the original source (Gartner)
2. Run new Exa query: "Gartner [specific topic] 2024"
3. Find the ORIGINAL Gartner report
4. Cite Gartner directly, not the blog

### Original vs. Secondary Source Table

| Type | Original Source | Secondary Source |
|------|----------------|------------------|
| Research Data | Gartner report PDF | Blog post about Gartner report |
| Company Announcement | Official press release | News article about announcement |
| Academic Finding | Published paper in journal | Magazine article about the research |
| Product Feature | Official documentation | Review site describing feature |
| Statistics | Census Bureau data | News article citing census data |

---

## Domain Authority Indicators

### Quick Assessment Checklist

**Tier 1 Indicators:**
- ✅ Research firm domain
- ✅ .edu or .gov extension
- ✅ Major publication
- ✅ Peer-reviewed journal
- ✅ Original research data

**Tier 2 Indicators:**
- ✅ Established industry publication
- ✅ Known company in relevant domain
- ✅ Professional journalism
- ✅ Named authors with credentials
- ✅ Clear data methodology

**Tier 3 Red Flags:**
- ❌ Unknown domain
- ❌ No author or credentials
- ❌ No sources cited
- ❌ Promotional content
- ❌ Thin/shallow content

---

## Verification Thresholds

### For CRITICAL Priority Claims:
- **Minimum:** 2 Tier 1 sources OR 3 Tier 2 sources
- **Preferred:** Multiple Tier 1 sources
- **Never:** Single Tier 3 source

### For HIGH Priority Claims:
- **Minimum:** 1 Tier 1 source OR 2 Tier 2 sources
- **Acceptable:** Strong Tier 2 with supporting evidence
- **Avoid:** Single Tier 3 source

### For MEDIUM Priority Claims:
- **Minimum:** 1 Tier 2 source OR 2 consistent Tier 2/3 sources
- **Acceptable:** Tier 3 if corroborated
- **Not ideal:** Single unverified source

### For LOW Priority Claims:
- **Flexible:** Can use Tier 2/3 if reasonable
- **Best practice:** Still verify if claiming as fact

---

## Date/Recency Requirements

### Current Data (2024-2025):
- **REQUIRED** for statistics and trends
- Sources must be from current or previous year
- Flag anything older than 2 years

### Historical Data:
- Acceptable to use older sources
- But must be appropriate to the claim
- "In 2020..." requires 2020 source

### Outdated Data Red Flags:
- Statistics from pre-2023 presented as current
- "Recent study" from 2019
- Market size data from 3+ years ago
- Technology adoption from outdated research

---

## Special Cases

### Company Documentation
- **Official docs** = Tier 1 (for that company's products)
- **Help center** = Tier 1 (for that company)
- **Blog post** = Tier 2 (if about own product)

### Industry Reports
- **Full report** = Tier 1
- **Summary/excerpt** = Tier 2
- **Blog about report** = Tier 3 (find original)

### Social Proof
- **Press releases** = Tier 2 (if from reputable company)
- **Case studies** = Tier 2 (if detailed and verifiable)
- **Testimonials** = Not suitable for fact claims

---

## Citation Best Practices

### Format:
```
Source: [Company/Publication Name] - [Report/Article Title] - [Year]
URL: [direct link]
Authority: Tier [1/2/3]
Date: [publication date]
```

### Example:
```
Source: Gartner - "Magic Quadrant for CRM 2024" - 2024
URL: https://www.gartner.com/doc/reprints?id=1-2EXAMPLE
Authority: Tier 1
Date: March 2024
```

---

## Quick Reference Guide

| If you find... | Then... |
|---------------|---------|
| Statistics without source | ❌ UNSUPPORTED - Search for original data |
| Blog citing Gartner | 🔍 TRACE - Find original Gartner report |
| Official product docs | ✅ VERIFIED (Tier 1 for that product) |
| Unknown blog opinion | ❌ AVOID - Not suitable for fact claims |
| Industry publication data | ⚠️ ACCEPTABLE (Tier 2) - Verify if CRITICAL |
| .edu research paper | ✅ VERIFIED (Tier 1) |
| Multiple Tier 2 agreeing | ✅ VERIFIED - Cross-referenced |
| Tier 3 contradicting Tier 1 | ✅ Trust Tier 1 |

---

## Remember

1. **Always prefer original sources** over secondary sources
2. **Never cite Tier 3 sources** for critical claims
3. **Cross-reference** multiple sources when possible
4. **Check publication dates** - current data only for current claims
5. **Trace citations** - if source cites another source, find the original

**When in doubt:** Search for the original authoritative source using Exa.ai.
