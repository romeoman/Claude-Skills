# Entity Understanding Patterns

## Why Entity Understanding Matters

Before creating any content brief, you MUST understand:
1. What entities exist in the topic space
2. How they relate to each other
3. Common misconceptions about these relationships
4. Boundaries between similar entities

**Without this understanding, briefs create confused content.**

## Entity Analysis Framework

### Step 1: Identify All Entities

For any topic, ask:
- **WHAT** are the main things/concepts/tools involved?
- **WHO** are the players/stakeholders/users?
- **HOW** do processes/workflows connect them?
- **WHERE** do boundaries exist?

### Step 2: Map Relationships

Document how entities connect:
- **INCLUDES**: What's part of this entity?
- **REQUIRES**: What dependencies exist?
- **ENABLES**: What does this make possible?
- **DIFFERS FROM**: What's commonly confused with this?

### Step 3: Identify Misconceptions

Find what people get wrong:
- Common conflations (X is not the same as Y)
- False assumptions (X doesn't automatically include Y)
- Boundary confusion (X ends here, Y starts there)

---

## Example: HubSpot AI Agents

### Entities Identified

```
1. HubSpot Breeze (umbrella AI brand)
   - The overall AI ecosystem name
   
2. Breeze Copilot (assistant tool)
   - Chat interface for quick tasks
   - Answers questions, generates content
   
3. Breeze Agents (autonomous workers)
   a. Customer Agent
      - Handles support tickets
      - Responds to customer inquiries
   b. Prospecting Agent  
      - Identifies and qualifies leads
      - Enriches contact data
   c. Content Agent
      - Creates marketing content
      - Manages content calendar
   d. Social Media Agent
      - Schedules posts
      - Monitors engagement

4. Breeze Intelligence (data enrichment)
   - Buyer intent signals
   - Company/contact data enrichment
   - NOT an agent, but a data layer
```

### Relationship Map

```
HubSpot Breeze (Ecosystem)
├── Breeze Copilot (Interactive Assistant)
│   └── Uses all Breeze capabilities
├── Breeze Agents (Autonomous Workers)
│   ├── Customer Agent → CRM Service Hub
│   ├── Prospecting Agent → CRM Sales Hub
│   ├── Content Agent → Marketing Hub
│   └── Social Media Agent → Marketing Hub
└── Breeze Intelligence (Data Layer)
    └── Feeds data to all agents
```

### Common Misconceptions

1. **Breeze Intelligence is NOT an agent**
   - It's a data enrichment service
   - Agents USE Intelligence data
   
2. **Copilot vs Agents**
   - Copilot: Interactive, requires prompting
   - Agents: Autonomous, work independently
   
3. **Agent boundaries**
   - Customer Agent ≠ Prospecting Agent
   - Each has specific scope and capabilities

---

## Example: Lead Scoring Components

### Entities Identified

```
1. Lead Scoring (methodology)
   - System for ranking leads
   - Can be manual or automated

2. HubSpot Lead Scoring (specific implementation)
   - Native feature in HubSpot
   - Part of Marketing Hub Professional+

3. Scoring Properties (data fields)
   - Custom properties that hold scores
   - Can be positive or negative

4. Scoring Criteria
   a. Demographic/Firmographic (fit)
      - Job title, company size, industry
   b. Behavioral (engagement)
      - Email opens, page visits, downloads
   c. Negative scoring
      - Unsubscribes, competitor, student

5. Lead Score (output)
   - Numerical value assigned to lead
   - Triggers for MQL status

6. Predictive Lead Scoring
   - AI-powered scoring
   - Separate from manual scoring
```

### Relationship Map

```
Lead Scoring Methodology
└── HubSpot Implementation
    ├── Scoring Properties (storage)
    ├── Scoring Criteria (rules)
    │   ├── Demographic → Company Properties
    │   ├── Behavioral → Activity Tracking
    │   └── Negative → Disqualifiers
    ├── Lead Score (calculation)
    └── MQL Status (outcome)
```

### Common Misconceptions

1. **Lead Scoring vs Lead Score**
   - Lead Scoring = the system/process
   - Lead Score = the numerical output
   
2. **Manual vs Predictive**
   - Manual: Rule-based, you define
   - Predictive: AI-based, learns from data
   - They're SEPARATE systems
   
3. **Properties vs Criteria**
   - Properties: Where scores are stored
   - Criteria: Rules for assigning scores

---

## Pattern: Software/Tools

When analyzing software/tools:

### Key Entities
- Platform/System (overall solution)
- Modules/Features (components)
- Integrations (connections)
- Users/Roles (who uses it)
- Data/Objects (what it manages)

### Common Conflations
- Platform name vs feature name
- Native features vs integrations
- Core functionality vs add-ons
- User types vs permissions

---

## Pattern: Business Processes

When analyzing processes:

### Key Entities
- Process/Methodology (overall approach)
- Stages/Phases (sequential steps)
- Stakeholders (participants)
- Inputs/Outputs (data flow)
- Tools/Systems (enablers)

### Common Conflations
- Process vs tool that enables it
- Stage vs entire process
- Stakeholder vs decision-maker
- Input vs prerequisite

---

## Pattern: Marketing/Sales Concepts

When analyzing concepts:

### Key Entities
- Strategy (high-level approach)
- Tactics (specific actions)
- Channels (delivery methods)
- Metrics (measurements)
- Outcomes (results)

### Common Conflations
- Strategy vs tactics
- Channel vs content type
- Metric vs goal
- Activity vs outcome

---

## Red Flags: When Entity Understanding is Poor

Watch for these signs of poor entity understanding:

1. **Using terms interchangeably** that are actually different
2. **Attributing capabilities** to the wrong component
3. **Mixing hierarchies** (comparing different levels)
4. **Assuming inclusion** (X automatically includes Y)
5. **Boundary confusion** (unclear where X ends and Y begins)

---

## Best Practices

1. **Research before structuring**
   - Understand entities first
   - Then create headings
   
2. **Document boundaries explicitly**
   - State what IS included
   - State what IS NOT included
   
3. **Use precise language**
   - Name entities consistently
   - Don't use synonyms carelessly
   
4. **Validate with examples**
   - Test understanding with real scenarios
   - Check if relationships hold true

5. **Address misconceptions directly**
   - Call out common mistakes
   - Explain the differences clearly