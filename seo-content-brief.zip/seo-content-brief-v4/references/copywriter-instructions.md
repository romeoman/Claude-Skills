# Copywriter Instructions (v4)

## Core Writing Principles

### 1. Answer First, Explain Second
```
✅ RIGHT: "Research intent identifies buyers 3-6 months before they're ready to purchase. This early-stage behavior includes..."

❌ WRONG: "In the modern B2B landscape, understanding buyer behavior is crucial. One important aspect is research intent, which..."
```

### 2. Short, Varied Sentences
- Mix 1, 2, and 3 sentence paragraphs
- Average 15-20 words per sentence
- Never 4+ sentences in one paragraph

```
✅ RIGHT:
Research intent signals appear months before purchase decisions.

This early visibility gives sales teams a crucial advantage. They can nurture leads before competitors even know they exist.

The key is recognizing these signals.
```

### 3. Use Bullets Liberally
Target 8-12 bullet sections per article. Use for:
- Feature lists
- Step-by-step processes
- Key benefits
- Common mistakes
- Statistics compilation

### 4. Include Specific Numbers
```
✅ RIGHT: "Teams save 5-7 hours weekly through automation"
❌ WRONG: "Teams save significant time"

✅ RIGHT: "Increase conversion rates by 25-40%"
❌ WRONG: "Improve conversion rates"
```

### 5. Add Visual Markers
Include 2-4 placeholders:
- `[Screenshot: HubSpot scoring property setup]`
- `[Diagram: Research intent workflow]`
- `[Table: Intent signal scoring values]`

---

## v4 Section Patterns with Word Targets

### Opening Paragraphs (H1: 200-250 words)
1. Hook with keyword + specific value
2. Add supporting statistic (use assigned STAT_ID)
3. Bridge to main content
4. Set expectations for article

### Framework/Overview Sections (H2: 150-200 words)
1. **Subheader** (often a question)
2. Direct answer (1-2 sentences)
3. Brief explanation of components
4. Transition to next section

### Implementation Sections (H2: 250-350 words)
1. **Subheader** with action verb
2. Step-by-step guidance
3. Specific settings/configurations
4. Common pitfalls to avoid
5. Screenshot placeholder

### Configuration Subsections (H3: 150-200 words)
1. Navigation path
2. Setting explanations
3. Recommended values
4. Warning or tip

### Conclusions (100-150 words)
1. Summarize key points (bullets work)
2. Provide clear next step
3. Link to related resource

---

## Statistics Usage (v4 Enhanced)

### Using Assigned Statistics

Each brief includes statistics with STAT_IDs. Use exactly as assigned:

```
Brief says: "Use STAT_01 in H1 opening"
STAT_01: "47% better conversion" - Forrester

Your writing:
"Companies implementing intent-based targeting see 47% better conversion rates (Forrester), 
making early buyer identification essential for competitive B2B sales..."
```

### Format Options:
```
According to Forrester Research, 70% of B2B buyers complete their journey before contacting sales.
```
OR
```
B2B buyers consume an average of 13 pieces of content before purchasing (Source: FocusVision).
```

### Rules:
- Use ONLY statistics assigned in the brief
- Maximum 3 external sources per article
- Use each domain only once
- Include publication year for time-sensitive data
- Link to original source when possible
- **Do NOT substitute different statistics**

---

## MAN Digital Voice

### Do Use:
- "This approach" (not "revolutionary method")
- "Works for most B2B companies" (not "transforms everything")
- "Typically takes 2-3 months" (not "quick wins")
- "Here's how" (not "discover the secrets")

### Don't Use:
- Superlatives (amazing, incredible, game-changing)
- Vague promises (skyrocket, explode, massive)
- Jargon without explanation
- Feature worship without process context

---

## Common Mistakes to Avoid

1. **Opening with background**
   - Jump straight to value
   - Skip the history lesson

2. **Walls of text**
   - Break up with bullets
   - Add subheaders
   - Use short paragraphs

3. **Theoretical without practical**
   - Always include "how to"
   - Provide real examples
   - Show actual settings/configs

4. **Perfect world scenarios**
   - Acknowledge challenges
   - Include timeline realities
   - Mention resource requirements

5. **Wrong statistics (v4)**
   - Use ONLY assigned statistics
   - Check STAT_ID in brief
   - Don't substitute similar stats

6. **Exceeding word targets (v4)**
   - Check WORD_TARGET for each section
   - Stay within ±10% of target
   - Cut fluff, not substance

---

## Quick Checklist (v4)

Before submitting:
- [ ] Opens with direct value statement?
- [ ] Uses assigned statistics (check STAT_IDs)?
- [ ] Each section meets word target (±10%)?
- [ ] Includes 8-12 bullet sections?
- [ ] Statistics properly cited?
- [ ] Visual placeholders added (2-4)?
- [ ] Paragraphs varied (1, 2, 3 sentences)?
- [ ] Practical examples included?
- [ ] Clear next steps provided?
- [ ] Doesn't duplicate content from linked articles?
- [ ] 1500-2000 words total (unless specified)?

---

## Example Section (v4 Format)

Here's how a section should look with word target adherence:

---

### How Does HubSpot Track Research Behavior? 
**[WORD_TARGET: 200-250 words]**

HubSpot captures research intent through native behavioral tracking on your website and content properties. [STAT_02: Companies using behavioral tracking identify 2.3x more qualified opportunities (Aberdeen).]

Every action a visitor takes creates a digital footprint. These signals, when properly interpreted, reveal where prospects are in their buying journey. The key is knowing which actions indicate research versus purchase readiness.

**High-Value Research Signals:**
- Downloading educational content (+10 points)
- Viewing 3+ blog posts in one session (+5 points)
- Attending webinars (+20 points)
- Watching product demo videos (+15 points)
- Returning to resource pages (+8 points)

[Screenshot: HubSpot behavioral tracking dashboard]

Unlike third-party intent data, these signals come directly from your properties. This first-party data is more accurate and actionable.

The challenge? Setting appropriate thresholds. Too low and you'll overwhelm sales with unqualified leads. Too high and you'll miss opportunities.

Most B2B companies find success with research thresholds between 30-50 points, adjusting monthly based on conversion data.

**[Word count: ~215 words - within target]**
