# Statistics Sources Reference (v4)

## Tier-1 Sources by Topic Area

### CRM/Implementation
| Source | Type | Best For | Check Before Using |
|--------|------|----------|-------------------|
| CRM.org | Research reports | CRM adoption, implementation stats | Fresh annually |
| SuperOffice | Industry surveys | European CRM data, B2B benchmarks | Good for EU focus |
| Nucleus Research | ROI studies | Tool ROI, productivity metrics | Expensive to access |
| Capterra | User surveys | Feature comparisons, user satisfaction | Check sample size |

### European B2B Market
| Source | Type | Best For | Check Before Using |
|--------|------|----------|-------------------|
| ECXO | Customer experience | European CX benchmarks | Good regional data |
| IDC Europe | Market research | Tech adoption, spending forecasts | Requires subscription |
| Eurostat | Official statistics | Market size, business demographics | Free, authoritative |

### Tech Adoption & Digital Transformation
| Source | Type | Best For | Check Before Using |
|--------|------|----------|-------------------|
| IDC Future Enterprise | Annual surveys | Digital transformation trends | High credibility |
| Gartner | Research notes | Tech predictions, adoption curves | ⚠️ Often overused |
| Deloitte | Industry reports | Business transformation data | Good for C-suite |

### Consulting Benchmarks
| Source | Type | Best For | Check Before Using |
|--------|------|----------|-------------------|
| McKinsey | Research articles | Transformation, growth stats | ⚠️ Often overused |
| BCG | Analysis reports | Change management, ROI | ⚠️ Often overused |
| Bain | Customer surveys | NPS, loyalty metrics | Good for customer data |

### Industry Research
| Source | Type | Best For | Check Before Using |
|--------|------|----------|-------------------|
| Forrester | Analyst reports | B2B buying, tech evaluations | ⚠️ Often overused |
| HubSpot Research | Annual reports | Marketing, sales benchmarks | Good for HubSpot context |
| Salesforce State of | Annual surveys | Sales, marketing, service trends | Good alternative to HubSpot |
| LinkedIn B2B | Marketing studies | B2B marketing effectiveness | Social selling focus |

---

## FORBIDDEN STATISTICS (Site-Wide Overuse)

These statistics appear too frequently across MAN Digital content. **DO NOT USE:**

| Statistic | Source | Why Forbidden |
|-----------|--------|---------------|
| "75% of RevOps see 10-20% growth" | Gartner | Used in 5+ articles |
| "70% of B2B buyers complete journey before sales" | Forrester | Used everywhere |
| "36% better customer retention" | Forrester | Overused |
| "70% digital transformation fail" | BCG/McKinsey | Cliché |
| "87% skills gap" | McKinsey | Used in multiple pieces |
| "Companies using CRM see 29% revenue increase" | Generic | Source unclear |

---

## Search Query Patterns for Fresh Statistics

### Primary Search Pattern
```
"{topic}" statistics 2024 OR 2025 site:{source}
```

### Alternative Patterns
```
"{topic}" survey results PDF 2025
"{topic}" benchmark report B2B
"{topic}" industry research data
"{topic}" state of report 2025
```

### Example Searches
```
"buyer intent" statistics 2025 site:forrester.com
"RevOps" benchmark report B2B 2024
"CRM implementation" survey results PDF 2025
"sales automation" state of report 2025
```

---

## Statistics Validation Checklist

Before including any statistic:

- [ ] **Recency**: Is it from 2023 or later? (2024-2025 preferred)
- [ ] **Source credibility**: Is the source authoritative for this topic?
- [ ] **Sample size**: Does the study have sufficient sample (n>100 for surveys)?
- [ ] **Exclusion check**: Is it in the forbidden list or cluster exclusion?
- [ ] **Assignment**: Have you assigned it to a specific heading?
- [ ] **Context fit**: Does it support the point being made?

---

## Statistics Assignment Format

When documenting statistics for a brief:

```markdown
## STATISTICS FOR BRIEF

### STAT_01
- **Statistic:** "47% better conversion rates for intent-driven campaigns"
- **Source:** Forrester, Intent Data 2024 Report
- **Year:** 2024
- **Use In:** H1 - intro paragraph
- **Context:** Justifies importance of intent tracking

### STAT_02
- **Statistic:** "Companies using ABM see 208% higher revenue"
- **Source:** Terminus ABM Benchmark Report
- **Year:** 2024
- **Use In:** H2-3 (ROI section)
- **Context:** Business case for implementation
```

---

## Recency Requirements

| Content Type | Maximum Age | Preferred Age |
|--------------|------------|---------------|
| Technology adoption | 2 years | <1 year |
| Market size/growth | 1 year | Current |
| Buyer behavior | 2 years | <1 year |
| ROI/Performance | 3 years | <2 years |
| Industry benchmarks | 2 years | <1 year |
| Methodology/Best practices | 3 years | Any |

---

## Alternative Fresh Sources

When tier-1 sources are exhausted:

### Academic/Research
- Harvard Business Review
- MIT Sloan Management Review
- Journal of Marketing Research

### Industry Publications
- MarTech (marketing technology)
- RevGenius (RevOps community)
- SaaStr (SaaS metrics)

### Vendor-Neutral Analysts
- Ascend2 (marketing surveys)
- Demand Gen Report
- Content Marketing Institute

### Regional Sources (Europe)
- European Commission reports
- National statistical offices
- Regional business publications
