# N-Grams and Keywords Reference

## What are N-Grams?

N-grams are sequences of words that appear together in your content, where 'n' represents the number of words in the sequence. They help maintain semantic relevance and topical consistency.

### Examples:
- **1-gram (Unigram):** "Sales," "Operations," "Revenue"
- **2-gram (Bigram):** "Sales operations," "Revenue growth"
- **3-gram (Trigram):** "B2B sales operations," "Revenue operations strategy"
- **4-gram:** "Sales operations management process"

### Purpose in Content Briefs:
1. **Semantic Relevance:** Reinforce the topic for search engines
2. **Content Consistency:** Ensure related phrases appear throughout
3. **Avoid Redundancy:** Use variations to maintain relevance without repetition
4. **Context Alignment:** All n-grams should align with the macro context

## N-GRAMS Column in Briefs

### Format:
- Pipe-separated phrases: `"phrase one | phrase two | phrase three"`
- **NOT required for every heading** - only where semantically relevant
- Typically more important for H1 and H2 headings

### Examples from Actual Briefs:

**For GTM Operations:**
```
"GTM operations | GTM strategy | Sales alignment | Marketing alignment | 
Revenue growth | Market strategy | Team collaboration | Process optimization"
```

**For Buyer Intent:**
```
"HubSpot buyer intent | anonymous visitor tracking | pipeline opportunities | 
ABM targeting | intent data configuration"
```

**For Account Enrichment:**
```
"data enrichment process | B2B account enrichment | CRM data quality | 
third-party data providers | account intelligence"
```

### When to Include N-Grams:
- **H1:** Always include comprehensive n-grams
- **H2:** Include when introducing new concepts or key sections
- **H3:** Optional - only if introducing specific terminology

### When NOT to Include N-Grams:
- Simple transitional sections
- Conclusion sections
- When it would be forced or unnatural

---

## KEYWORDS Column

### Format:
**Only for H1 headings!** Include the primary keywords with search volume from DataForSEO.

### Correct Format:
```
"keyword phrase - volume
second keyword - volume
third keyword - volume"
```

### Examples:
```
"gtm operations - 150
go to market operations - 60
gtm strategy - 200"
```

```
"data enrichment - 1300
account based marketing data - 80
crm data enrichment - 100"
```

### Important Notes:
- **Get volume data from DataForSEO** keyword research
- **Only include in H1 row** - leave blank for all other headings
- Include 2-4 primary keywords with highest relevance
- Format: keyword phrase, then hyphen, then volume

---

## Context Vector and N-Grams Relationship

The n-grams should support the context vector:

### Example: If your context vector is about "RevOps alignment"
**Good n-grams:**
- "revenue operations alignment"
- "sales marketing alignment"  
- "cross-functional collaboration"
- "revenue team optimization"

**Bad n-grams (break context):**
- "general business management"
- "startup growth tips"
- "HR operations" (unless specifically relevant)

---

## Practical Guidelines

### DO:
- Use n-grams that reinforce your main topic
- Vary the phrases to avoid repetition
- Include both broad and specific terms
- Align with user search intent

### DON'T:
- Force n-grams where they don't fit naturally
- Use the same phrases repeatedly
- Include n-grams that break topical relevance
- Add n-grams just to fill the column

---

## Quick Reference

| Column | When to Fill | Format | Example |
|--------|-------------|---------|----------|
| KEYWORDS | H1 only | keyword - volume | "hubspot buyer intent - 150" |
| N-GRAMS | H1, H2, selective H3 | phrase 1 \| phrase 2 | "buyer intent \| intent signals" |

Remember: Quality over quantity. It's better to have relevant, focused n-grams than to force them into every row.