# Blog Embedding Guide

## Overview

This guide ensures HubSpot custom modules embed cleanly within blog posts without conflicts or layout issues.

## Blog CSS Context

Your modules will be embedded within a blog post that has this CSS structure:

```css
.blog-post {
  margin: 0 auto;
  max-width: 960px;
  padding: 0 20px;
  font-family: 'Georgia', serif;
  line-height: 1.6;
  color: #333;
}

.blog-post h1,
.blog-post h2,
.blog-post h3 {
  font-family: 'Arial', sans-serif;
  margin-top: 1.5em;
  margin-bottom: 0.5em;
}

.blog-post p {
  margin-bottom: 1em;
}

.blog-post__tags {
  display: flex;
  gap: 0.5rem;
  margin: 1rem 0;
}

.blog-post__tags svg {
  width: 16px;
  height: 16px;
}
```

## Critical Requirements

### 1. Width Constraints

**Rule**: Never exceed the blog's 960px max-width.

**Implementation**:
```html
<!-- Outer wrapper respects blog width -->
<div class="tw-w-full tw-max-w-[960px] tw-mx-auto tw-px-4 md:tw-px-0">
  <!-- Module content -->
</div>
```

**Why**: Content overflowing the blog width breaks layout and creates horizontal scrolling on mobile.

### 2. Bottom Spacing Control

**Rule**: No excess bottom padding that creates awkward gaps between content.

**Implementation**:
```html
<!-- Outer wrapper has no bottom padding -->
<div class="tw-pb-0">
  <!-- Content with controlled last-child spacing -->
  <div class="tw-space-y-4">
    <div class="tw-mb-4 last:tw-mb-0">Item 1</div>
    <div class="tw-mb-4 last:tw-mb-0">Item 2</div>
    <div class="tw-mb-4 last:tw-mb-0">Item 3</div>
  </div>
</div>
```

**Why**: Blog posts have their own vertical rhythm. Extra module padding disrupts flow.

### 3. Heading Hierarchy (SEO Critical)

**Rule**: **NEVER use H1 or H2 tags in modules.** Maximum heading level is H3.

**Why**: Blog posts already have:
- **H1**: Blog post title (only one per page for SEO)
- **H2**: Main section headings throughout the blog content
- Multiple H1s or H2s harm SEO and confuse screen readers

**Implementation**:
```html
<!-- ✅ Correct: Use H3 for module headings -->
<h3 class="module-heading">Feature Title</h3>

<!-- ✅ Correct: Use styled spans for emphasis -->
<strong class="subheading">Subheading Text</strong>
<span class="heading-style">Emphasized Text</span>

<!-- ❌ NEVER: Do not use H1 or H2 -->
<h1>This breaks SEO</h1>
<h2>This also breaks SEO</h2>
```

**Sizing Standard**:
```css
/* H3 should be 28px for visual hierarchy */
.module-heading,
h3 {
  font-size: 28px;
  line-height: 1.3;
  margin-bottom: 1rem;
}

/* Use classes for other heading styles */
.subheading {
  font-size: 20px;
  font-weight: 600;
  display: block;
  margin-bottom: 0.5rem;
}
```

**Accessibility Note**: If you need visual hierarchy beyond H3, use:
- CSS classes with `<strong>` or `<span>` tags
- `role="heading"` with `aria-level="4"` for semantic structure without SEO impact

### 4. Typography Inheritance

**Rule**: Don't force fonts or sizes globally; let blog typography apply where appropriate.

**Implementation**:
```html
<!-- ✅ Good: Only style what needs to differ -->
<h3 class="module-title">Module Heading</h3>
<p>Regular paragraph text inherits blog styles</p>

<!-- ❌ Bad: Overriding everything -->
<div style="font-family: Arial; font-size: 16px; line-height: 1.5;">
  <!-- Forces all text to use these styles -->
</div>
```

**Why**: Blog has consistent typography. Only override when module requires specific styling.

### 4. Icon Sizing

**Rule**: Don't override `.blog-post__tags` icon sizing (16px).

**Implementation**:
```html
<!-- Module icons use their own classes -->
<svg class="tw-w-6 tw-h-6" stroke="currentColor">
  <!-- Module icon -->
</svg>

<!-- Don't add global icon styles that affect blog -->
<!-- ❌ Bad: svg { width: 24px !important; } -->
```

**Why**: Blog tags have specific 16px icons. Global overrides break blog layout.

### 5. Touch Targets (Mobile)

**Rule**: Ensure all clickable elements are ≥44px on mobile.

**Implementation**:
```html
<!-- Buttons with adequate touch area -->
<button class="tw-min-h-[44px] tw-px-4 tw-py-3">Click me</button>

<!-- Touch-optimized spacing -->
<div class="tw-space-y-2 pointer-coarse:tw-space-y-3">
  <a class="tw-block tw-py-3">Link 1</a>
  <a class="tw-block tw-py-3">Link 2</a>
</div>
```

**Why**: Mobile users need adequate tap targets. Too small = frustrating UX.

## Module Wrapper Pattern

### Standard Wrapper

Use this wrapper for most modules:

```html
<div class="tw-w-full tw-max-w-[960px] tw-mx-auto tw-px-4 md:tw-px-0 tw-pb-0">
  <div class="tw-bg-white tw-rounded-2xl tw-shadow-lg tw-p-6 md:tw-p-8">
    <!-- Module content -->
    <div class="tw-space-y-4">
      <div class="last:tw-mb-0">Content item</div>
    </div>
  </div>
</div>
```

**Breakdown**:
- `tw-w-full` - Full width within container
- `tw-max-w-[960px]` - Match blog max-width
- `tw-mx-auto` - Center the module
- `tw-px-4 md:tw-px-0` - Mobile padding, none on desktop (blog handles it)
- `tw-pb-0` - No bottom padding

### Flush Module (No Card)

For modules that blend into blog content:

```html
<div class="tw-w-full tw-max-w-[960px] tw-mx-auto tw-px-4 md:tw-px-0 tw-pb-0">
  <div class="tw-space-y-4">
    <div class="last:tw-mb-0">Content item</div>
  </div>
</div>
```

### Full-Width Background Module

For modules with full-width backgrounds:

```html
<div class="tw-w-full tw-bg-gray-50 tw-py-8 tw-pb-0">
  <div class="tw-max-w-[960px] tw-mx-auto tw-px-4 md:tw-px-0">
    <!-- Content respects blog width -->
    <div class="tw-space-y-4">
      <div class="last:tw-mb-0">Content item</div>
    </div>
  </div>
</div>
```

## Responsive Testing Protocol

### Test Widths

1. **320px** - Small mobile (iPhone SE)
2. **375px** - Standard mobile (iPhone 12/13)
3. **768px** - Tablet (iPad)
4. **1024px** - Desktop
5. **1280px+** - Large desktop

### Testing Checklist

At each width, verify:

- [ ] **No horizontal scroll** - Content fits within viewport
- [ ] **Touch targets ≥44px** - All buttons/links easily tappable
- [ ] **Text is readable** - Adequate font size and line height
- [ ] **Spacing is consistent** - No awkward gaps or crowding
- [ ] **Icons sized correctly** - Not too large or small
- [ ] **Images scale properly** - No pixelation or overflow
- [ ] **Interactive elements work** - Clicks/taps register properly

### Mobile-Specific Tests

```html
<!-- Test touch target size -->
<button class="tw-min-h-[44px] tw-min-w-[44px]">
  <svg class="tw-w-6 tw-h-6">Icon</svg>
</button>

<!-- Test spacing on touch devices -->
<nav class="tw-space-y-2 pointer-coarse:tw-space-y-3">
  <a class="tw-block tw-py-2 pointer-coarse:tw-py-3">Link</a>
</nav>

<!-- Test readable font sizes -->
<p class="tw-text-base pointer-coarse:tw-text-lg">
  Text content
</p>
```

## Common Issues & Solutions

### Issue 1: Horizontal Scrolling on Mobile

**Symptom**: Content extends beyond viewport width.

**Cause**: Module wider than 960px or missing responsive padding.

**Solution**:
```html
<!-- ✅ Correct -->
<div class="tw-w-full tw-max-w-[960px] tw-px-4 md:tw-px-0">

<!-- ❌ Wrong -->
<div class="tw-w-[1200px]">
```

### Issue 2: Excess Bottom Spacing

**Symptom**: Large gap between module and next blog paragraph.

**Cause**: Module has bottom padding/margin, and blog adds its own.

**Solution**:
```html
<!-- ✅ Correct -->
<div class="tw-pb-0">
  <div class="tw-mb-4 last:tw-mb-0">Content</div>
</div>

<!-- ❌ Wrong -->
<div class="tw-pb-12">
  <div class="tw-mb-4">Content</div>
</div>
```

### Issue 3: Typography Conflicts

**Symptom**: Module text looks different from blog text.

**Cause**: Module overrides blog fonts/sizes unnecessarily.

**Solution**:
```html
<!-- ✅ Correct: Only style headings -->
<h2 class="tw-text-2xl tw-font-bold">Heading</h2>
<p>Body text inherits blog styles</p>

<!-- ❌ Wrong: Overrides everything -->
<div class="tw-font-sans tw-text-base">
  <h2>Heading</h2>
  <p>Body text</p>
</div>
```

### Issue 4: Icon Size Conflicts

**Symptom**: Blog tag icons become too large or module icons too small.

**Cause**: Global icon styles affect both blog and module.

**Solution**:
```css
/* ✅ Correct: Scope icon styles */
.module-icon {
  width: 24px;
  height: 24px;
}

/* ❌ Wrong: Global override */
svg {
  width: 24px !important;
  height: 24px !important;
}
```

### Issue 5: Touch Targets Too Small

**Symptom**: Mobile users can't reliably tap buttons.

**Cause**: Buttons smaller than 44px hit area.

**Solution**:
```html
<!-- ✅ Correct -->
<button class="tw-min-h-[44px] tw-px-4 tw-py-3">
  Button
</button>

<!-- ❌ Wrong -->
<button class="tw-px-2 tw-py-1">
  Button
</button>
```

## Testing in HubSpot

### Preview Environment Setup

1. Create a test blog post in HubSpot
2. Add your custom module to the post
3. Add regular blog content before and after
4. Preview at multiple viewport sizes

### Test Blog Content Template

```html
<h1>Blog Post Title</h1>
<p>This is a paragraph of regular blog content. It has the standard blog typography and spacing.</p>

<!-- Your module goes here -->

<p>This paragraph comes after the module. Check spacing between module and this paragraph.</p>

<h2>Another Section</h2>
<p>More blog content to ensure the module doesn't disrupt the flow.</p>
```

### Inspection Checklist

- [ ] Module respects 960px width constraint
- [ ] No horizontal scrolling at any viewport size
- [ ] Spacing between module and blog content is consistent
- [ ] Typography transitions smoothly between blog and module
- [ ] Icons in blog tags remain 16px
- [ ] Module icons are appropriate size (typically 24px)
- [ ] All interactive elements have ≥44px touch targets on mobile
- [ ] No console errors in browser DevTools
- [ ] Module loads and initializes correctly

## Browser Testing

### Required Browsers

- **Chrome** (Desktop & Mobile)
- **Safari** (Desktop & iOS)
- **Firefox** (Desktop)
- **Edge** (Desktop)

### Testing Steps

1. Open blog post with module in each browser
2. Test at mobile, tablet, and desktop widths
3. Check for layout issues, overlaps, or spacing problems
4. Test all interactive elements (clicks, hovers, focus states)
5. Verify no console errors
6. Check accessibility with screen reader (if applicable)

## Accessibility Considerations

### Focus States

```html
<!-- Visible focus indicators -->
<button class="focus:tw-ring-2 focus:tw-ring-blue-500 focus:tw-outline-none">
  Button
</button>

<!-- Focus-visible for mouse/keyboard difference -->
<a class="focus-visible:tw-ring-2 focus-visible:tw-ring-blue-500">
  Link
</a>
```

### Keyboard Navigation

- All interactive elements must be keyboard accessible
- Tab order should be logical
- Focus indicators must be visible
- No keyboard traps

### Screen Reader Support

```html
<!-- Meaningful icons need labels -->
<button aria-label="Close dialog">
  <svg class="tw-w-6 tw-h-6" aria-hidden="true">
    <!-- X icon -->
  </svg>
</button>

<!-- Decorative icons should be hidden -->
<svg class="tw-w-6 tw-h-6" aria-hidden="true">
  <!-- Decorative icon -->
</svg>

<!-- Complex interactions need ARIA -->
<div role="tablist">
  <button role="tab" aria-selected="true">Tab 1</button>
  <button role="tab" aria-selected="false">Tab 2</button>
</div>
```

## Performance Optimization

### Minimize Reflows/Repaints

```javascript
// ✅ Good: Batch DOM updates
function render() {
  const updates = [];
  state.items.forEach(item => {
    updates.push(`<div>${item.name}</div>`);
  });
  container.innerHTML = updates.join('');
}

// ❌ Bad: Multiple DOM manipulations
function render() {
  state.items.forEach(item => {
    const div = document.createElement('div');
    div.textContent = item.name;
    container.appendChild(div); // Triggers reflow each time
  });
}
```

### Lazy Load Images

```html
<img src="placeholder.jpg" 
     data-src="actual-image.jpg" 
     loading="lazy"
     class="tw-w-full tw-h-auto">
```

### Optimize JavaScript

```javascript
// Cache DOM queries
const elements = {
  container: document.querySelector('.module-container'),
  buttons: document.querySelectorAll('.module-button'),
  content: document.querySelector('.module-content')
};

// Use event delegation
elements.container.addEventListener('click', (e) => {
  if (e.target.matches('.module-button')) {
    handleButtonClick(e.target);
  }
});
```

## Final Checklist

Before deploying a module, verify:

- [ ] Wrapper uses correct pattern (width, padding, spacing)
- [ ] No excess bottom padding (`tw-pb-0`)
- [ ] Last-child spacing controlled (`last:tw-mb-0`)
- [ ] Touch targets ≥44px on mobile
- [ ] Icons sized with Tailwind classes
- [ ] No conflicts with blog CSS
- [ ] Tested at 320px, 768px, 1000px+
- [ ] Works in Chrome, Safari, Firefox, Edge
- [ ] No console errors
- [ ] Accessibility requirements met
- [ ] Interactive elements work via keyboard
- [ ] Focus states visible
- [ ] ARIA attributes where needed
- [ ] Performance is acceptable (no jank)
- [ ] Works with Tailwind 4.1 CDN
- [ ] Preflight disabled (no global resets)
- [ ] All utilities use `tw-` prefix

## Quick Fix Commands

```bash
# Check for missing tw- prefixes
grep -r "class=\"[^\"]*flex" module.html

# Check for excess bottom padding
grep -r "pb-[^0]" module.html

# Check for hardcoded widths > 960px
grep -r "w-\[.*px\]" module.html | grep -v "max-w"

# Verify touch target sizes
grep -r "min-h-\[" module.html
```
