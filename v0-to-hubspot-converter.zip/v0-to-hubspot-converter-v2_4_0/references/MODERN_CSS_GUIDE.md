# Modern CSS Guide for HubSpot Design Manager

## Overview

This guide covers modern native CSS features that work perfectly in HubSpot Design Manager without any frameworks, build tools, or external dependencies. All features have excellent browser support and are production-ready for 2025.

## Why Modern Native CSS?

- **No external dependencies** - Everything works natively in browsers
- **Better performance** - No large framework files to download
- **Full browser support** - All major features work in modern browsers
- **HubSpot compatibility** - No CDN blocking or build process issues
- **Future-proof** - Using web standards that continue to evolve

## Core Layout Features

### CSS Grid

The foundation for two-dimensional layouts:[1]

```css
/* Basic Grid */
.grid-container {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 2rem;
}

/* Responsive Grid (auto-fit) */
.responsive-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 1.5rem;
}

/* Named Grid Areas */
.layout {
  display: grid;
  grid-template-areas:
    "header header header"
    "sidebar content content"
    "footer footer footer";
  grid-template-columns: 200px 1fr 1fr;
  gap: 1rem;
}

.header { grid-area: header; }
.sidebar { grid-area: sidebar; }
.content { grid-area: content; }
.footer { grid-area: footer; }
```

### Flexbox

Perfect for one-dimensional layouts:[2]

```css
/* Basic Flex */
.flex-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 1rem;
}

/* Flex Wrap */
.flex-wrap {
  display: flex;
  flex-wrap: wrap;
  gap: 1rem;
}

/* Flex Column */
.flex-column {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

/* Centered Content */
.flex-center {
  display: flex;
  justify-content: center;
  align-items: center;
}
```

## CSS Custom Properties (Variables)

Make your styles maintainable and dynamic:[3]

```css
/* Define Variables */
:root {
  /* Colors */
  --color-primary: #6b5cff;
  --color-secondary: #ff6b9d;
  --color-text: #333333;
  --color-background: #ffffff;
  
  /* Spacing */
  --space-xs: 0.5rem;
  --space-sm: 1rem;
  --space-md: 1.5rem;
  --space-lg: 3rem;
  --space-xl: 4rem;
  
  /* Typography */
  --font-body: system-ui, -apple-system, sans-serif;
  --font-heading: 'Georgia', serif;
  --font-size-sm: 0.875rem;
  --font-size-base: 1rem;
  --font-size-lg: 1.25rem;
  --font-size-xl: 1.5rem;
  
  /* Border Radius */
  --radius-sm: 4px;
  --radius-md: 8px;
  --radius-lg: 12px;
  
  /* Shadows */
  --shadow-sm: 0 1px 3px rgba(0,0,0,0.1);
  --shadow-md: 0 4px 6px rgba(0,0,0,0.1);
  --shadow-lg: 0 10px 15px rgba(0,0,0,0.1);
}

/* Use Variables */
.card {
  background: var(--color-background);
  padding: var(--space-md);
  border-radius: var(--radius-md);
  box-shadow: var(--shadow-md);
  font-family: var(--font-body);
}

.card-title {
  font-family: var(--font-heading);
  font-size: var(--font-size-xl);
  margin-bottom: var(--space-sm);
}
```

## Modern CSS Functions

### clamp() - Fluid Typography and Sizing

Responsive sizing without media queries:[4]

```css
/* Fluid Typography - For Blog Modules use H3 max (28px) */
h3 {
  font-size: 28px; /* Fixed size for blog SEO compliance */
  line-height: 1.3;
}

/* For standalone pages (not blog modules) */
.page-h1 {
  font-size: clamp(2rem, 5vw, 4rem);
  /* min: 2rem, preferred: 5vw, max: 4rem */
}

.page-h2 {
  font-size: clamp(1.5rem, 3vw, 2.5rem);
}

p {
  font-size: clamp(1rem, 1.5vw, 1.125rem);
}

/* Fluid Spacing */
.section {
  padding: clamp(2rem, 5vw, 4rem);
}

/* Fluid Width */
.container {
  width: clamp(300px, 90%, 1200px);
}
```

**Important**: For blog-embedded modules, use fixed 28px for H3 headings to maintain SEO compliance and visual hierarchy.

### min() and max()

Choose between multiple values:[5]

```css
/* Responsive Width */
.container {
  width: min(100%, 1200px);
  /* Takes the smaller value */
}

/* Responsive Padding */
.section {
  padding: max(1rem, 3vw);
  /* Takes the larger value */
}

/* Combining min() and max() */
.content {
  width: min(100% - 2rem, 960px);
  padding: max(1rem, 2vw);
}
```

## CSS Nesting

Cleaner, more organized CSS:[6]

```css
/* Traditional CSS */
.card { background: white; }
.card h3 { color: #333; font-size: 28px; }
.card p { color: #666; }
.card:hover { box-shadow: 0 4px 12px rgba(0,0,0,0.1); }

/* Modern CSS Nesting */
.card {
  background: white;
  
  & h3 {
    color: #333;
    font-size: 28px; /* Blog SEO compliant */
    margin-bottom: 1rem;
  }
  
  & p {
    color: #666;
    line-height: 1.6;
  }
  
  &:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  }
  
  & .card-footer {
    margin-top: 1rem;
    border-top: 1px solid #eee;
  }
}
```

## Modern Selectors

### :has() - Parent Selector

Style parents based on their children:[7]

```css
/* Card with image gets grid layout */
.card:has(img) {
  display: grid;
  grid-template-columns: 200px 1fr;
  gap: 1rem;
}

/* Form with error shows red border */
.form-group:has(.error) {
  border-color: red;
}

/* List item with checkbox checked */
li:has(input[type="checkbox"]:checked) {
  text-decoration: line-through;
  opacity: 0.6;
}
```

### :is() - Grouping Selector

Group multiple selectors:[8]

```css
/* Group similar elements */
:is(.btn, .button, .cta) {
  padding: 0.75rem 1.5rem;
  border-radius: 4px;
  border: none;
  cursor: pointer;
}

/* For blog modules - only H3 */
:is(h3, .heading, .module-title) {
  font-size: 28px;
  line-height: 1.3;
  font-weight: 600;
}

/* Complex grouping */
:is(article, section, aside) :is(p, li) {
  color: var(--color-text);
  line-height: 1.6;
}
```

### :where() - Zero-Specificity Grouping

Same as :is() but with zero specificity:[9]

```css
/* Easily overridable styles */
:where(.btn, .button, .cta) {
  padding: 0.75rem 1.5rem;
  border-radius: 4px;
  border: none;
}

/* Can be overridden without !important */
.btn {
  padding: 1rem 2rem; /* This wins */
}
```

## Container Queries

Responsive design based on container size:[10]

```css
/* Define container */
.card-container {
  container-type: inline-size;
  container-name: card;
}

/* Query the container */
@container card (min-width: 400px) {
  .card {
    display: flex;
    gap: 1rem;
  }
}

@container card (min-width: 600px) {
  .card {
    display: grid;
    grid-template-columns: 1fr 2fr;
  }
}
```

## Logical Properties

Direction-agnostic spacing and sizing:[11]

```css
/* Physical Properties (old) */
.element {
  margin-left: 1rem;
  padding-right: 2rem;
  border-top: 1px solid;
}

/* Logical Properties (new) */
.element {
  margin-inline-start: 1rem;
  padding-inline-end: 2rem;
  border-block-start: 1px solid;
}

/* Common patterns */
.container {
  margin-inline: auto; /* centers horizontally */
  padding-block: 2rem; /* vertical padding */
  padding-inline: 1rem; /* horizontal padding */
}
```

## Modern Animations

### Scroll-Driven Animations

Native scroll effects:[12]

```css
@keyframes fade-in {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.animate-on-scroll {
  animation: fade-in linear;
  animation-timeline: view();
  animation-range: entry 0% cover 30%;
}
```

### View Transitions

Smooth page transitions:[13]

```css
@view-transition {
  navigation: auto;
}

::view-transition-old(root),
::view-transition-new(root) {
  animation-duration: 0.3s;
  animation-timing-function: ease-in-out;
}
```

## Practical Patterns

### Responsive Card Grid

```css
.card-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(min(100%, 300px), 1fr));
  gap: clamp(1rem, 3vw, 2rem);
  padding: clamp(1rem, 3vw, 2rem);
}

.card {
  background: white;
  border-radius: var(--radius-md);
  padding: var(--space-md);
  box-shadow: var(--shadow-sm);
  
  &:hover {
    box-shadow: var(--shadow-lg);
    transform: translateY(-2px);
    transition: all 0.2s ease;
  }
  
  & h3 {
    font-size: 28px; /* Blog SEO compliant */
    line-height: 1.3;
    margin-bottom: var(--space-sm);
  }
  
  & p {
    color: var(--color-text);
    line-height: 1.6;
  }
}
```

### Flexible Hero Section

**Note**: Hero sections are typically for standalone pages, not blog modules. If using in a blog module, replace heading tags with styled divs.

```css
/* For standalone pages (not blog modules) */
.hero {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  min-height: clamp(400px, 60vh, 800px);
  padding: clamp(2rem, 5vw, 4rem);
  background: linear-gradient(135deg, var(--color-primary), var(--color-secondary));
  
  /* For standalone pages - use H1 */
  & h1 {
    font-size: clamp(2rem, 6vw, 4rem);
    text-align: center;
    margin-bottom: var(--space-md);
  }
  
  & p {
    font-size: clamp(1rem, 2vw, 1.5rem);
    text-align: center;
    max-width: 60ch;
  }
}

/* For blog modules - use styled div instead */
.hero-blog {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  min-height: clamp(300px, 50vh, 600px);
  padding: clamp(2rem, 5vw, 4rem);
  background: linear-gradient(135deg, var(--color-primary), var(--color-secondary));
  
  /* Use H3 for blog modules */
  & h3 {
    font-size: 28px;
    text-align: center;
    margin-bottom: var(--space-md);
  }
  
  /* Or use styled div */
  & .hero-title {
    font-size: 36px;
    font-weight: 700;
    text-align: center;
    margin-bottom: var(--space-md);
  }
}
```

### Responsive Navigation

```css
.nav {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: var(--space-md);
  
  & .nav-list {
    display: flex;
    gap: var(--space-md);
    list-style: none;
  }
  
  & .nav-link {
    padding: 0.5rem 1rem;
    text-decoration: none;
    color: var(--color-text);
    
    &:hover {
      color: var(--color-primary);
      background: rgba(0, 0, 0, 0.05);
      border-radius: var(--radius-sm);
    }
  }
}

@media (max-width: 768px) {
  .nav .nav-list {
    flex-direction: column;
    width: 100%;
  }
}
```

## HubSpot-Specific Considerations

### Blog-Safe Container

```css
.module-wrapper {
  width: min(100%, 960px);
  margin-inline: auto;
  padding-block: var(--space-md);
  padding-inline: var(--space-sm);
  
  & > *:last-child {
    margin-bottom: 0;
  }
}
```

### Heading Hierarchy (SEO Critical)

**NEVER use H1 or H2 in blog-embedded modules** - they harm SEO and accessibility.

```css
/* Maximum heading level: H3 at 28px */
.module-wrapper h3,
.module-heading {
  font-size: 28px;
  line-height: 1.3;
  font-weight: 600;
  margin-bottom: 1rem;
}

/* Use classes for sub-headings (not H4, H5, H6) */
.subheading {
  font-size: 20px;
  font-weight: 600;
  display: block;
  margin-bottom: 0.5rem;
}

.label-heading {
  font-size: 16px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  margin-bottom: 0.5rem;
}
```

**Why**: Blog posts already have H1 (title) and H2 (sections). Multiple H1s or H2s per page:
- Harm SEO rankings
- Confuse screen readers
- Break semantic document structure

**Alternative approaches**:
```css
/* Styled emphasis without heading semantics */
.emphasis-text {
  font-size: 24px;
  font-weight: 600;
  color: var(--color-primary);
}

/* Use with <strong> or <span> tags */
```

### Icon Sizing

```css
.icon {
  width: 1.5rem;
  height: 1.5rem;
  flex-shrink: 0;
  stroke: currentColor;
}

.icon-sm { width: 1rem; height: 1rem; }
.icon-md { width: 1.5rem; height: 1.5rem; }
.icon-lg { width: 2rem; height: 2rem; }
```

### Touch Targets

```css
.btn {
  min-height: 44px;
  min-width: 44px;
  padding: 0.75rem 1.5rem;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
}
```

## CSS Organization Template

```css
/* ==========================================================================
   Module Name - HubSpot Custom Module
   ========================================================================== */

/* Variables
   ========================================================================== */
:root {
  --module-primary: #6b5cff;
  --module-spacing: 1rem;
  --module-radius: 8px;
}

/* Base Styles
   ========================================================================== */
.module-wrapper {
  width: min(100%, 960px);
  margin-inline: auto;
  padding: var(--module-spacing);
}

/* Heading Hierarchy - SEO Compliant (MAX H3)
   ========================================================================== */
.module-wrapper h3,
.module-heading {
  font-size: 28px;
  line-height: 1.3;
  font-weight: 600;
  margin-bottom: var(--module-spacing);
}

/* Sub-headings (use classes, not H4/H5/H6) */
.subheading {
  font-size: 20px;
  font-weight: 600;
  margin-bottom: 0.5rem;
}

/* Header
   ========================================================================== */
.module-header {
  margin-bottom: var(--module-spacing);
}

/* Content
   ========================================================================== */
.module-content {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: var(--module-spacing);
}

/* Interactive Elements
   ========================================================================== */
.module-btn {
  padding: 0.75rem 1.5rem;
  background: var(--module-primary);
  border-radius: var(--module-radius);
  border: none;
  cursor: pointer;
  
  &:hover {
    filter: brightness(1.1);
  }
  
  &:active {
    transform: scale(0.98);
  }
}

/* Responsive
   ========================================================================== */
@media (max-width: 768px) {
  .module-content {
    grid-template-columns: 1fr;
  }
}
```

## Browser Support

All features in this guide have excellent support in modern browsers (2023+):
- Chrome 90+
- Firefox 88+
- Safari 15+
- Edge 90+

For older browser support, you can use feature queries:

```css
@supports (display: grid) {
  .container {
    display: grid;
  }
}

@supports not (display: grid) {
  .container {
    display: flex;
  }
}
```

## Further Reading

- [MDN Web Docs - CSS](https://developer.mozilla.org/en-US/docs/Web/CSS)
- [CSS-Tricks](https://css-tricks.com/)
- [Modern CSS Solutions](https://moderncss.dev/)
- [State of CSS 2025](https://2025.stateofcss.com/)

---

**References:**
[1] CSS Grid Layout
[2] Flexbox Layout
[3] CSS Custom Properties
[4] clamp() Function
[5] min() and max() Functions
[6] CSS Nesting
[7] :has() Selector
[8] :is() Selector
[9] :where() Selector
[10] Container Queries
[11] Logical Properties
[12] Scroll-Driven Animations
[13] View Transitions API
