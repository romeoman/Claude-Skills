# Tailwind CSS to Standard CSS Conversion Guide

## Overview

This reference provides comprehensive conversions from Tailwind utility classes to standard CSS. Use this when converting v0.dev components that use Tailwind CSS.

## Layout & Display

### Flexbox
```css
/* Tailwind */ .flex              → display: flex;
/* Tailwind */ .inline-flex       → display: inline-flex;
/* Tailwind */ .flex-row          → flex-direction: row;
/* Tailwind */ .flex-col          → flex-direction: column;
/* Tailwind */ .flex-wrap         → flex-wrap: wrap;
/* Tailwind */ .flex-nowrap       → flex-wrap: nowrap;
/* Tailwind */ .items-start       → align-items: flex-start;
/* Tailwind */ .items-center      → align-items: center;
/* Tailwind */ .items-end         → align-items: flex-end;
/* Tailwind */ .items-stretch     → align-items: stretch;
/* Tailwind */ .justify-start     → justify-content: flex-start;
/* Tailwind */ .justify-center    → justify-content: center;
/* Tailwind */ .justify-end       → justify-content: flex-end;
/* Tailwind */ .justify-between   → justify-content: space-between;
/* Tailwind */ .justify-around    → justify-content: space-around;
/* Tailwind */ .gap-1            → gap: 0.25rem;
/* Tailwind */ .gap-2            → gap: 0.5rem;
/* Tailwind */ .gap-4            → gap: 1rem;
/* Tailwind */ .gap-6            → gap: 1.5rem;
/* Tailwind */ .gap-8            → gap: 2rem;
```

### Grid
```css
/* Tailwind */ .grid              → display: grid;
/* Tailwind */ .inline-grid       → display: inline-grid;
/* Tailwind */ .grid-cols-1       → grid-template-columns: repeat(1, minmax(0, 1fr));
/* Tailwind */ .grid-cols-2       → grid-template-columns: repeat(2, minmax(0, 1fr));
/* Tailwind */ .grid-cols-3       → grid-template-columns: repeat(3, minmax(0, 1fr));
/* Tailwind */ .grid-cols-4       → grid-template-columns: repeat(4, minmax(0, 1fr));
/* Tailwind */ .grid-cols-6       → grid-template-columns: repeat(6, minmax(0, 1fr));
/* Tailwind */ .grid-cols-12      → grid-template-columns: repeat(12, minmax(0, 1fr));
/* Tailwind */ .col-span-2        → grid-column: span 2 / span 2;
/* Tailwind */ .col-span-3        → grid-column: span 3 / span 3;
```

### Container & Width
```css
/* Tailwind */ .container         → max-width: 1200px; margin: 0 auto; padding: 0 1rem;
/* Tailwind */ .w-full            → width: 100%;
/* Tailwind */ .w-auto            → width: auto;
/* Tailwind */ .w-1/2             → width: 50%;
/* Tailwind */ .w-1/3             → width: 33.333333%;
/* Tailwind */ .w-1/4             → width: 25%;
/* Tailwind */ .max-w-screen-sm   → max-width: 640px;
/* Tailwind */ .max-w-screen-md   → max-width: 768px;
/* Tailwind */ .max-w-screen-lg   → max-width: 1024px;
/* Tailwind */ .max-w-screen-xl   → max-width: 1280px;
```

## Spacing

### Padding (multiply value by 0.25rem)
```css
/* Tailwind */ .p-0    → padding: 0;
/* Tailwind */ .p-1    → padding: 0.25rem;
/* Tailwind */ .p-2    → padding: 0.5rem;
/* Tailwind */ .p-3    → padding: 0.75rem;
/* Tailwind */ .p-4    → padding: 1rem;
/* Tailwind */ .p-6    → padding: 1.5rem;
/* Tailwind */ .p-8    → padding: 2rem;
/* Tailwind */ .p-12   → padding: 3rem;
/* Tailwind */ .px-4   → padding-left: 1rem; padding-right: 1rem;
/* Tailwind */ .py-4   → padding-top: 1rem; padding-bottom: 1rem;
/* Tailwind */ .pt-4   → padding-top: 1rem;
/* Tailwind */ .pr-4   → padding-right: 1rem;
/* Tailwind */ .pb-4   → padding-bottom: 1rem;
/* Tailwind */ .pl-4   → padding-left: 1rem;
```

### Margin
```css
/* Tailwind */ .m-0    → margin: 0;
/* Tailwind */ .m-auto → margin: auto;
/* Tailwind */ .m-4    → margin: 1rem;
/* Tailwind */ .mx-4   → margin-left: 1rem; margin-right: 1rem;
/* Tailwind */ .my-4   → margin-top: 1rem; margin-bottom: 1rem;
/* Tailwind */ .mt-4   → margin-top: 1rem;
/* Tailwind */ .mr-4   → margin-right: 1rem;
/* Tailwind */ .mb-4   → margin-bottom: 1rem;
/* Tailwind */ .ml-4   → margin-left: 1rem;
/* Tailwind */ .-m-4   → margin: -1rem; (negative margin)
```

## Typography

### Font Size
```css
/* Tailwind */ .text-xs    → font-size: 0.75rem; line-height: 1rem;
/* Tailwind */ .text-sm    → font-size: 0.875rem; line-height: 1.25rem;
/* Tailwind */ .text-base  → font-size: 1rem; line-height: 1.5rem;
/* Tailwind */ .text-lg    → font-size: 1.125rem; line-height: 1.75rem;
/* Tailwind */ .text-xl    → font-size: 1.25rem; line-height: 1.75rem;
/* Tailwind */ .text-2xl   → font-size: 1.5rem; line-height: 2rem;
/* Tailwind */ .text-3xl   → font-size: 1.875rem; line-height: 2.25rem;
/* Tailwind */ .text-4xl   → font-size: 2.25rem; line-height: 2.5rem;
```

### Font Weight
```css
/* Tailwind */ .font-thin       → font-weight: 100;
/* Tailwind */ .font-light      → font-weight: 300;
/* Tailwind */ .font-normal     → font-weight: 400;
/* Tailwind */ .font-medium     → font-weight: 500;
/* Tailwind */ .font-semibold   → font-weight: 600;
/* Tailwind */ .font-bold       → font-weight: 700;
/* Tailwind */ .font-extrabold  → font-weight: 800;
```

### Text Alignment & Styling
```css
/* Tailwind */ .text-left       → text-align: left;
/* Tailwind */ .text-center     → text-align: center;
/* Tailwind */ .text-right      → text-align: right;
/* Tailwind */ .italic          → font-style: italic;
/* Tailwind */ .uppercase       → text-transform: uppercase;
/* Tailwind */ .lowercase       → text-transform: lowercase;
/* Tailwind */ .capitalize      → text-transform: capitalize;
/* Tailwind */ .underline       → text-decoration: underline;
/* Tailwind */ .line-through    → text-decoration: line-through;
```

## Colors

### Text Colors
```css
/* Tailwind */ .text-black      → color: #000000;
/* Tailwind */ .text-white      → color: #ffffff;
/* Tailwind */ .text-gray-100   → color: #f3f4f6;
/* Tailwind */ .text-gray-200   → color: #e5e7eb;
/* Tailwind */ .text-gray-300   → color: #d1d5db;
/* Tailwind */ .text-gray-400   → color: #9ca3af;
/* Tailwind */ .text-gray-500   → color: #6b7280;
/* Tailwind */ .text-gray-600   → color: #4b5563;
/* Tailwind */ .text-gray-700   → color: #374151;
/* Tailwind */ .text-gray-800   → color: #1f2937;
/* Tailwind */ .text-gray-900   → color: #111827;
/* Tailwind */ .text-blue-500   → color: #3b82f6;
/* Tailwind */ .text-blue-600   → color: #2563eb;
/* Tailwind */ .text-blue-700   → color: #1d4ed8;
/* Tailwind */ .text-red-500    → color: #ef4444;
/* Tailwind */ .text-green-500  → color: #10b981;
```

### Background Colors
```css
/* Tailwind */ .bg-transparent  → background-color: transparent;
/* Tailwind */ .bg-white        → background-color: #ffffff;
/* Tailwind */ .bg-gray-50      → background-color: #f9fafb;
/* Tailwind */ .bg-gray-100     → background-color: #f3f4f6;
/* Tailwind */ .bg-gray-200     → background-color: #e5e7eb;
/* Tailwind */ .bg-blue-50      → background-color: #eff6ff;
/* Tailwind */ .bg-blue-500     → background-color: #3b82f6;
/* Tailwind */ .bg-blue-600     → background-color: #2563eb;
```

## Borders

### Border Width & Style
```css
/* Tailwind */ .border           → border-width: 1px; border-style: solid;
/* Tailwind */ .border-0         → border-width: 0;
/* Tailwind */ .border-2         → border-width: 2px;
/* Tailwind */ .border-4         → border-width: 4px;
/* Tailwind */ .border-t         → border-top-width: 1px;
/* Tailwind */ .border-r         → border-right-width: 1px;
/* Tailwind */ .border-b         → border-bottom-width: 1px;
/* Tailwind */ .border-l         → border-left-width: 1px;
```

### Border Colors
```css
/* Tailwind */ .border-gray-200  → border-color: #e5e7eb;
/* Tailwind */ .border-gray-300  → border-color: #d1d5db;
/* Tailwind */ .border-blue-500  → border-color: #3b82f6;
```

### Border Radius
```css
/* Tailwind */ .rounded-none     → border-radius: 0;
/* Tailwind */ .rounded-sm       → border-radius: 0.125rem;
/* Tailwind */ .rounded          → border-radius: 0.25rem;
/* Tailwind */ .rounded-md       → border-radius: 0.375rem;
/* Tailwind */ .rounded-lg       → border-radius: 0.5rem;
/* Tailwind */ .rounded-xl       → border-radius: 0.75rem;
/* Tailwind */ .rounded-2xl      → border-radius: 1rem;
/* Tailwind */ .rounded-full     → border-radius: 9999px;
```

## Effects

### Shadow
```css
/* Tailwind */ .shadow-sm   → box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
/* Tailwind */ .shadow      → box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
/* Tailwind */ .shadow-md   → box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
/* Tailwind */ .shadow-lg   → box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
/* Tailwind */ .shadow-xl   → box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
```

### Opacity
```css
/* Tailwind */ .opacity-0    → opacity: 0;
/* Tailwind */ .opacity-25   → opacity: 0.25;
/* Tailwind */ .opacity-50   → opacity: 0.5;
/* Tailwind */ .opacity-75   → opacity: 0.75;
/* Tailwind */ .opacity-100  → opacity: 1;
```

## Transitions
```css
/* Tailwind */ .transition             → transition-property: all; transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1); transition-duration: 150ms;
/* Tailwind */ .transition-colors      → transition-property: color, background-color, border-color;
/* Tailwind */ .transition-opacity     → transition-property: opacity;
/* Tailwind */ .transition-transform   → transition-property: transform;
/* Tailwind */ .duration-150           → transition-duration: 150ms;
/* Tailwind */ .duration-300           → transition-duration: 300ms;
/* Tailwind */ .duration-500           → transition-duration: 500ms;
/* Tailwind */ .ease-in-out            → transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
```

## Position & Display
```css
/* Tailwind */ .block        → display: block;
/* Tailwind */ .inline-block → display: inline-block;
/* Tailwind */ .hidden       → display: none;
/* Tailwind */ .relative     → position: relative;
/* Tailwind */ .absolute     → position: absolute;
/* Tailwind */ .fixed        → position: fixed;
/* Tailwind */ .top-0        → top: 0;
/* Tailwind */ .right-0      → right: 0;
/* Tailwind */ .bottom-0     → bottom: 0;
/* Tailwind */ .left-0       → left: 0;
/* Tailwind */ .z-10         → z-index: 10;
/* Tailwind */ .z-50         → z-index: 50;
```

## Responsive Modifiers

Convert responsive classes to media queries:

```css
/* Tailwind: sm:text-lg */
@media (min-width: 640px) {
  .element {
    font-size: 1.125rem;
    line-height: 1.75rem;
  }
}

/* Tailwind: md:grid-cols-2 */
@media (min-width: 768px) {
  .grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}

/* Tailwind: lg:p-8 */
@media (min-width: 1024px) {
  .element {
    padding: 2rem;
  }
}

/* Tailwind: xl:max-w-screen-xl */
@media (min-width: 1280px) {
  .element {
    max-width: 1280px;
  }
}
```

## Hover & Focus States

```css
/* Tailwind: hover:bg-blue-600 */
.button:hover {
  background-color: #2563eb;
}

/* Tailwind: focus:ring-2 focus:ring-blue-500 */
.input:focus {
  outline: 2px solid #3b82f6;
  outline-offset: 2px;
}

/* Tailwind: hover:shadow-lg */
.card:hover {
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
}
```

## Usage Tips

1. **Combine related properties**: Group Tailwind classes that affect the same element property
2. **Use CSS variables**: For theme colors and repeated values
3. **Mobile-first**: Apply base styles first, then add media queries for larger screens
4. **Class naming**: Use semantic class names instead of utility classes
5. **Organize CSS**: Group related styles in commented sections
