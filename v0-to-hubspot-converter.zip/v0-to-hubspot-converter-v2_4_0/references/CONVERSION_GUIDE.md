# Universal v0.dev → HubSpot Custom Module Conversion Guide

**Use this guide for ANY v0.dev component conversion.**

---

## 🎯 Purpose & Scope

This guide provides a **universal, repeatable methodology** for converting any v0.dev generated component into a HubSpot custom module. Use it every single time you need to make this conversion, regardless of the component type.

**Applies to:**
- ✅ Cards, grids, and layouts
- ✅ Interactive components (tabs, accordions, toggles)
- ✅ Forms and data entry
- ✅ Timelines and progress indicators
- ✅ Dashboards and data visualization
- ✅ Navigation and menus
- ✅ Any React component from v0.dev

---

## 📋 Quick Start Checklist

Print this and keep it handy:

```
□ Component exported from v0.dev
□ Project Worksheet completed (see below)
□ Icon list created
□ Time estimated
□ HubSpot module folder created
□ Code editor open
□ Browser DevTools ready
□ HubSpot Design Manager open
□ Test page/blog post ready
```

---

## Part 1: Pre-Conversion Assessment

### Project Worksheet

**Fill this out BEFORE starting any conversion:**

```
PROJECT: _______________________________________
DATE: __________________________________________
ESTIMATED TIME: ________________________________

COMPONENT DETAILS:
├─ Component Name: ____________________________
├─ Component Type: ☐ Static ☐ Interactive ☐ Form-based
├─ Primary Purpose: ____________________________
└─ Where will it be used: ☐ Blog ☐ Landing Page ☐ Both

TECHNICAL INVENTORY:
├─ Number of Icons: ______ (× 10 min each = ______ min)
├─ React Hooks Used: 
│  ☐ useState (____ instances × 20 min = ______ min)
│  ☐ useEffect (____ instances × 20 min = ______ min)
│  ☐ useRef (____ instances × 15 min = ______ min)
│  ☐ Other: ________________ × ______ min = ______ min
├─ shadcn/ui Components: ______ (× 15 min each = ______ min)
├─ External Libraries: _____________________________
└─ TypeScript Interfaces: ______ (× 5 min each = ______ min)

COMPLEXITY ASSESSMENT:
☐ Level 1: Static/Presentational (1-2 hours)
   └─ No state, no interactions, pure display
   
☐ Level 2: Simple Interactive (2-4 hours)
   └─ Basic state, clicks, toggles, simple conditionals
   
☐ Level 3: Medium Interactive (4-6 hours)
   └─ Multiple state variables, forms, tabs/accordions
   
☐ Level 4: Complex Interactive (6-10 hours)
   └─ Complex state, API calls, multi-step processes
   
☐ Level 5: Very Complex (10+ hours)
   └─ App-like functionality, consider alternatives

ESTIMATED TOTAL TIME: ______ hours

PLANNED WORK SESSIONS:
Session 1: __________ (Date/Time) - Icons & HTML
Session 2: __________ (Date/Time) - CSS
Session 3: __________ (Date/Time) - JavaScript
Session 4: __________ (Date/Time) - Testing
```

---

## Part 2: Universal Transformation Rules

### The Core Conversion Matrix

| v0.dev Element | HubSpot Equivalent | Transformation Method |
|----------------|-------------------|----------------------|
| **Language & Framework** |
| TypeScript (.tsx) | Vanilla JavaScript (.js) | Remove types, convert syntax |
| React Components | Plain HTML | Flatten component hierarchy |
| JSX Syntax | HTML5 | Convert attributes and structure |
| ES6 Imports/Exports | Single-file code | Remove all imports, inline code |
| **Styling** |
| Tailwind CSS classes | Standard CSS properties | Use conversion tables |
| className attribute | class attribute | Find & replace |
| style={{}} objects | style="" strings | Convert object to string |
| Responsive modifiers (md:, lg:) | @media queries | Create explicit breakpoints |
| **Components & Libraries** |
| shadcn/ui components | Custom HTML elements | Rebuild structure manually |
| Lucide React icons | Inline SVG code | Convert each icon |
| Component props | Static HTML or data-* attributes | Hardcode or use attributes |
| Children props | Nested HTML | Write out nested structure |
| **State & Interactivity** |
| useState hook | JavaScript variables | let/const declarations |
| setState functions | Update functions | Custom update functions |
| useEffect hook | Event listeners | addEventListener |
| useRef hook | DOM queries | querySelector/getElementById |
| Event handlers (onClick, etc.) | addEventListener | Attach in JavaScript |
| Conditional rendering ({condition && <div>}) | CSS display or innerHTML | Hide/show with JS/CSS |
| Array.map() loops | Static HTML | Write out each item |

---

## Part 3: Step-by-Step Conversion Process

### STEP 1: ANALYSIS (10-15 minutes)

**1.1 Create Component Inventory**

Open your v0.dev component and create this inventory:

```markdown
# Component Inventory: [COMPONENT_NAME]

## Imports Used
- [ ] React hooks: _________________________
- [ ] shadcn/ui: _________________________
- [ ] Lucide icons: _________________________
- [ ] Other libraries: _________________________

## Component Structure
```
[Paste simplified structure here]
Container
├─ Header
│  ├─ Title
│  └─ Subtitle
├─ Main Content
│  ├─ Section 1
│  └─ Section 2
└─ Footer
```

## Interactive Elements
- [ ] Buttons: _____ (describe actions)
- [ ] Forms: _____ (list fields)
- [ ] Toggles: _____ (describe states)
- [ ] Tabs: _____ (list tab names)
- [ ] Other: _____

## State Variables
- [ ] Variable 1: __________ (initial value: ______)
- [ ] Variable 2: __________ (initial value: ______)
- [ ] Variable 3: __________ (initial value: ______)

## Data Structures
- [ ] Arrays: _________________________
- [ ] Objects: _________________________
- [ ] Other: _________________________
```

**1.2 Icon Extraction**

Create an icon list:

```markdown
# Icons List: [COMPONENT_NAME]

| Icon Name | Used Where | Size | Color | Priority |
|-----------|-----------|------|-------|----------|
| Example: Search | Header | 20px | #000 | High |
| Example: Settings | Button | 16px | #666 | Medium |
| ___________|___________|______|_______|__________|
| ___________|___________|______|_______|__________|
| ___________|___________|______|_______|__________|

Total Icons: _____
Estimated Time: _____ minutes (× 10 min each)
```

**1.3 Complexity Score**

Calculate your complexity score:

```
Base Score: 10 points

Add points for:
+ Icons (2 points each): _____
+ State hooks (5 points each): _____
+ shadcn components (3 points each): _____
+ Conditional rendering (2 points each): _____
+ Array maps (3 points each): _____
+ Forms (5 points each): _____
+ API calls (10 points each): _____

Total Score: _____

Interpretation:
10-20 points = Simple (1-2 hours)
21-40 points = Medium (2-4 hours)
41-60 points = Complex (4-8 hours)
61+ points = Very Complex (8+ hours, consider alternatives)
```

---

### STEP 2: ICON CONVERSION (Variable time)

**2.1 Icon Conversion Template**

For each icon, follow this process:

```markdown
# Icon: [ICON_NAME]

## Source
Visit: https://lucide.dev/icons/[icon-name-lowercase]

## Copy SVG Code
[Paste raw SVG here]

## Customized Version
```html
<svg 
  class="icon-[purpose]" 
  width="[size]" 
  height="[size]" 
  viewBox="0 0 24 24" 
  fill="none" 
  stroke="[color]" 
  stroke-width="2" 
  stroke-linecap="round" 
  stroke-linejoin="round"
>
  [SVG paths here]
</svg>
```

## Usage in HTML
```html
<div class="icon-container">
  <svg class="icon-[purpose]">...</svg>
  <span>Label text</span>
</div>
```
```

**2.2 Icon Reference File Template**

Create `icons-[project-name].md`:

```markdown
# Icon Reference: [PROJECT_NAME]

## Quick Copy Section

### Icon 1: [NAME]
```html
[SVG code]
```

### Icon 2: [NAME]
```html
[SVG code]
```

[Repeat for all icons...]

## Customization Guide

### Size Variants
- Small: width="14" height="14"
- Medium: width="18" height="18"
- Large: width="24" height="24"

### Color Variants
- Primary: stroke="#[brand-color]"
- Secondary: stroke="#6b7280"
- Success: stroke="#10b981"
- Warning: stroke="#f59e0b"
- Error: stroke="#ef4444"

### Stroke Width
- Thin: stroke-width="1.5"
- Normal: stroke-width="2"
- Bold: stroke-width="2.5"
```

---

### STEP 3: HTML STRUCTURE (1-3 hours)

**3.1 HTML Conversion Worksheet**

```markdown
# HTML Conversion: [COMPONENT_NAME]

## Original JSX Structure
```tsx
[Paste v0.dev JSX here]
```

## Converted HTML Structure
```html
<!-- [COMPONENT_NAME] - module.html -->

<!-- Load external resources -->
{{ require_css("https://fonts.googleapis.com/css2?family=[FONT]&display=swap") }}

<div class="[component-name]-wrapper">
  <!-- Header -->
  <div class="[component-name]-header">
    [Convert header JSX to HTML]
  </div>
  
  <!-- Main Content -->
  <div class="[component-name]-content">
    [Convert content JSX to HTML]
  </div>
  
  <!-- Footer (if applicable) -->
  <div class="[component-name]-footer">
    [Convert footer JSX to HTML]
  </div>
</div>
```

## Conversion Notes
- [ ] All className → class
- [ ] All self-closing tags closed
- [ ] All {variables} replaced with static content or data attributes
- [ ] All icons converted to SVG
- [ ] All conditionals handled
- [ ] All loops expanded
```

**3.2 JSX to HTML Conversion Rules**

Apply these transformations systematically:

```markdown
# Conversion Checklist: JSX → HTML

## Attributes
- [ ] className → class
- [ ] htmlFor → for
- [ ] onClick → remove (handle in JS)
- [ ] onChange → remove (handle in JS)
- [ ] onSubmit → remove (handle in JS)
- [ ] style={{}} → style="" or CSS class

## Dynamic Content
- [ ] {variable} → static text or data attribute
- [ ] {condition && <div>} → write both states
- [ ] {array.map()} → duplicate HTML manually
- [ ] {children} → write nested content

## Component Hierarchy
- [ ] <Component> → <div class="component">
- [ ] Nested components flattened
- [ ] Props removed or converted to data attributes
```

**3.3 Data Attributes Strategy**

When you need to reference elements in JavaScript:

```html
<!-- ✅ GOOD: Use data attributes for JS hooks -->
<button class="tab-btn" data-tab-id="0" data-tab-name="overview">
  Overview
</button>

<div class="stage-card" data-stage-index="1" data-status="complete">
  Content
</div>

<!-- ✅ GOOD: Use for state tracking -->
<div class="accordion-item" data-open="false">
  <button class="accordion-trigger" data-target="item-1">
    Title
  </button>
  <div class="accordion-content" data-item-id="item-1">
    Content
  </div>
</div>

<!-- ❌ BAD: Don't rely on position -->
<button class="tab-btn">Tab 1</button>
<button class="tab-btn">Tab 2</button>
<!-- How do you know which is which in JS? -->
```

---

### STEP 4: CSS CONVERSION (1-3 hours)

**4.1 CSS Conversion Worksheet**

```markdown
# CSS Conversion: [COMPONENT_NAME]

## Tailwind Classes Inventory
List all unique Tailwind classes:
- Container: _________________________
- Layout: _________________________
- Typography: _________________________
- Colors: _________________________
- Spacing: _________________________
- Borders: _________________________
- Effects: _________________________
- Responsive: _________________________

## CSS Structure Plan
```css
/* [COMPONENT_NAME] - module.css */

/* ============================================
   BASE STYLES
   ============================================ */
.[component-name]-wrapper { }

/* ============================================
   HEADER SECTION
   ============================================ */
.[component-name]-header { }

/* ============================================
   CONTENT SECTION
   ============================================ */
.[component-name]-content { }

/* ============================================
   INTERACTIVE ELEMENTS
   ============================================ */
.button { }
.card { }

/* ============================================
   STATE CLASSES
   ============================================ */
.active { }
.disabled { }
.open { }

/* ============================================
   RESPONSIVE BREAKPOINTS
   ============================================ */
@media (min-width: 640px) { }
@media (min-width: 768px) { }
@media (min-width: 1024px) { }
```
```

**4.2 Tailwind → CSS Quick Reference**

```css
/* LAYOUT */
/* Tailwind */ .container { /* CSS */ max-width: 1200px; margin: 0 auto; }
/* Tailwind */ .flex { /* CSS */ display: flex; }
/* Tailwind */ .grid { /* CSS */ display: grid; }
/* Tailwind */ .items-center { /* CSS */ align-items: center; }
/* Tailwind */ .justify-between { /* CSS */ justify-content: space-between; }

/* SPACING (multiply by 0.25rem) */
/* Tailwind */ .p-4 { /* CSS */ padding: 1rem; }
/* Tailwind */ .m-4 { /* CSS */ margin: 1rem; }
/* Tailwind */ .px-4 { /* CSS */ padding-left: 1rem; padding-right: 1rem; }
/* Tailwind */ .py-4 { /* CSS */ padding-top: 1rem; padding-bottom: 1rem; }
/* Tailwind */ .gap-4 { /* CSS */ gap: 1rem; }

/* TYPOGRAPHY */
/* Tailwind */ .text-sm { /* CSS */ font-size: 0.875rem; line-height: 1.25rem; }
/* Tailwind */ .text-base { /* CSS */ font-size: 1rem; line-height: 1.5rem; }
/* Tailwind */ .text-lg { /* CSS */ font-size: 1.125rem; line-height: 1.75rem; }
/* Tailwind */ .text-xl { /* CSS */ font-size: 1.25rem; line-height: 1.75rem; }
/* Tailwind */ .text-2xl { /* CSS */ font-size: 1.5rem; line-height: 2rem; }
/* Tailwind */ .text-3xl { /* CSS */ font-size: 1.875rem; line-height: 2.25rem; }
/* Tailwind */ .font-normal { /* CSS */ font-weight: 400; }
/* Tailwind */ .font-medium { /* CSS */ font-weight: 500; }
/* Tailwind */ .font-semibold { /* CSS */ font-weight: 600; }
/* Tailwind */ .font-bold { /* CSS */ font-weight: 700; }

/* COLORS */
/* Tailwind */ .text-gray-600 { /* CSS */ color: #6b7280; }
/* Tailwind */ .text-blue-600 { /* CSS */ color: #2563eb; }
/* Tailwind */ .bg-white { /* CSS */ background-color: #ffffff; }
/* Tailwind */ .bg-gray-100 { /* CSS */ background-color: #f3f4f6; }

/* BORDERS & RADIUS */
/* Tailwind */ .rounded { /* CSS */ border-radius: 0.25rem; }
/* Tailwind */ .rounded-lg { /* CSS */ border-radius: 0.5rem; }
/* Tailwind */ .border { /* CSS */ border-width: 1px; }
/* Tailwind */ .border-gray-200 { /* CSS */ border-color: #e5e7eb; }

/* EFFECTS */
/* Tailwind */ .shadow { /* CSS */ box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1); }
/* Tailwind */ .shadow-lg { /* CSS */ box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1); }
/* Tailwind */ .transition { /* CSS */ transition: all 0.15s; }

/* RESPONSIVE */
/* Tailwind */ .md:grid-cols-2 { 
  /* CSS */ 
  @media (min-width: 768px) {
    grid-template-columns: repeat(2, 1fr);
  }
}
```

**4.3 CSS Template**

```css
/* ============================================
   [COMPONENT_NAME] MODULE
   Created: [DATE]
   ============================================ */

/* ============================================
   VARIABLES (Optional)
   ============================================ */
:root {
  --component-primary: #2563eb;
  --component-secondary: #64748b;
  --component-spacing: 1rem;
  --component-border-radius: 0.5rem;
}

/* ============================================
   BASE WRAPPER
   ============================================ */
.[component-name]-wrapper {
  box-sizing: border-box;
  width: 100%;
  max-width: 1200px;
  margin: 0 auto;
  padding: 1rem;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
}

.[component-name]-wrapper *,
.[component-name]-wrapper *::before,
.[component-name]-wrapper *::after {
  box-sizing: border-box;
}

/* ============================================
   HEADER SECTION
   ============================================ */
.[component-name]-header {
  /* Add styles */
}

.[component-name]-title {
  /* Add styles */
}

.[component-name]-subtitle {
  /* Add styles */
}

/* ============================================
   CONTENT SECTION
   ============================================ */
.[component-name]-content {
  /* Add styles */
}

/* Grid/Flex layouts */
.[component-name]-grid {
  display: grid;
  grid-template-columns: 1fr;
  gap: 1rem;
}

/* ============================================
   COMPONENTS
   ============================================ */

/* Cards */
.card {
  background: #ffffff;
  border: 1px solid #e5e7eb;
  border-radius: 0.5rem;
  padding: 1.5rem;
}

/* Buttons */
.btn {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem 1rem;
  border: none;
  border-radius: 0.375rem;
  font-weight: 500;
  cursor: pointer;
  transition: background-color 0.2s;
}

.btn-primary {
  background-color: #2563eb;
  color: #ffffff;
}

.btn-primary:hover {
  background-color: #1d4ed8;
}

/* ============================================
   STATE CLASSES
   ============================================ */
.active {
  /* Active state styles */
}

.disabled {
  opacity: 0.5;
  cursor: not-allowed;
  pointer-events: none;
}

.hidden {
  display: none;
}

/* ============================================
   RESPONSIVE BREAKPOINTS
   ============================================ */

/* Small screens (640px and up) */
@media (min-width: 640px) {
  /* Adjust styles for tablets */
}

/* Medium screens (768px and up) */
@media (min-width: 768px) {
  .[component-name]-wrapper {
    padding: 1.5rem;
  }
  
  .[component-name]-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}

/* Large screens (1024px and up) */
@media (min-width: 1024px) {
  .[component-name]-wrapper {
    padding: 2rem;
  }
  
  .[component-name]-grid {
    grid-template-columns: repeat(3, 1fr);
  }
}

/* Extra large screens (1280px and up) */
@media (min-width: 1280px) {
  /* Adjust for very large screens */
}

/* ============================================
   UTILITY CLASSES
   ============================================ */
.visually-hidden {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}
```

---

### STEP 5: JAVASCRIPT CONVERSION (1-4 hours)

**5.1 JavaScript Conversion Worksheet**

```markdown
# JavaScript Conversion: [COMPONENT_NAME]

## State Variables from React
| React State | Initial Value | Purpose | Update Triggers |
|-------------|---------------|---------|-----------------|
| const [var1, setVar1] = useState(init) | init | purpose | triggers |
| ____________|_______________|_________|_________________|
| ____________|_______________|_________|_________________|

## Event Handlers from JSX
| Element | Event Type | Handler Function | What it does |
|---------|-----------|------------------|--------------|
| Button | onClick | handleClick | description |
| ________|___________|__________________|______________|
| ________|___________|__________________|______________|

## DOM Elements to Cache
- [ ] Buttons: _________________________
- [ ] Inputs: _________________________
- [ ] Containers: _________________________
- [ ] Lists: _________________________
```

**5.2 JavaScript Template**

```javascript
/**
 * ============================================
 * [COMPONENT_NAME] MODULE
 * Vanilla JavaScript for HubSpot
 * Created: [DATE]
 * ============================================
 */

(function() {
  'use strict';
  
  // ============================================
  // CONFIGURATION
  // ============================================
  
  const CONFIG = {
    debug: false, // Set to true for console logging
    animationDuration: 300,
    // Add other configuration options
  };
  
  // ============================================
  // STATE MANAGEMENT
  // ============================================
  
  let state = {
    // Example: activeTab: 0,
    // Example: isOpen: false,
    // Add your state variables here
  };
  
  // ============================================
  // DOM ELEMENT REFERENCES
  // ============================================
  
  let elements = {};
  
  /**
   * Cache DOM elements for performance
   */
  function cacheElements() {
    // Cache all elements you'll need
    elements.container = document.querySelector('.[component-name]-wrapper');
    
    // Example cacheing patterns:
    // elements.buttons = document.querySelectorAll('.btn');
    // elements.tabs = document.querySelectorAll('[data-tab-id]');
    // elements.form = document.getElementById('form-id');
    
    if (!elements.container) {
      console.error('[Component Name]: Container not found');
      return false;
    }
    
    return true;
  }
  
  // ============================================
  // STATE UPDATE FUNCTIONS
  // ============================================
  
  /**
   * Update state and trigger UI update
   * @param {Object} updates - State updates to apply
   */
  function updateState(updates) {
    Object.assign(state, updates);
    
    if (CONFIG.debug) {
      console.log('[Component Name] State updated:', state);
    }
    
    // Trigger UI update
    render();
  }
  
  // Example state setters:
  // function setActiveTab(index) {
  //   updateState({ activeTab: index });
  // }
  
  // function toggleOpen() {
  //   updateState({ isOpen: !state.isOpen });
  // }
  
  // ============================================
  // UI UPDATE FUNCTIONS
  // ============================================
  
  /**
   * Main render function - updates UI based on state
   */
  function render() {
    // Update DOM based on current state
    
    // Example patterns:
    // renderActiveTab();
    // renderOpenState();
    // updateButtonStates();
  }
  
  /**
   * Example: Update active tab UI
   */
  // function renderActiveTab() {
  //   elements.tabs.forEach(function(tab, index) {
  //     if (index === state.activeTab) {
  //       tab.classList.add('active');
  //     } else {
  //       tab.classList.remove('active');
  //     }
  //   });
  // }
  
  // ============================================
  // EVENT HANDLERS
  // ============================================
  
  /**
   * Handle button clicks
   * @param {Event} event - Click event
   */
  function handleButtonClick(event) {
    const button = event.currentTarget;
    
    // Your logic here
    
    if (CONFIG.debug) {
      console.log('[Component Name] Button clicked:', button);
    }
  }
  
  /**
   * Handle form submission
   * @param {Event} event - Submit event
   */
  function handleFormSubmit(event) {
    event.preventDefault();
    
    // Get form data
    const formData = new FormData(event.target);
    
    // Your logic here
    
    if (CONFIG.debug) {
      console.log('[Component Name] Form submitted:', Object.fromEntries(formData));
    }
  }
  
  /**
   * Handle input changes
   * @param {Event} event - Input event
   */
  function handleInputChange(event) {
    const input = event.target;
    const value = input.value;
    
    // Your logic here
    
    if (CONFIG.debug) {
      console.log('[Component Name] Input changed:', value);
    }
  }
  
  // ============================================
  // EVENT LISTENER ATTACHMENT
  // ============================================
  
  /**
   * Attach all event listeners
   */
  function attachEventListeners() {
    // Example: Attach button clicks
    // elements.buttons.forEach(function(button) {
    //   button.addEventListener('click', handleButtonClick);
    // });
    
    // Example: Attach form submit
    // if (elements.form) {
    //   elements.form.addEventListener('submit', handleFormSubmit);
    // }
    
    // Example: Attach input changes
    // elements.inputs.forEach(function(input) {
    //   input.addEventListener('input', handleInputChange);
    // });
  }
  
  // ============================================
  // HELPER FUNCTIONS
  // ============================================
  
  /**
   * Example: Find element by data attribute
   * @param {string} attribute - Data attribute name
   * @param {string} value - Attribute value
   * @returns {Element|null}
   */
  function findElementByData(attribute, value) {
    return document.querySelector('[data-' + attribute + '="' + value + '"]');
  }
  
  /**
   * Example: Toggle class on element
   * @param {Element} element - DOM element
   * @param {string} className - Class name to toggle
   */
  function toggleClass(element, className) {
    if (element.classList.contains(className)) {
      element.classList.remove(className);
    } else {
      element.classList.add(className);
    }
  }
  
  // ============================================
  // INITIALIZATION
  // ============================================
  
  /**
   * Initialize the module
   */
  function init() {
    if (CONFIG.debug) {
      console.log('[Component Name] Initializing...');
    }
    
    // Cache DOM elements
    if (!cacheElements()) {
      console.error('[Component Name] Initialization failed - elements not found');
      return;
    }
    
    // Attach event listeners
    attachEventListeners();
    
    // Initial render
    render();
    
    if (CONFIG.debug) {
      console.log('[Component Name] Initialized successfully');
    }
  }
  
  // ============================================
  // ENTRY POINT
  // ============================================
  
  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    // DOM already loaded
    init();
  }
  
})();
```

**5.3 React Hooks → Vanilla JS Patterns**

```javascript
// ============================================
// PATTERN: useState
// ============================================

// React:
const [count, setCount] = useState(0);

// Vanilla JS:
let count = 0;

function setCount(newValue) {
  count = newValue;
  updateCountDisplay(); // Update UI
}

function updateCountDisplay() {
  document.getElementById('count').textContent = count;
}

// ============================================
// PATTERN: useState with Object
// ============================================

// React:
const [form, setForm] = useState({ name: '', email: '' });

// Vanilla JS:
let form = {
  name: '',
  email: ''
};

function updateForm(field, value) {
  form[field] = value;
  // No automatic UI update, do it manually if needed
}

// ============================================
// PATTERN: useEffect (on mount)
// ============================================

// React:
useEffect(() => {
  // Runs once on mount
  fetchData();
}, []);

// Vanilla JS:
function init() {
  fetchData();
}

document.addEventListener('DOMContentLoaded', init);

// ============================================
// PATTERN: useEffect (with dependency)
// ============================================

// React:
useEffect(() => {
  updateDisplay();
}, [count]);

// Vanilla JS:
function setCount(newValue) {
  count = newValue;
  updateDisplay(); // Call manually after state change
}

// ============================================
// PATTERN: useRef
// ============================================

// React:
const inputRef = useRef(null);
inputRef.current.focus();

// Vanilla JS:
const inputElement = document.getElementById('input-id');
inputElement.focus();

// ============================================
// PATTERN: Event Handlers (onClick)
// ============================================

// React:
<button onClick={() => setCount(count + 1)}>
  Click me
</button>

// Vanilla JS:
const button = document.querySelector('.increment-btn');
button.addEventListener('click', function() {
  setCount(count + 1);
});

// ============================================
// PATTERN: Event Handlers (onChange)
// ============================================

// React:
<input 
  value={name}
  onChange={(e) => setName(e.target.value)}
/>

// Vanilla JS:
const input = document.getElementById('name-input');
let name = '';

input.addEventListener('input', function(e) {
  name = e.target.value;
});

// ============================================
// PATTERN: Conditional Rendering
// ============================================

// React:
{isOpen && <div>Content</div>}

// Vanilla JS - Option 1 (CSS):
// HTML: <div class="content" style="display: none;">Content</div>
// JS:
if (isOpen) {
  element.style.display = 'block';
} else {
  element.style.display = 'none';
}

// Vanilla JS - Option 2 (Class):
// CSS: .hidden { display: none; }
// JS:
if (isOpen) {
  element.classList.remove('hidden');
} else {
  element.classList.add('hidden');
}

// ============================================
// PATTERN: Array.map() Rendering
// ============================================

// React:
{items.map((item, index) => (
  <div key={item.id}>{item.name}</div>
))}

// Vanilla JS - Option 1 (Pre-rendered HTML):
// Write all items in HTML, show/hide as needed

// Vanilla JS - Option 2 (Dynamic rendering):
function renderItems() {
  const container = document.getElementById('items-container');
  container.innerHTML = ''; // Clear
  
  items.forEach(function(item, index) {
    const div = document.createElement('div');
    div.textContent = item.name;
    div.setAttribute('data-id', item.id);
    container.appendChild(div);
  });
}
```

---

## Part 4: Common Component Patterns

### Pattern Library

Use these templates for common UI patterns:

#### Pattern 1: Tabs/Stage Selector

**HTML:**
```html
<div class="tabs-container">
  <!-- Tab Buttons -->
  <div class="tabs-list">
    <button class="tab-btn active" data-tab="0">Tab 1</button>
    <button class="tab-btn" data-tab="1">Tab 2</button>
    <button class="tab-btn" data-tab="2">Tab 3</button>
  </div>
  
  <!-- Tab Content -->
  <div class="tabs-content">
    <div class="tab-panel active" data-panel="0">
      <p>Content for Tab 1</p>
    </div>
    <div class="tab-panel" data-panel="1">
      <p>Content for Tab 2</p>
    </div>
    <div class="tab-panel" data-panel="2">
      <p>Content for Tab 3</p>
    </div>
  </div>
</div>
```

**CSS:**
```css
.tabs-list {
  display: flex;
  gap: 0.5rem;
  border-bottom: 2px solid #e5e7eb;
  margin-bottom: 1rem;
}

.tab-btn {
  padding: 0.75rem 1rem;
  background: transparent;
  border: none;
  border-bottom: 2px solid transparent;
  cursor: pointer;
  transition: all 0.2s;
}

.tab-btn:hover {
  background: #f3f4f6;
}

.tab-btn.active {
  border-bottom-color: #2563eb;
  color: #2563eb;
  font-weight: 600;
}

.tab-panel {
  display: none;
}

.tab-panel.active {
  display: block;
}
```

**JavaScript:**
```javascript
(function() {
  let activeTab = 0;
  
  function switchTab(tabIndex) {
    activeTab = tabIndex;
    
    // Update buttons
    document.querySelectorAll('.tab-btn').forEach(function(btn, index) {
      if (index === tabIndex) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });
    
    // Update panels
    document.querySelectorAll('.tab-panel').forEach(function(panel, index) {
      if (index === tabIndex) {
        panel.classList.add('active');
      } else {
        panel.classList.remove('active');
      }
    });
  }
  
  function init() {
    document.querySelectorAll('.tab-btn').forEach(function(btn, index) {
      btn.addEventListener('click', function() {
        switchTab(index);
      });
    });
  }
  
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
```

---

#### Pattern 2: Accordion/Toggle

**HTML:**
```html
<div class="accordion">
  <!-- Item 1 -->
  <div class="accordion-item">
    <button class="accordion-trigger" data-target="item-1">
      <span>Section 1</span>
      <svg class="accordion-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <polyline points="6 9 12 15 18 9"></polyline>
      </svg>
    </button>
    <div class="accordion-content" id="item-1" style="display: none;">
      <p>Content for section 1</p>
    </div>
  </div>
  
  <!-- Item 2 -->
  <div class="accordion-item">
    <button class="accordion-trigger" data-target="item-2">
      <span>Section 2</span>
      <svg class="accordion-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <polyline points="6 9 12 15 18 9"></polyline>
      </svg>
    </button>
    <div class="accordion-content" id="item-2" style="display: none;">
      <p>Content for section 2</p>
    </div>
  </div>
</div>
```

**CSS:**
```css
.accordion {
  border: 1px solid #e5e7eb;
  border-radius: 0.5rem;
  overflow: hidden;
}

.accordion-item {
  border-bottom: 1px solid #e5e7eb;
}

.accordion-item:last-child {
  border-bottom: none;
}

.accordion-trigger {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1rem;
  background: #ffffff;
  border: none;
  cursor: pointer;
  text-align: left;
  font-weight: 500;
  transition: background-color 0.2s;
}

.accordion-trigger:hover {
  background: #f9fafb;
}

.accordion-trigger.open .accordion-icon {
  transform: rotate(180deg);
}

.accordion-icon {
  transition: transform 0.2s;
}

.accordion-content {
  padding: 0 1rem 1rem 1rem;
}
```

**JavaScript:**
```javascript
(function() {
  function toggleAccordion(trigger) {
    const targetId = trigger.getAttribute('data-target');
    const content = document.getElementById(targetId);
    const isOpen = content.style.display !== 'none';
    
    if (isOpen) {
      content.style.display = 'none';
      trigger.classList.remove('open');
    } else {
      content.style.display = 'block';
      trigger.classList.add('open');
    }
  }
  
  function init() {
    document.querySelectorAll('.accordion-trigger').forEach(function(trigger) {
      trigger.addEventListener('click', function() {
        toggleAccordion(trigger);
      });
    });
  }
  
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
```

---

#### Pattern 3: Modal/Dialog

**HTML:**
```html
<!-- Trigger Button -->
<button class="open-modal-btn" data-modal="modal-1">
  Open Modal
</button>

<!-- Modal -->
<div class="modal-overlay" id="modal-1" style="display: none;">
  <div class="modal-content">
    <div class="modal-header">
      <h2>Modal Title</h2>
      <button class="close-modal-btn" data-modal="modal-1">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </button>
    </div>
    <div class="modal-body">
      <p>Modal content goes here</p>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary close-modal-btn" data-modal="modal-1">
        Cancel
      </button>
      <button class="btn btn-primary">
        Confirm
      </button>
    </div>
  </div>
</div>
```

**CSS:**
```css
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 9999;
}

.modal-content {
  background: #ffffff;
  border-radius: 0.5rem;
  max-width: 500px;
  width: 90%;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
}

.modal-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1.5rem;
  border-bottom: 1px solid #e5e7eb;
}

.modal-header h2 {
  margin: 0;
  font-size: 1.5rem;
  font-weight: 600;
}

.close-modal-btn {
  background: transparent;
  border: none;
  padding: 0.5rem;
  cursor: pointer;
  color: #6b7280;
}

.close-modal-btn:hover {
  color: #111827;
}

.modal-body {
  padding: 1.5rem;
}

.modal-footer {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 0.5rem;
  padding: 1.5rem;
  border-top: 1px solid #e5e7eb;
}
```

**JavaScript:**
```javascript
(function() {
  function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.style.display = 'flex';
      document.body.style.overflow = 'hidden'; // Prevent scroll
    }
  }
  
  function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.style.display = 'none';
      document.body.style.overflow = ''; // Restore scroll
    }
  }
  
  function init() {
    // Open modal buttons
    document.querySelectorAll('.open-modal-btn').forEach(function(btn) {
      btn.addEventListener('click', function() {
        const modalId = btn.getAttribute('data-modal');
        openModal(modalId);
      });
    });
    
    // Close modal buttons
    document.querySelectorAll('.close-modal-btn').forEach(function(btn) {
      btn.addEventListener('click', function() {
        const modalId = btn.getAttribute('data-modal');
        closeModal(modalId);
      });
    });
    
    // Close on overlay click
    document.querySelectorAll('.modal-overlay').forEach(function(overlay) {
      overlay.addEventListener('click', function(e) {
        if (e.target === overlay) {
          closeModal(overlay.id);
        }
      });
    });
    
    // Close on Escape key
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay').forEach(function(modal) {
          if (modal.style.display !== 'none') {
            closeModal(modal.id);
          }
        });
      }
    });
  }
  
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
```

---

#### Pattern 4: Card Grid with Filtering

**HTML:**
```html
<div class="card-grid-wrapper">
  <!-- Filter Buttons -->
  <div class="filter-buttons">
    <button class="filter-btn active" data-filter="all">All</button>
    <button class="filter-btn" data-filter="tech">Tech</button>
    <button class="filter-btn" data-filter="design">Design</button>
    <button class="filter-btn" data-filter="business">Business</button>
  </div>
  
  <!-- Card Grid -->
  <div class="card-grid">
    <div class="card" data-category="tech">
      <h3>Tech Card</h3>
      <p>Technology content</p>
    </div>
    <div class="card" data-category="design">
      <h3>Design Card</h3>
      <p>Design content</p>
    </div>
    <div class="card" data-category="business">
      <h3>Business Card</h3>
      <p>Business content</p>
    </div>
    <div class="card" data-category="tech">
      <h3>Another Tech Card</h3>
      <p>More technology content</p>
    </div>
  </div>
</div>
```

**CSS:**
```css
.filter-buttons {
  display: flex;
  gap: 0.5rem;
  margin-bottom: 1.5rem;
  flex-wrap: wrap;
}

.filter-btn {
  padding: 0.5rem 1rem;
  border: 1px solid #e5e7eb;
  border-radius: 0.375rem;
  background: #ffffff;
  cursor: pointer;
  transition: all 0.2s;
}

.filter-btn:hover {
  border-color: #2563eb;
  color: #2563eb;
}

.filter-btn.active {
  background: #2563eb;
  border-color: #2563eb;
  color: #ffffff;
}

.card-grid {
  display: grid;
  grid-template-columns: 1fr;
  gap: 1.5rem;
}

@media (min-width: 768px) {
  .card-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (min-width: 1024px) {
  .card-grid {
    grid-template-columns: repeat(3, 1fr);
  }
}

.card {
  background: #ffffff;
  border: 1px solid #e5e7eb;
  border-radius: 0.5rem;
  padding: 1.5rem;
  transition: opacity 0.3s, transform 0.3s;
}

.card.hidden {
  display: none;
}

.card h3 {
  margin: 0 0 0.5rem 0;
  font-size: 1.25rem;
  font-weight: 600;
}

.card p {
  margin: 0;
  color: #6b7280;
}
```

**JavaScript:**
```javascript
(function() {
  let activeFilter = 'all';
  
  function filterCards(category) {
    activeFilter = category;
    
    // Update button states
    document.querySelectorAll('.filter-btn').forEach(function(btn) {
      const btnFilter = btn.getAttribute('data-filter');
      if (btnFilter === category) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });
    
    // Filter cards
    document.querySelectorAll('.card').forEach(function(card) {
      const cardCategory = card.getAttribute('data-category');
      
      if (category === 'all' || cardCategory === category) {
        card.classList.remove('hidden');
      } else {
        card.classList.add('hidden');
      }
    });
  }
  
  function init() {
    document.querySelectorAll('.filter-btn').forEach(function(btn) {
      btn.addEventListener('click', function() {
        const filter = btn.getAttribute('data-filter');
        filterCards(filter);
      });
    });
  }
  
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
```

---

## Part 5: Testing & Deployment

### Testing Checklist

```markdown
# Testing Checklist: [COMPONENT_NAME]

## HTML Validation
- [ ] All tags properly closed
- [ ] No JSX syntax remaining
- [ ] All icons converted to SVG
- [ ] Data attributes correct
- [ ] Semantic HTML used

## CSS Validation
- [ ] No Tailwind classes remaining
- [ ] All colors defined
- [ ] Responsive breakpoints work
- [ ] Hover states defined
- [ ] Transitions smooth
- [ ] Cross-browser compatible

## JavaScript Validation
- [ ] No React imports
- [ ] No TypeScript syntax
- [ ] All variables declared
- [ ] Event listeners attached
- [ ] State management works
- [ ] No console errors
- [ ] Wrapped in IIFE

## Functionality Testing
- [ ] All buttons work
- [ ] All interactions work
- [ ] State updates correctly
- [ ] Forms submit (if applicable)
- [ ] Navigation works (if applicable)

## Browser Testing
- [ ] Chrome (latest)
- [ ] Safari (latest)
- [ ] Firefox (latest)
- [ ] Edge (latest)
- [ ] Mobile Chrome
- [ ] Mobile Safari

## Responsive Testing
- [ ] Mobile (< 640px)
- [ ] Tablet (640px - 1024px)
- [ ] Desktop (> 1024px)
- [ ] All breakpoints smooth

## Accessibility Testing
- [ ] Keyboard navigation works
- [ ] Focus states visible
- [ ] Alt text on images
- [ ] ARIA labels (if needed)
- [ ] Color contrast meets WCAG AA
- [ ] Screen reader friendly

## HubSpot Integration
- [ ] Module created in Design Manager
- [ ] All three files uploaded
- [ ] Preview works
- [ ] Published successfully
- [ ] Works in blog post
- [ ] Works in landing page
- [ ] No conflicts with other modules
```

### Deployment Checklist

```markdown
# Deployment: [COMPONENT_NAME]

## Pre-Deployment
- [ ] All testing complete
- [ ] Documentation updated
- [ ] Module name finalized
- [ ] Files backed up

## HubSpot Setup
- [ ] Navigate to Design Manager
- [ ] Create new module
- [ ] Select content types (blog/landing page)
- [ ] Set module name
- [ ] Upload module.html
- [ ] Upload module.css
- [ ] Upload module.js
- [ ] Save draft

## Testing in HubSpot
- [ ] Click "Preview"
- [ ] Check for errors in browser console
- [ ] Test all interactions
- [ ] Verify responsive design
- [ ] Check in different browsers

## Publishing
- [ ] Click "Publish changes"
- [ ] Create test blog post
- [ ] Add module to post
- [ ] Preview blog post
- [ ] Publish blog post
- [ ] View live page
- [ ] Final verification

## Post-Deployment
- [ ] Document in project log
- [ ] Add to module library
- [ ] Share with team (if applicable)
- [ ] Archive source files
```

---

## Part 6: Troubleshooting

### Common Issues Reference

```markdown
# Troubleshooting: [COMPONENT_NAME]

## Issue Log

### Issue #1: [Description]
**Symptom:** ______________________________
**Cause:** ________________________________
**Solution:** ______________________________
**Prevention:** ____________________________

### Issue #2: [Description]
**Symptom:** ______________________________
**Cause:** ________________________________
**Solution:** ______________________________
**Prevention:** ____________________________
```

### Quick Fixes

| Problem | Likely Cause | Quick Fix |
|---------|-------------|-----------|
| Module shows blank | Missing content in HTML | Check module.html has content |
| CSS not working | Low specificity | Add wrapper class to all selectors |
| JS not running | Missing DOMContentLoaded | Wrap code in event listener |
| Icons show as empty boxes | Invalid SVG | Re-copy SVG from lucide.dev |
| Layout broken on mobile | No media queries | Add responsive breakpoints |
| Buttons not clickable | Z-index issue | Check stacking context |
| Colors not showing | Invalid color values | Use valid hex/rgb values |
| Multiple modules conflict | Global selectors | Use unique class prefixes |
| State not updating | Forgot to call render | Call updateUI() after state change |
| Memory leaks | Event listeners not removed | Use proper event delegation |

---

## Part 7: Project Documentation

### Conversion Log Template

```markdown
# Conversion Log: [COMPONENT_NAME]

## Project Info
- **Component Name:** ______________________
- **Source:** v0.dev
- **Destination:** HubSpot Custom Module
- **Start Date:** __________________________
- **Completion Date:** _____________________
- **Total Time:** __________________________

## Time Breakdown
- Analysis: ________ minutes
- Icon Conversion: ________ minutes
- HTML Structure: ________ minutes
- CSS Styling: ________ minutes
- JavaScript: ________ minutes
- Testing: ________ minutes
- Deployment: ________ minutes

**Total Actual:** ________ minutes
**Estimated:** ________ minutes
**Variance:** ________ minutes (_____ %)

## Complexity Assessment
- Complexity Level: ☐ 1 ☐ 2 ☐ 3 ☐ 4 ☐ 5
- Complexity Score: ________ points

## Components Converted
- Icons: ________ (list: __________________)
- State Variables: ________ (list: __________)
- Event Handlers: ________ (list: ___________)
- shadcn Components: ________ (list: ______)

## Challenges Encountered
1. ________________________________________
   Solution: ________________________________

2. ________________________________________
   Solution: ________________________________

## Key Learnings
1. ________________________________________
2. ________________________________________
3. ________________________________________

## Reusable Patterns Created
1. ________________________________________
2. ________________________________________

## Next Time Improvements
1. ________________________________________
2. ________________________________________

## Files Created
- module.html (_____ lines)
- module.css (_____ lines)
- module.js (_____ lines)

## Testing Notes
- Browsers Tested: _______________________
- Devices Tested: ________________________
- Issues Found: __________________________
- All Resolved: ☐ Yes ☐ No

## Deployment Info
- HubSpot Module URL: ____________________
- Test Page URL: _________________________
- Live Page URL: _________________________

## Status
☐ In Progress
☐ Testing
☐ Complete
☐ Deployed
☐ Archived
```

---

## Part 8: Quick Reference Cards

### Conversion Speed Reference

Print and keep at your desk:

```
┌──────────────────────────────────────────────┐
│     v0.dev → HubSpot Quick Reference         │
├──────────────────────────────────────────────┤
│                                              │
│  SYNTAX CHANGES                              │
│  ├─ className → class                        │
│  ├─ {var} → static or data-*                 │
│  ├─ onClick → addEventListener               │
│  └─ style={{}} → style="" or CSS            │
│                                              │
│  TIME ESTIMATES                              │
│  ├─ Icon conversion: 10 min each             │
│  ├─ State hook: 20 min each                  │
│  ├─ shadcn component: 15 min each            │
│  └─ HTML/CSS/JS: 1-3 hours each              │
│                                              │
│  COMPLEXITY LEVELS                           │
│  ├─ Level 1 (Static): 1-2 hours              │
│  ├─ Level 2 (Simple): 2-4 hours              │
│  ├─ Level 3 (Medium): 4-6 hours              │
│  ├─ Level 4 (Complex): 6-10 hours            │
│  └─ Level 5 (Very Complex): 10+ hours        │
│                                              │
│  TESTING CHECKLIST                           │
│  ├─ [ ] HTML validated                       │
│  ├─ [ ] CSS validated                        │
│  ├─ [ ] JS no errors                         │
│  ├─ [ ] Mobile works                         │
│  ├─ [ ] Desktop works                        │
│  └─ [ ] All browsers tested                  │
│                                              │
└──────────────────────────────────────────────┘
```

### Tailwind → CSS Quick Lookup

```
┌──────────────────────────────────────────────┐
│       Tailwind to CSS Cheat Sheet            │
├──────────────────────────────────────────────┤
│                                              │
│  LAYOUT                                      │
│  flex         → display: flex                │
│  grid         → display: grid                │
│  block        → display: block               │
│  hidden       → display: none                │
│                                              │
│  SPACING (multiply by 0.25rem)              │
│  p-4          → padding: 1rem                │
│  m-4          → margin: 1rem                 │
│  px-4         → padding-left/right: 1rem     │
│  gap-4        → gap: 1rem                    │
│                                              │
│  TYPOGRAPHY                                  │
│  text-sm      → font-size: 0.875rem          │
│  text-base    → font-size: 1rem              │
│  text-lg      → font-size: 1.125rem          │
│  text-xl      → font-size: 1.25rem           │
│  text-2xl     → font-size: 1.5rem            │
│  text-3xl     → font-size: 1.875rem          │
│  font-bold    → font-weight: 700             │
│                                              │
│  COLORS                                      │
│  text-gray-600 → color: #6b7280              │
│  text-blue-600 → color: #2563eb              │
│  bg-white     → background: #ffffff          │
│  bg-gray-100  → background: #f3f4f6          │
│                                              │
│  BORDERS                                     │
│  rounded      → border-radius: 0.25rem       │
│  rounded-lg   → border-radius: 0.5rem        │
│  border       → border-width: 1px            │
│                                              │
│  RESPONSIVE                                  │
│  sm:          → @media (min-width: 640px)    │
│  md:          → @media (min-width: 768px)    │
│  lg:          → @media (min-width: 1024px)   │
│                                              │
└──────────────────────────────────────────────┘
```

---

## Part 9: Building Your Library

### Personal Pattern Library Structure

Create this folder structure for reusable code:

```
my-hubspot-library/
├── README.md (this guide)
├── templates/
│   ├── module.html (blank template)
│   ├── module.css (blank template with structure)
│   └── module.js (blank template with IIFE)
├── patterns/
│   ├── tabs.md (complete tab pattern)
│   ├── accordion.md (complete accordion pattern)
│   ├── modal.md (complete modal pattern)
│   ├── cards.md (complete card patterns)
│   └── forms.md (complete form patterns)
├── icons/
│   ├── all-icons.md (master icon reference)
│   └── project-icons/ (per-project icon files)
├── css-snippets/
│   ├── buttons.css
│   ├── cards.css
│   ├── forms.css
│   ├── grids.css
│   └── utilities.css
├── js-snippets/
│   ├── state-management.js
│   ├── event-handlers.js
│   ├── dom-helpers.js
│   └── animation-helpers.js
├── checklists/
│   ├── pre-conversion.md
│   ├── testing.md
│   └── deployment.md
└── logs/
    ├── project-1-log.md
    ├── project-2-log.md
    └── lessons-learned.md
```

### Pattern Documentation Template

For each reusable pattern:

```markdown
# Pattern: [PATTERN_NAME]

## Description
[What this pattern does and when to use it]

## Complexity
Level: ☐ Simple ☐ Medium ☐ Complex
Time: ________ minutes

## Dependencies
- Icons: [list]
- External libraries: [list]
- Prerequisites: [list]

## HTML Structure
```html
[Complete HTML code]
```

## CSS Styling
```css
[Complete CSS code]
```

## JavaScript
```javascript
[Complete JavaScript code]
```

## Customization Options
1. ________________________________________
2. ________________________________________
3. ________________________________________

## Usage Example
[How to implement this pattern]

## Browser Support
- Chrome: ✅
- Safari: ✅
- Firefox: ✅
- Edge: ✅

## Accessibility Notes
[Accessibility considerations]

## Version History
- v1.0 (Date): Initial version
```

---

## Part 10: Continuous Improvement

### After Each Conversion

Complete this reflection:

```markdown
# Post-Conversion Reflection: [COMPONENT_NAME]

## What Went Well?
1. ________________________________________
2. ________________________________________
3. ________________________________________

## What Was Challenging?
1. ________________________________________
2. ________________________________________
3. ________________________________________

## Time Accuracy
- Estimated: ________ hours
- Actual: ________ hours
- Variance: ________ hours
- Reason for variance: _____________________

## New Patterns Created
1. ________________________________________
2. ________________________________________

## Reusable Code Generated
- CSS snippets: ____________________________
- JS functions: ____________________________
- Icon sets: _______________________________

## Process Improvements for Next Time
1. ________________________________________
2. ________________________________________
3. ________________________________________

## Knowledge Gained
1. ________________________________________
2. ________________________________________
3. ________________________________________

## Next Conversion Will Be Faster Because:
1. ________________________________________
2. ________________________________________
3. ________________________________________
```

---

## Appendix: Full Workflow Diagram

```
START: v0.dev Component
│
├─ STEP 1: ANALYSIS (10-15 min)
│  ├─ Fill out Project Worksheet
│  ├─ Create Component Inventory
│  ├─ Extract Icon List
│  ├─ Calculate Complexity Score
│  └─ Estimate Total Time
│
├─ STEP 2: ICON CONVERSION (Variable)
│  ├─ Visit lucide.dev for each icon
│  ├─ Copy SVG code
│  ├─ Create Icon Reference File
│  └─ Customize sizes/colors
│
├─ STEP 3: HTML STRUCTURE (1-3 hours)
│  ├─ Convert JSX to HTML
│  ├─ className → class
│  ├─ Replace icons with SVG
│  ├─ Flatten component hierarchy
│  ├─ Expand loops manually
│  ├─ Handle conditionals
│  └─ Add data attributes
│
├─ STEP 4: CSS CONVERSION (1-3 hours)
│  ├─ List all Tailwind classes
│  ├─ Convert to standard CSS
│  ├─ Organize by section
│  ├─ Add responsive breakpoints
│  ├─ Define hover states
│  └─ Test in browser
│
├─ STEP 5: JAVASCRIPT (1-4 hours)
│  ├─ Remove React/TypeScript
│  ├─ Convert state hooks
│  ├─ Create update functions
│  ├─ Attach event listeners
│  ├─ Wrap in IIFE
│  └─ Test functionality
│
├─ STEP 6: TESTING (15-30 min)
│  ├─ Validate HTML
│  ├─ Validate CSS
│  ├─ Check JavaScript
│  ├─ Test responsive
│  ├─ Test browsers
│  └─ Check accessibility
│
├─ STEP 7: HUBSPOT DEPLOYMENT (10-15 min)
│  ├─ Create module in Design Manager
│  ├─ Upload three files
│  ├─ Preview
│  ├─ Publish
│  └─ Test in blog post
│
└─ STEP 8: DOCUMENTATION (10-15 min)
   ├─ Complete conversion log
   ├─ Update pattern library
   ├─ Post-conversion reflection
   └─ Archive source files

END: Working HubSpot Custom Module
```

---

## Summary & Quick Start

### Your First Conversion (Follow This Order):

1. **Read this guide** (30 minutes)
2. **Print the checklists** (Project Worksheet, Testing Checklist)
3. **Download your v0.dev component**
4. **Complete the Project Worksheet** (10 minutes)
5. **Follow Steps 1-8 systematically**
6. **Document everything in the Conversion Log**
7. **Build your pattern library from day one**

### Success Metrics:

- ✅ First conversion: 8-12 hours
- ✅ Third conversion: 5-8 hours
- ✅ Fifth conversion: 3-5 hours
- ✅ Tenth conversion: 2-3 hours

**Your conversion time will decrease by ~30-50% every 2-3 projects as you build your library.**

---

## Final Checklist

Before considering this guide complete:

```
- [ ] Guide downloaded and saved
- [ ] Checklists printed
- [ ] Folder structure created
- [ ] Templates saved
- [ ] Icon reference started
- [ ] Pattern library initiated
- [ ] First conversion planned
- [ ] Team informed (if applicable)
```

---

**This guide is a living document. Update it as you learn!**

*Created: [DATE]*  
*Last Updated: [DATE]*  
*Version: 1.0*  
*Your Name: _______________*
