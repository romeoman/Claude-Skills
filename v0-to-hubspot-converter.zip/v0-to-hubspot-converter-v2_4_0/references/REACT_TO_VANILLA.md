# React to Vanilla JavaScript Conversion Guide

## Overview

This reference provides comprehensive patterns for converting React components and hooks to vanilla JavaScript. Use this when transforming v0.dev React code to HubSpot-compatible JavaScript.

## State Management

### useState Hook

**React Pattern:**
```javascript
const [count, setCount] = useState(0);
const [isOpen, setIsOpen] = useState(false);
const [items, setItems] = useState([]);
```

**Vanilla JS Pattern:**
```javascript
let state = {
  count: 0,
  isOpen: false,
  items: []
};

function updateState(updates) {
  Object.assign(state, updates);
  render(); // Trigger UI update
}

// Specific setters
function setCount(newCount) {
  updateState({ count: newCount });
}

function setIsOpen(value) {
  updateState({ isOpen: value });
}

function setItems(newItems) {
  updateState({ items: newItems });
}
```

### useState with Objects

**React Pattern:**
```javascript
const [user, setUser] = useState({
  name: '',
  email: '',
  age: 0
});

// Update single property
setUser({...user, name: 'John'});
```

**Vanilla JS Pattern:**
```javascript
let state = {
  user: {
    name: '',
    email: '',
    age: 0
  }
};

function updateUser(updates) {
  state.user = {...state.user, ...updates};
  render();
}

// Usage
updateUser({ name: 'John' });
```

## Effects & Lifecycle

### useEffect Hook

**React Pattern:**
```javascript
// On mount only
useEffect(() => {
  console.log('Component mounted');
  return () => console.log('Component unmounted');
}, []);

// With dependencies
useEffect(() => {
  console.log('Count changed:', count);
}, [count]);
```

**Vanilla JS Pattern:**
```javascript
// On mount (in init function)
function init() {
  console.log('Component mounted');
  // Setup code here
}

// For cleanup, store references
let cleanupFunctions = [];

function addCleanup(fn) {
  cleanupFunctions.push(fn);
}

// Call from state setters for dependency effects
function setCount(newCount) {
  const oldCount = state.count;
  state.count = newCount;
  if (oldCount !== newCount) {
    console.log('Count changed:', newCount);
    render();
  }
}
```

### useRef Hook

**React Pattern:**
```javascript
const inputRef = useRef(null);

<input ref={inputRef} />

// Access: inputRef.current.focus();
```

**Vanilla JS Pattern:**
```javascript
let elements = {
  input: null
};

function cacheElements() {
  elements.input = document.querySelector('#input-id');
}

// Access: elements.input.focus();
```

## Event Handling

### onClick Events

**React Pattern:**
```javascript
function handleClick(event) {
  console.log('Clicked');
}

<button onClick={handleClick}>Click me</button>
```

**Vanilla JS Pattern:**
```javascript
function handleClick(event) {
  console.log('Clicked');
}

function attachEventListeners() {
  elements.button.addEventListener('click', handleClick);
}
```

### onChange Events

**React Pattern:**
```javascript
function handleChange(event) {
  setValue(event.target.value);
}

<input onChange={handleChange} />
```

**Vanilla JS Pattern:**
```javascript
function handleChange(event) {
  setValue(event.target.value);
}

function attachEventListeners() {
  elements.input.addEventListener('input', handleChange);
}
```

### onSubmit Events

**React Pattern:**
```javascript
function handleSubmit(event) {
  event.preventDefault();
  console.log('Submitted');
}

<form onSubmit={handleSubmit}>...</form>
```

**Vanilla JS Pattern:**
```javascript
function handleSubmit(event) {
  event.preventDefault();
  console.log('Submitted');
}

function attachEventListeners() {
  elements.form.addEventListener('submit', handleSubmit);
}
```

## Conditional Rendering

### Simple Conditional

**React Pattern:**
```javascript
{isOpen && <div>Content</div>}
```

**Vanilla JS Pattern:**
```javascript
// Option 1: CSS (preferred for simple show/hide)
<div class="content" style="display: none;">Content</div>

function render() {
  elements.content.style.display = state.isOpen ? 'block' : 'none';
}

// Option 2: Adding/removing classes
function render() {
  if (state.isOpen) {
    elements.content.classList.remove('hidden');
  } else {
    elements.content.classList.add('hidden');
  }
}
```

### Ternary Conditional

**React Pattern:**
```javascript
{isLoggedIn ? <UserMenu /> : <LoginButton />}
```

**Vanilla JS Pattern:**
```javascript
// Both elements in HTML with CSS control
<div class="user-menu hidden">User Menu</div>
<div class="login-button hidden">Login</div>

function render() {
  if (state.isLoggedIn) {
    elements.userMenu.classList.remove('hidden');
    elements.loginButton.classList.add('hidden');
  } else {
    elements.userMenu.classList.add('hidden');
    elements.loginButton.classList.remove('hidden');
  }
}
```

### Multiple Conditions

**React Pattern:**
```javascript
{status === 'loading' && <Spinner />}
{status === 'error' && <Error />}
{status === 'success' && <Content />}
```

**Vanilla JS Pattern:**
```javascript
function render() {
  // Hide all first
  elements.spinner.classList.add('hidden');
  elements.error.classList.add('hidden');
  elements.content.classList.add('hidden');
  
  // Show current
  switch(state.status) {
    case 'loading':
      elements.spinner.classList.remove('hidden');
      break;
    case 'error':
      elements.error.classList.remove('hidden');
      break;
    case 'success':
      elements.content.classList.remove('hidden');
      break;
  }
}
```

## List Rendering

### Array.map()

**React Pattern:**
```javascript
{items.map((item, index) => (
  <div key={index}>
    <h3>{item.title}</h3>
    <p>{item.description}</p>
  </div>
))}
```

**Vanilla JS Pattern:**
```javascript
// Option 1: Pre-written HTML (simpler, preferred for static lists)
<div class="item" data-index="0">
  <h3>Item 1</h3>
  <p>Description 1</p>
</div>
<div class="item" data-index="1">
  <h3>Item 2</h3>
  <p>Description 2</p>
</div>

// Option 2: Dynamic generation (for truly dynamic lists)
function renderItems() {
  const html = state.items.map((item, index) => `
    <div class="item" data-index="${index}">
      <h3>${item.title}</h3>
      <p>${item.description}</p>
    </div>
  `).join('');
  
  elements.container.innerHTML = html;
}
```

## Component Communication

### Props Passing

**React Pattern:**
```javascript
<ChildComponent title="Hello" onClick={handleClick} />

function ChildComponent({ title, onClick }) {
  return <button onClick={onClick}>{title}</button>;
}
```

**Vanilla JS Pattern:**
```javascript
// Use data attributes in HTML
<button class="child-btn" data-title="Hello">Hello</button>

// Access in JS
function handleChildClick(event) {
  const title = event.currentTarget.dataset.title;
  console.log(title);
}
```

### Context/Global State

**React Pattern:**
```javascript
const ThemeContext = React.createContext('light');

function App() {
  return (
    <ThemeContext.Provider value={theme}>
      <Component />
    </ThemeContext.Provider>
  );
}
```

**Vanilla JS Pattern:**
```javascript
// Use module-level state
const globalState = {
  theme: 'light',
  user: null
};

// Access from any function
function updateTheme(newTheme) {
  globalState.theme = newTheme;
  render();
}
```

## Common Patterns

### Toggle Pattern

**React Pattern:**
```javascript
const [isOpen, setIsOpen] = useState(false);

function toggleOpen() {
  setIsOpen(!isOpen);
}

<button onClick={toggleOpen}>Toggle</button>
```

**Vanilla JS Pattern:**
```javascript
let state = { isOpen: false };

function toggleOpen() {
  state.isOpen = !state.isOpen;
  render();
}

elements.toggleBtn.addEventListener('click', toggleOpen);
```

### Tab Pattern

**React Pattern:**
```javascript
const [activeTab, setActiveTab] = useState(0);

<button onClick={() => setActiveTab(0)}>Tab 1</button>
<button onClick={() => setActiveTab(1)}>Tab 2</button>
```

**Vanilla JS Pattern:**
```javascript
let state = { activeTab: 0 };

function setActiveTab(index) {
  state.activeTab = index;
  renderTabs();
}

function renderTabs() {
  // Update button states
  elements.tabButtons.forEach((btn, index) => {
    if (index === state.activeTab) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });
  
  // Update content visibility
  elements.tabContents.forEach((content, index) => {
    if (index === state.activeTab) {
      content.classList.remove('hidden');
    } else {
      content.classList.add('hidden');
    }
  });
}

// Attach listeners
elements.tabButtons.forEach((btn, index) => {
  btn.addEventListener('click', () => setActiveTab(index));
});
```

### Form Pattern

**React Pattern:**
```javascript
const [formData, setFormData] = useState({
  name: '',
  email: ''
});

function handleChange(e) {
  setFormData({
    ...formData,
    [e.target.name]: e.target.value
  });
}

function handleSubmit(e) {
  e.preventDefault();
  console.log(formData);
}
```

**Vanilla JS Pattern:**
```javascript
let state = {
  formData: {
    name: '',
    email: ''
  }
};

function handleChange(event) {
  const { name, value } = event.target;
  state.formData[name] = value;
}

function handleSubmit(event) {
  event.preventDefault();
  console.log(state.formData);
  
  // Or use FormData API
  const formData = new FormData(event.target);
  const data = Object.fromEntries(formData);
  console.log(data);
}

elements.form.addEventListener('submit', handleSubmit);
```

### Accordion Pattern

**React Pattern:**
```javascript
const [openIndex, setOpenIndex] = useState(null);

function toggleAccordion(index) {
  setOpenIndex(openIndex === index ? null : index);
}
```

**Vanilla JS Pattern:**
```javascript
let state = { openIndex: null };

function toggleAccordion(index) {
  state.openIndex = state.openIndex === index ? null : index;
  renderAccordion();
}

function renderAccordion() {
  elements.accordionItems.forEach((item, index) => {
    if (index === state.openIndex) {
      item.classList.add('open');
    } else {
      item.classList.remove('open');
    }
  });
}
```

## Complete Module Template

```javascript
/**
 * Component Name Module
 */
(function() {
  'use strict';
  
  // ========== STATE ==========
  let state = {
    // Define initial state
  };
  
  // ========== DOM CACHE ==========
  let elements = {};
  
  function cacheElements() {
    elements.container = document.querySelector('.component-wrapper');
    // Cache other elements
    return elements.container !== null;
  }
  
  // ========== STATE UPDATES ==========
  function updateState(updates) {
    Object.assign(state, updates);
    render();
  }
  
  // ========== RENDERING ==========
  function render() {
    // Update UI based on state
  }
  
  // ========== EVENT HANDLERS ==========
  function handleClick(event) {
    // Handle clicks
  }
  
  function attachEventListeners() {
    // Attach all listeners
    elements.button.addEventListener('click', handleClick);
  }
  
  // ========== INITIALIZATION ==========
  function init() {
    if (!cacheElements()) {
      console.error('Component elements not found');
      return;
    }
    attachEventListeners();
    render();
  }
  
  // ========== ENTRY POINT ==========
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
  
})();
```

## Best Practices

1. **Use IIFE**: Wrap code in immediately invoked function expression for scope isolation
2. **Cache DOM queries**: Store element references in `elements` object
3. **Centralize state**: Keep all state in one `state` object
4. **Single render function**: Update all UI from one render function
5. **Event delegation**: Use for dynamic content
6. **Data attributes**: Use for element identification and data storage
7. **Consistent naming**: Follow same naming conventions as React code
8. **Comments**: Document complex logic and state transitions
