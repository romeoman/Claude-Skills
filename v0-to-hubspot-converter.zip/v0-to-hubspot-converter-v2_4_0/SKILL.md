---
name: v0-to-hubspot-converter
description: Comprehensive conversion of v0.dev React/TypeScript components to HubSpot custom modules. Transforms React JSX, TypeScript, and shadcn/ui components into HubSpot-compatible HTML with modern native CSS and vanilla JavaScript. Uses ONLY Heroicons inline SVG (copied directly from heroicons.com). Outputs as a single Markdown artifact with copy-pasteable code blocks for easy integration into HubSpot. Use when converting any v0.dev generated component, or when creating HubSpot custom modules from React applications. Handles static components, interactive elements (tabs, accordions, forms), state management, and responsive designs with proper blog embedding support.
---

# v0.dev to HubSpot Custom Module Converter

## Overview

This skill provides a systematic methodology for converting v0.dev generated React/TypeScript components into HubSpot custom modules. The conversion process transforms modern React code and outputs a **single Markdown artifact** containing three code blocks (HTML, CSS, JavaScript) that you can easily copy-paste into HubSpot's module system.

**Output Format**: All conversions are delivered as a Markdown artifact in Claude's interface (not as files in Docker). This allows you to simply open the artifact and copy each code block directly into HubSpot Design Manager.

## 🚨 CRITICAL OUTPUT INSTRUCTIONS

**ALWAYS output as a Markdown artifact. NEVER create files in Docker.**

- ✅ DO: Create ONE Markdown artifact with three code blocks (HTML, CSS, JS)
- ✅ DO: Use proper markdown formatting with code fences
- ✅ DO: Include complete, copy-paste ready code in each block
- ❌ DON'T: Create files using `create_file` or save to Docker filesystem
- ❌ DON'T: Output code blocks in the chat thread
- ❌ DON'T: Ask the user where to save files

The user should be able to open the artifact in Claude's sidebar and copy-paste each code block directly into HubSpot Design Manager without any additional processing.

## When to Use This Skill

Use this skill when:
- Converting v0.dev components to HubSpot modules
- Creating HubSpot custom modules from React applications
- Transforming TypeScript/JSX into vanilla JavaScript
- Converting React components to modern native CSS
- Using Heroicons inline SVG (copied from heroicons.com)
- Building responsive, interactive HubSpot modules
- Embedding modules cleanly inside blog posts (desktop & mobile)

## Modern Native CSS Approach

**Why native CSS**: HubSpot Design Manager works perfectly with modern CSS features without any frameworks or build tools. This approach gives you better performance, no external dependencies, and full browser support.

### Core Modern CSS Features

**CSS Grid & Flexbox**

The foundation for all layouts:[1]

```css
/* Flexbox for one-dimensional layouts */
.container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 1rem;
}

/* CSS Grid for two-dimensional layouts */
.grid-container {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
}
```

**CSS Custom Properties (Variables)**

Make your styles maintainable and dynamic. **IMPORTANT:** In HubSpot modules, always scope variables to your module wrapper, never to `:root`:[2]

```css
/* CORRECT: Scoped to module wrapper */
.module-wrapper {
  --primary-color: #6b5cff;
  --spacing-unit: 1.5rem;
  --border-radius: 8px;
}

.card {
  background: var(--primary-color);
  padding: var(--spacing-unit);
  border-radius: var(--border-radius);
}
```

**Why not `:root`?** Blog posts already define `:root` variables, and your module variables would conflict with them. Scoping to `.module-wrapper` keeps everything isolated.

**Modern CSS Functions**

Responsive sizing without media queries:[3]

```css
.responsive-text {
  /* Fluid typography that scales between min and max */
  font-size: clamp(1rem, 2vw, 2rem);
}

.flexible-width {
  /* Takes the minimum of two values */
  width: min(100%, 1200px);
  padding: max(1rem, 3vw);
}
```

**CSS Nesting**

Cleaner, more organized CSS:[4]

```css
.card {
  padding: 2rem;
  background: white;
  
  & h2 {
    color: #333;
    margin-bottom: 1rem;
  }
  
  & p {
    color: #666;
    line-height: 1.6;
  }
  
  &:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  }
}
```

**Modern Selectors**

More powerful targeting without JavaScript:[5]

```css
/* :has() - parent selector */
.card:has(img) {
  display: grid;
  grid-template-columns: 200px 1fr;
}

/* :is() - grouping selector */
:is(h1, h2, h3) {
  font-family: 'Georgia', serif;
  color: var(--heading-color);
}

/* :where() - zero specificity grouping */
:where(.btn, .button, .cta) {
  padding: 0.75rem 1.5rem;
  border-radius: 4px;
}
```

For comprehensive modern CSS guidance, see `references/MODERN_CSS_GUIDE.md`.

## ⚠️ CRITICAL: Heroicons Icon Implementation

**ALWAYS use Heroicons inline SVG - this is the ONLY approach that works reliably in HubSpot.**

### Why Inline SVG is Mandatory

**Icon fonts DON'T work because:**
- ❌ Requires hosting font files in HubSpot File Manager
- ❌ Complex @font-face setup prone to path errors
- ❌ Character code mapping (\e900, \e901, etc.) is fragile
- ❌ Breaks if font file path changes
- ❌ Not practical in HubSpot's environment

**Inline SVG DOES work because:**
- ✅ No setup required - works immediately
- ✅ No external files - no hosting dependencies
- ✅ Blog-safe - guaranteed compatibility
- ✅ Professional quality - clean, crisp at any size
- ✅ Proven in production - all working modules use this

### How to Get Correct Heroicons SVG

**NEVER invent SVG paths. ALWAYS copy from heroicons.com.**

**Step-by-step process:**

1. **Visit** heroicons.com
2. **Search** for the icon you need (e.g., "cog", "code", "users", "database")
3. **Select** "Outline" style (not Solid or Mini)
4. **Click** the icon to open the detail view
5. **Click** "Copy SVG" button
6. **Paste** directly into your HTML
7. **Add** appropriate sizing class (`.icon-lg` or `.icon-xl`)
8. **Verify** `stroke-width="1.5"` is preserved

**Example - Correct Heroicons cog-6-tooth (outline):**

```html
<svg class="icon icon-lg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
  <path d="M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593c.55 0 1.02.398 1.11.94l.213 1.281c.063.374.313.686.645.87.074.04.147.083.22.127.324.196.72.257 1.075.124l1.217-.456a1.125 1.125 0 011.37.49l1.296 2.247a1.125 1.125 0 01-.26 1.431l-1.003.827c-.293.24-.438.613-.431.992a6.759 6.759 0 010 .255c-.007.378.138.75.43.99l1.005.828c.424.35.534.954.26 1.43l-1.298 2.247a1.125 1.125 0 01-1.369.491l-1.217-.456c-.355-.133-.75-.072-1.076.124a6.57 6.57 0 01-.22.128c-.331.183-.581.495-.644.869l-.213 1.28c-.09.543-.56.941-1.11.941h-2.594c-.55 0-1.02-.398-1.11-.94l-.213-1.281c-.062-.374-.312-.686-.644-.87a6.52 6.52 0 01-.22-.127c-.325-.196-.72-.257-1.076-.124l-1.217.456a1.125 1.125 0 01-1.369-.49l-1.297-2.247a1.125 1.125 0 01.26-1.431l1.004-.827c.292-.24.437-.613.43-.992a6.932 6.932 0 010-.255c.007-.378-.138-.75-.43-.99l-1.004-.828a1.125 1.125 0 01-.26-1.43l1.297-2.247a1.125 1.125 0 011.37-.491l1.216.456c.356.133.751.072 1.076-.124.072-.044.146-.087.22-.128.332-.183.582-.495.644-.869l.214-1.281z"/>
  <path d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
</svg>
```

### CSS for Icons

```css
.icon {
  color: #ffffff !important;
  stroke: currentColor;
}

.icon-lg { 
  width: 28px; 
  height: 28px; 
}

.icon-xl { 
  width: 40px; 
  height: 40px; 
}
```

### ❌ Common Icon Mistakes to Avoid

**WRONG Example 1 - Simplified/Generic SVG:**
```html
<!-- DON'T DO THIS - Generic/simplified paths -->
<svg viewBox="0 0 24 24">
  <circle cx="12" cy="12" r="3"></circle>
  <path d="M12 1v6m0 6v6"></path>
</svg>
```
**Why it's wrong:** Invented paths create ugly, unprofessional icons.

**WRONG Example 2 - Made-up icon paths:**
```html
<!-- DON'T DO THIS - Inventing SVG paths -->
<svg viewBox="0 0 24 24">
  <path d="M6 18L18 6M6 6l12 12"/>
</svg>
```
**Why it's wrong:** Doesn't match Heroicons design system.

**WRONG Example 3 - Using icon fonts:**
```html
<!-- DON'T DO THIS - Icon fonts don't work in HubSpot -->
<i class="hi hi-cog"></i>
```
**Why it's wrong:** Requires complex font hosting setup that breaks easily.

**RIGHT - Actual Heroicons SVG:**
```html
<!-- DO THIS - Copy exact SVG from heroicons.com -->
<svg class="icon icon-lg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
  <path d="M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593..."/>
  <!-- Full correct path from heroicons.com -->
</svg>
```
**Why it's right:** Professional, reliable, works immediately.

### Icon Implementation Checklist

- [ ] SVG copied directly from heroicons.com (not invented)
- [ ] "Outline" style selected (not Solid or Mini)
- [ ] `stroke-width="1.5"` preserved from Heroicons
- [ ] `viewBox="0 0 24 24"` attribute present
- [ ] `fill="none"` and `stroke="currentColor"` included
- [ ] Sizing class added (`.icon-lg` or `.icon-xl`)
- [ ] `color: #ffffff !important` in CSS for proper rendering
- [ ] `aria-hidden="true"` added for decorative icons

For Heroicons library reference, see `references/HEROICONS_REFERENCE.md`.

## Blog Embedding Support

Modules must work seamlessly inside blog posts under the existing blog CSS.

### Blog CSS Context

```css
.blog-post {
  margin: 0 auto;
  max-width: 960px;
}
/* Additional blog styles apply */
```

### Blog Embedding Requirements

1. **Width constraints**: Keep content within ≤960px; never exceed container width
2. **Heading hierarchy**: 
   - **CRITICAL**: Maximum heading level is H3 (never use H1 or H2)
   - Blog posts already have H1 (title) and H2 (main sections) for SEO
   - H3 should be sized at 28px for visual hierarchy
   - Use `<strong>` or `<span class="heading-style">` for styling without semantic heading tags
3. **Typography inheritance**: Let blog typography apply; don't force fonts/sizes globally
4. **Spacing control**: 
   - Outer wrapper: No extra bottom padding
   - Last items: Use `:last-child` to remove trailing margins
5. **Touch targets**: Ensure ≥44px tap targets on mobile
6. **Icon consistency**: Use consistent sizing with CSS classes

### Responsive Testing

Test at multiple widths:
- Mobile: 320px
- Tablet: 768px
- Desktop: 1000px+

## HTML Structure Rules for Blog-Safe Modules

### Heading Rules (CRITICAL)

**ONE h3 per module maximum** - This is the main module title that must coexist with blog post structure.

Blog posts already use:
- **H1**: Blog post title (SEO-critical, appears once at top)
- **H2**: Main section headings throughout the blog content

Therefore, HubSpot modules must:
- ✅ **Use H3 ONLY** for the primary module title
- ❌ **NEVER use H1, H2, H4, H5, H6** - These conflict with blog post hierarchy and SEO
- ✅ **Use paragraphs with CSS classes** for all other text hierarchy

**Why this matters:**
- SEO: Search engines expect proper heading hierarchy (H1 → H2 → H3)
- Accessibility: Screen readers navigate by heading structure
- Visual consistency: Blog posts control H1/H2 styling globally

### Paragraph Usage for Visual Hierarchy

Since we can only use ONE H3, create visual hierarchy using **paragraphs with CSS classes**:

```html
<div class="module-wrapper">
  <!-- Primary module title (only H3 allowed) -->
  <h3 class="module-title">Main Module Title</h3>
  
  <!-- All other text hierarchy uses paragraphs -->
  <p class="eyebrow-text">SMALL CAPS LABEL</p>
  <p class="large-text">This looks like a subtitle</p>
  <p class="medium-text">This looks like a subheading</p>
  <p class="description-text">Regular body text here</p>
  <p class="small-text">Small detail text</p>
  <p class="label-text">Tiny label text</p>
</div>
```

### Typography Rules (MANDATORY)

**ALL text uses Montserrat** - No font mixing whatsoever.

```css
/* Apply to EVERYTHING in the module */
.module-wrapper,
.module-wrapper * {
  font-family: 'Montserrat', sans-serif !important;
}
```

**Why Montserrat everywhere:**
- Blog posts use Charter/Lato by default
- Modules need consistent branding
- The `!important` flag ensures module fonts override blog styles
- Applies to both headings AND paragraphs

**Never use:**
- ❌ Lato (blog's body font)
- ❌ Charter (blog's reading font)
- ❌ Georgia, Times, or any serif fonts
- ❌ Multiple font families in one module

## Box Model & Layout Alignment Rules

### Critical: Always Use box-sizing: border-box

**MANDATORY in every HubSpot module:**

```css
.module-wrapper,
.module-wrapper * {
  font-family: 'Montserrat', sans-serif !important;
  box-sizing: border-box; /* CRITICAL - Always include this */
}
```

**Why it's critical:**
- Without `box-sizing: border-box`, width calculations break
- `width: 100%` + `padding: 40px` = 100% + 80px total width
- With `box-sizing: border-box`, padding is included in width
- Result: Components overflow their containers without it

**Example of the problem:**

```css
/* WRONG - Will overflow */
.data-foundation {
  width: 100%;
  padding: 32px 40px; /* Adds 80px to width */
  /* Total width: 100% + 80px = overflow */
}

/* RIGHT - Stays within bounds */
.module-wrapper * {
  box-sizing: border-box;
}

.data-foundation {
  width: 100%;
  padding: 32px 40px; /* Included in 100% */
  /* Total width: exactly 100% */
}
```

### Seamless Component Connections

When components need to connect visually (stacked sections), follow these rules:

**Example: Cards sitting on top of a foundation section**

```css
/* Top component - no bottom border */
.pillar {
  border: 2px solid var(--primary-blue);
  border-bottom: none; /* Remove connecting edge */
  border-radius: 8px 8px 0 0; /* Only top corners rounded */
  margin: 0; /* Critical: no gap */
}

/* Bottom component - no top border */
.foundation {
  border: 2px solid var(--primary-blue);
  border-top: none; /* Remove connecting edge */
  border-radius: 0 0 12px 12px; /* Only bottom corners rounded */
  margin: 0; /* Critical: no gap */
}
```

**Critical alignment rules:**
1. **Border widths MUST match exactly** - Both 2px or both 3px (never mixed)
2. **Remove connecting borders** - Use `border-bottom: none` / `border-top: none`
3. **Set margins to 0** - Both `margin-bottom: 0` and `margin-top: 0`
4. **Border radii only on outer corners** - Top element: `8px 8px 0 0`, Bottom: `0 0 12px 12px`
5. **No gaps in grid** - Use `gap: 0` on parent containers that connect

**Visual test:** 
- The seam between components should be invisible
- No gap visible between sections
- No double-line at connection point
- Left and right edges align perfectly

**Common alignment mistakes:**

```css
/* WRONG - Creates gap */
.pillars-row {
  gap: 24px;
  margin-bottom: 4px; /* Creates visible gap */
}

/* RIGHT - Seamless connection */
.pillars-row {
  gap: 24px; /* Gap between pillars, not below */
  margin-bottom: 0; /* No gap at bottom */
}
```

```css
/* WRONG - Mismatched borders create double line */
.pillar {
  border: 2px solid blue;
  border-bottom: none;
}

.foundation {
  border: 3px solid blue; /* Different width! */
  border-top: none;
}

/* RIGHT - Matching borders */
.pillar {
  border: 2px solid blue;
  border-bottom: none;
}

.foundation {
  border: 2px solid blue; /* Same width */
  border-top: none;
}
```

### Layout Debugging Checklist

When components don't align properly:

- [ ] Check `box-sizing: border-box` is on universal selector
- [ ] Verify border widths match exactly at connection points
- [ ] Confirm connecting borders are removed (`none`)
- [ ] Ensure margins are 0 at connection points
- [ ] Validate border-radius only on outer corners
- [ ] Inspect in browser DevTools for hidden margins/padding
- [ ] Test at multiple screen widths (320px, 768px, 1200px)

### Structure Example

**Complete blog-safe module structure:**

```html
<div class="module-wrapper">
  <!-- Single H3 for main title -->
  <h3 class="module-title">Three Pillars of Revenue Operations</h3>
  
  <!-- Everything else is paragraphs with classes -->
  <p class="eyebrow-text">FRAMEWORK</p>
  <p class="section-intro">Build a foundation for scalable growth</p>
  
  <!-- Pillar cards -->
  <div class="pillar-card">
    <p class="pillar-number">01</p>
    <p class="pillar-title">Strategy & Planning</p>
    <p class="pillar-description">Align revenue teams around unified goals...</p>
  </div>
  
  <!-- More content using paragraph hierarchy -->
</div>
```

## CSS Generation Rules for Blog-Safe Modules

### Font Declaration (MANDATORY FIRST RULE)

**ALWAYS start your CSS with this universal font declaration:**

```css
/* CRITICAL: All module text uses Montserrat */
.module-wrapper,
.module-wrapper * {
  font-family: 'Montserrat', sans-serif !important;
}
```

This must be the **first rule** in your CSS to:
1. Override blog's default fonts (Charter/Lato)
2. Ensure visual consistency across module
3. Apply to both semantic tags (h3, p) and any child elements
4. Use `!important` to win specificity battles with blog CSS

### CSS Variables Scoping (CRITICAL)

**NEVER use `:root` for CSS variables in HubSpot modules.**

Blog posts already define `:root` variables, and your module variables would conflict with them.

**WRONG (causes conflicts):**
```css
:root {
  --primary-color: #000FC4;
  --spacing-unit: 24px;
}
```

**RIGHT (properly scoped):**
```css
.module-wrapper {
  --primary-color: #000FC4;
  --spacing-unit: 24px;
  --text-color-light: #666666;
  --text-color-dark: #222222;
}
```

**Why this matters:**
- Blog posts use `:root` for global theme colors
- Your `:root` variables would override blog variables
- Scoping to `.module-wrapper` keeps variables isolated
- Other modules on the same page won't conflict

### Important Flag Usage

Add `!important` strategically to prevent blog CSS conflicts:

**ALWAYS use `!important` for:**
1. **Font family** - Blog tries to apply Charter/Lato
2. **White text on dark backgrounds** - Blog CSS tries to force dark text
3. **Critical layout** - When blog CSS tries to override your module layout

**Example:**
```css
.module-wrapper {
  font-family: 'Montserrat', sans-serif !important;
}

.dark-section {
  background-color: #000FC4;
}

/* Force white text on dark backgrounds */
.dark-section,
.dark-section * {
  color: #ffffff !important;
}

/* Force white links on dark backgrounds */
.dark-section a {
  color: #ffffff !important;
}
```

### Typography Class System

Create paragraph size variants to replace missing heading levels:

```css
/* Heading (H3 only - module title) */
.module-title {
  font-family: 'Montserrat', sans-serif !important;
  font-size: 32px;
  font-weight: 700;
  color: #222222;
  margin: 0 0 16px 0;
}

/* Eyebrow/Label text (replaces H6 or small heading) */
.eyebrow-text {
  font-family: 'Montserrat', sans-serif !important;
  font-size: 12px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1.5px;
  color: #000FC4;
  margin: 0 0 8px 0;
}

/* Large paragraph (replaces H4 visually) */
.large-text {
  font-family: 'Montserrat', sans-serif !important;
  font-size: 24px;
  font-weight: 600;
  color: #333333;
  margin: 0 0 12px 0;
}

/* Medium paragraph (replaces H5 visually) */
.medium-text {
  font-family: 'Montserrat', sans-serif !important;
  font-size: 18px;
  font-weight: 600;
  color: #333333;
  margin: 0 0 8px 0;
}

/* Regular paragraph */
.description-text {
  font-family: 'Montserrat', sans-serif !important;
  font-size: 16px;
  font-weight: 400;
  color: #333333;
  line-height: 1.6;
  margin: 0 0 16px 0;
}

/* Small paragraph */
.small-text {
  font-family: 'Montserrat', sans-serif !important;
  font-size: 14px;
  font-weight: 400;
  color: #666666;
  margin: 0 0 8px 0;
}

/* Tiny label */
.label-text {
  font-family: 'Montserrat', sans-serif !important;
  font-size: 12px;
  font-weight: 400;
  color: #666666;
  margin: 0;
}
```

### Dark Background Text Handling (CRITICAL)

When a section has a dark background (navy, black, etc.), **ALL text and links inside MUST be white**.

**Common mistake:** Forgetting to override link colors, which default to blue/purple.

**Complete dark section handling:**

```css
/* Dark section container */
.dark-section {
  background-color: #000FC4; /* Navy blue */
  padding: 48px 24px;
}

/* Force white text on ALL elements inside dark section */
.dark-section,
.dark-section * {
  color: #ffffff !important;
}

/* Specifically target common elements */
.dark-section h3,
.dark-section p,
.dark-section span,
.dark-section a {
  color: #ffffff !important;
}

/* Handle link states */
.dark-section a:hover,
.dark-section a:focus {
  color: #ffffff !important;
  text-decoration: underline;
}
```

**Dark badges or buttons:**

```css
.dark-badge {
  background-color: #000FC4;
  padding: 8px 16px;
  border-radius: 4px;
}

/* Force white text in badge */
.dark-badge,
.dark-badge * {
  color: #ffffff !important;
}
```

**Why `!important` is necessary:**
- Blog CSS applies default link colors (blue/purple)
- Blog CSS applies default text colors (dark grey/black)
- Without `!important`, blog CSS wins and text is unreadable on dark backgrounds
- The universal selector `*` catches all child elements

## Dark Background Color Forcing (COMPREHENSIVE)

**CRITICAL:** Blog CSS will override text colors on dark backgrounds unless you use aggressive `!important` declarations.

### The Problem

Blog posts have strong CSS that sets text to dark colors. When you have a dark background section (e.g., navy blue), blog CSS turns your text black, making it unreadable.

### The Solution: Multi-Layer Color Forcing

**Use ALL of these approaches simultaneously:**

```css
/* Layer 1: Universal selector on dark section */
.dark-section,
.dark-section * {
  color: #ffffff !important;
}

/* Layer 2: Specific element types */
.dark-section p,
.dark-section span,
.dark-section div,
.dark-section strong,
.dark-section em,
.dark-section a {
  color: #ffffff !important;
}

/* Layer 3: Content containers */
.dark-section-content * {
  color: #ffffff !important;
}

/* Layer 4: Individual text elements */
.dark-section-title {
  color: #ffffff !important;
}

.dark-section-description {
  color: #ffffff !important;
  opacity: 0.9; /* Use opacity for lighter shades, not color */
}

/* Layer 5: Links specifically (blog CSS targets these heavily) */
.dark-section a,
.dark-section a:visited,
.dark-section a:hover,
.dark-section a:active {
  color: #ffffff !important;
}
```

### Complete Dark Section Example

```css
/* Container with dark background */
.data-foundation {
  background-color: var(--primary-blue) !important;
  padding: 32px 40px;
}

/* CRITICAL: All text must be white */
.data-foundation,
.data-foundation * {
  color: #ffffff !important;
}

/* Specific element reinforcement */
.data-foundation p,
.data-foundation span,
.data-foundation div {
  color: #ffffff !important;
}

/* Content area specific */
.foundation-content * {
  color: #ffffff !important;
}

/* Individual elements */
.foundation-title {
  color: #ffffff !important;
  font-weight: 700 !important;
}

.foundation-description {
  color: #ffffff !important;
  opacity: 0.9; /* Light effect via opacity */
}

/* Metric box */
.foundation-metric * {
  color: #ffffff !important;
}

.metric-label {
  color: #ffffff !important;
  opacity: 0.9;
}
```

### Why Use Opacity Instead of Light Colors

**WRONG:**
```css
.description {
  color: #E8F4FE; /* Light blue - blog CSS overrides this */
}
```

**RIGHT:**
```css
.description {
  color: #ffffff !important; /* White with !important */
  opacity: 0.9; /* Opacity creates lighter appearance */
}
```

**Reason:** Blog CSS won't override white + opacity, but it will override color values.

### Dark Section Checklist

- [ ] Universal selector with `color: #ffffff !important`
- [ ] Specific element selectors (p, span, div, a)
- [ ] Content container selectors with `!important`
- [ ] Individual text elements with `!important`
- [ ] Links with all states (hover, visited, active)
- [ ] Use opacity for lighter shades, not color values
- [ ] Test in actual blog post (not just preview)
- [ ] Verify text is readable on dark background at all screen sizes

## Quick Reference

### Core Transformations

| v0.dev | HubSpot | Method |
|--------|---------|--------|
| TypeScript (.tsx) | Vanilla JS (.js) | Remove types, convert syntax |
| React Components | Plain HTML | Flatten hierarchy |
| JSX Syntax | HTML5 | Convert attributes |
| Tailwind CSS | Modern Native CSS | Convert to CSS Grid, Flexbox, Custom Properties |
| Lucide/Other Icons | Heroicons Inline SVG | Copy exact SVG code from heroicons.com |
| useState/useEffect | Vanilla JS | Use variables + listeners |
| Component props | data-* attributes | Hardcode or use attributes |

## Conversion Process

### Step 1: Pre-Conversion Assessment (10-15 min)

**Component Inventory:**
1. List all React hooks used (useState, useEffect, useRef)
2. Count icons to convert to Heroicons icon font/CSS (estimate 2-3 min per icon)
3. Identify shadcn/ui components (estimate 15 min each)
4. Document interactive elements (buttons, forms, toggles)
5. Map state variables and their purposes

**Complexity Scoring:**
- Base: 10 points
- Icons: +1 each (converting inline SVG to icon font/CSS)
- State hooks: +5 each
- shadcn components: +3 each
- Conditionals: +2 each
- Array maps: +3 each
- Forms: +5 each

**Time Estimates:**
- 10-20 points: Simple (1-2 hours)
- 21-40 points: Medium (2-4 hours)
- 41-60 points: Complex (4-8 hours)
- 61+ points: Very Complex (8+ hours)

### Step 2: Icon Conversion (Heroicons Only, NO Inline SVG)

**CRITICAL: Convert inline SVG to Heroicons icon font or CSS backgrounds.**

For each icon in the original component:

**Step A: Identify the Icon**
1. Note what the inline SVG represents (check, arrow, menu, etc.)
2. Find the matching Heroicon at https://heroicons.com/
3. Note the Heroicon name (e.g., "check-circle", "arrow-right")

**Step B: Choose Implementation Method**

**Method 1: Icon Font** (Preferred - cleaner markup)
```html
<!-- Before: Inline SVG (15 lines) -->
<svg class="icon" viewBox="0 0 24 24">
  <path d="M9 12.75L11.25 15 15 9.75..."/>
</svg>

<!-- After: Icon Font (1 line) -->
<i class="hi-check-circle"></i>
```

```css
/* In CSS file - define once, use everywhere */
.hi-check-circle::before {
  content: '\e001'; /* Icon font character code */
  font-family: 'Heroicons';
  font-size: 24px;
}
```

**Method 2: CSS Background Image** (Alternative)
```html
<!-- Before: Inline SVG -->
<svg class="icon">...</svg>

<!-- After: Empty span with CSS background -->
<span class="icon icon-check"></span>
```

```css
.icon-check {
  display: inline-block;
  width: 24px;
  height: 24px;
  background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="..."/></svg>');
  background-size: contain;
}
```

**Method 3: External SVG Sprite** (If available)
```html
<svg class="icon">
  <use xlink:href="/heroicons-sprite.svg#check-circle"></use>
</svg>
```

**Step C: Set Up Icon System**

**For Icon Font Approach:**
1. Load Heroicons font file in CSS
2. Create icon classes (`.hi-check`, `.hi-arrow`, etc.)
3. Apply classes in HTML (`<i class="hi-check"></i>`)

**For CSS Background Approach:**
1. Convert each Heroicon SVG to data URI
2. Create CSS classes with background-image
3. Apply classes to empty spans

**Example Icon Font Setup:**
```css
/* Load font */
@font-face {
  font-family: 'Heroicons';
  src: url('/fonts/heroicons.woff2') format('woff2');
}

/* Base icon class */
.hi {
  font-family: 'Heroicons';
  font-style: normal;
  font-weight: normal;
  font-size: 24px;
  line-height: 1;
  display: inline-block;
}

/* Specific icons */
.hi-check::before { content: '\e001'; }
.hi-arrow-right::before { content: '\e002'; }
.hi-menu::before { content: '\e003'; }
```

**Step D: Replace in HTML**

Convert all inline SVG to icon font classes:

```html
<!-- Before -->
<button>
  <svg class="icon" viewBox="0 0 24 24">
    <path d="M9 12.75L11.25 15..."/>
  </svg>
  <span>Save Changes</span>
</button>

<!-- After -->
<button>
  <i class="hi hi-check"></i>
  <span>Save Changes</span>
</button>
```

**Benefits:**
- ✅ HTML stays clean (1 line vs 15 lines per icon)
- ✅ Icons defined once in CSS, used everywhere
- ✅ Easy to update all icons globally
- ✅ No blog CSS conflicts
- ✅ Better performance (smaller HTML files)

**Rule:** ONLY use Heroicons. NO Font Awesome, Lucide, or other icon libraries.

### Step 3: HTML Structure (1-3 hours)

**JSX to HTML Conversion Rules:**
1. `className` → `class`
2. `htmlFor` → `for`
3. Self-closing tags → Properly closed
4. `{variables}` → Static text or data attributes
5. `{condition && <div>}` → Write both states
6. `{array.map()}` → Duplicate HTML manually
7. Event handlers (onClick, etc.) → Remove (handle in JS)
8. **HEADINGS**: Maximum H3 (never H1/H2 for blog SEO) - use `<strong>` for emphasis instead

**Blog-Safe Wrapper:**
```html
<div class="module-wrapper">
  <!-- module content -->
  <div class="module-content">
    <h3 class="module-title">Section Title</h3>
    <!-- items -->
  </div>
</div>
```

**Data Attribute Strategy:**
Use data attributes for JavaScript hooks:
```html
<button class="tab-btn" data-tab-id="0">Tab 1</button>
<div class="content" data-tab-content="0">Content 1</div>
```

### Step 4: Modern CSS Conversion (2-4 hours)

**Organization Strategy:**
1. Start with CSS custom properties (variables)
2. Use CSS Grid/Flexbox for layouts
3. Apply modern functions (clamp, min, max) for responsive sizing
4. Use CSS nesting for organization
5. Add media queries for specific breakpoints

**CSS Structure Template:**
```css
/* CRITICAL: Universal Montserrat font application */
.module-wrapper,
.module-wrapper * {
  font-family: 'Montserrat', sans-serif !important;
}

/* CSS Variables - Scoped to module wrapper (NOT :root) */
.module-wrapper {
  --color-primary: #6b5cff;
  --color-secondary: #ff6b9d;
  --spacing-sm: 0.5rem;
  --spacing-md: 1rem;
  --spacing-lg: 2rem;
  --text-dark: #222222;
  --text-medium: #666666;
}

/* Module wrapper */
.module-wrapper {
  width: min(100%, 960px);
  margin-inline: auto;
  padding: var(--spacing-md);
}

/* Heading hierarchy - MAX ONE H3 for blog SEO */
.module-wrapper h3 {
  font-size: 32px;
  font-weight: 700;
  line-height: 1.3;
  margin-bottom: var(--spacing-md);
}

/* Paragraph size variants for visual hierarchy */
.large-text {
  font-size: 24px;
  font-weight: 600;
  margin-bottom: var(--spacing-sm);
}

.medium-text {
  font-size: 18px;
  font-weight: 600;
  margin-bottom: var(--spacing-sm);
}

.description-text {
  font-size: 16px;
  font-weight: 400;
  line-height: 1.6;
  margin-bottom: var(--spacing-md);
}

/* Component styles with nesting */
.card {
  background: white;
  border-radius: 12px;
  padding: var(--spacing-md);
  
  & .card-title {
    font-size: 24px;
    font-weight: 600;
    margin-bottom: var(--spacing-sm);
  }
  
  &:hover {
    box-shadow: 0 4px 16px rgba(0,0,0,0.1);
  }
}

/* Dark sections - Force white text */
.dark-section {
  background-color: var(--color-primary);
  padding: var(--spacing-lg);
}

.dark-section,
.dark-section * {
  color: #ffffff !important;
}

/* Responsive grid */
.grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: var(--spacing-md);
}
```

**Best Practices:**
- Use semantic class names (BEM or descriptive)
- Leverage CSS custom properties for theming
- Apply mobile-first responsive design
- Use modern CSS functions for fluid sizing
- Organize by sections (base, header, content, interactive, responsive)

### Step 5: JavaScript Conversion (1-4 hours)

**React Hooks to Vanilla JS:**

**useState:**
```javascript
// React:
const [count, setCount] = useState(0);

// Vanilla JS:
let state = { count: 0 };
function setCount(newValue) {
  state.count = newValue;
  render();
}
```

**useEffect:**
```javascript
// React:
useEffect(() => {
  // side effect
}, [dependency]);

// Vanilla JS:
function init() {
  // side effect on mount
}
// For updates, call from state setters
```

**Module Structure:**
```javascript
(function() {
  'use strict';
  
  let state = { /* initial state */ };
  let elements = {};
  
  function cacheElements() { /* cache DOM refs */ }
  function updateState(updates) { /* update + render */ }
  function render() { /* update UI */ }
  function attachEventListeners() { /* add listeners */ }
  function init() { /* initialize */ }
  
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
```

## Output Format

**IMPORTANT**: All output is delivered as a **single Markdown artifact**, not as Docker files. This artifact contains three clearly labeled code blocks that you can copy-paste directly into HubSpot Design Manager.

### Artifact Structure

The Markdown artifact will contain:

1. **Component Overview** - Brief description and usage notes
2. **Implementation Approach** - Modern native CSS with Heroicons icon font
3. **HTML Code Block** - Complete module.html code
4. **CSS Code Block** - Complete module.css code with modern features
5. **JavaScript Code Block** - Complete module.js code
6. **Blog Embedding Notes** - Special considerations for blog use
7. **Implementation Checklist** - Testing steps

### Code Block Contents

**HTML Block (`module.html`):**
- Blog-safe wrapper with proper constraints
- Plain HTML structure with semantic markup
- Heroicons via icon font classes (`<i class="hi-check"></i>`) - NO inline SVG
- Data attributes for JavaScript hooks
- No inline styles or scripts

**CSS Block (`module.css`):**
- CSS custom properties (variables) for theming
- Modern CSS features (Grid, Flexbox, clamp, min, max)
- CSS nesting for organization
- Mobile-first responsive design
- State classes for interactivity (.active, .hidden, etc.)

**JavaScript Block (`module.js`):**
- IIFE wrapper for scope isolation
- State management system
- DOM element caching
- Event listener attachments
- Initialization logic
- Fully vanilla JavaScript (no React, no external dependencies)

### Artifact Template

```markdown
# [Component Name] - HubSpot Custom Module

## Overview
[Brief description of the component and its functionality]

## Implementation Approach
- **Styling**: Modern Native CSS (Grid, Flexbox, Custom Properties, Nesting)
- **Icons**: Heroicons icon font (NO inline SVG)
- **Blog Safe**: Designed for clean embedding in blog posts
- **Typography**: Montserrat font family throughout

## Usage Notes
- [Any special considerations]
- [Dependencies or requirements]
- [Configuration options]

---

## HTML (module.html)

\`\`\`html
[Complete HTML code here]
\`\`\`

---

## CSS (module.css)

\`\`\`css
[Complete CSS code here]
\`\`\`

---

## JavaScript (module.js)

\`\`\`javascript
[Complete JavaScript code here]
\`\`\`

---

## Blog Embedding Notes

- **Width**: Content constrained to 960px max
- **Spacing**: No extra bottom padding; last-child margins removed
- **Icons**: Heroicons icon font - NO inline SVG
- **Responsive**: Tested at 320px, 768px, 1000px+
- **Typography**: Montserrat applied universally with !important

## Implementation Checklist

- [ ] Copy HTML into HubSpot module.html
- [ ] Copy CSS into HubSpot module.css
- [ ] Copy JavaScript into HubSpot module.js
- [ ] Test in HubSpot Design Manager preview
- [ ] Verify all interactive elements work
- [ ] Test responsive behavior at multiple widths
- [ ] Check accessibility features (ARIA, keyboard nav)
- [ ] Test embedded in blog post context
- [ ] Verify no conflicts with blog CSS

## Additional Notes
[Any special instructions, known issues, or optimization tips]
```

## Best Practices

1. **Mobile-First Design**: Start with mobile styles, enhance for larger screens
2. **Blog Embedding**: Always wrap in blog-safe container, test in blog context
3. **Heading Hierarchy**: Maximum H3 (32px) - never use H1/H2 for blog SEO
4. **Modern CSS**: Use Grid, Flexbox, Custom Properties, and modern functions
5. **Icons**: ONLY Heroicons via icon font or CSS (NO inline SVG in HTML)
6. **Data Attributes**: Use for JS hooks instead of relying on class names
7. **CSS Isolation**: Use semantic class names to avoid conflicts
8. **Performance**: Cache DOM queries, avoid layout thrashing
9. **Accessibility**: Include ARIA attributes, keyboard navigation, proper focus states
10. **Testing**: Test at 320px, 768px, 1000px+ widths
11. **Spacing**: Remove excess bottom padding; use `:last-child` selectors
12. **Typography**: Montserrat everywhere with `!important` flag

## Common Patterns

### Tabs Component
**HTML**: Use data-tab-id and data-tab-content
**CSS**: .active class for selected tab with modern CSS transitions
**JS**: Click handlers to switch active states

### Accordion Component
**HTML**: Use data-open attribute
**CSS**: Max-height transition with modern CSS
**JS**: Toggle data-open and class states

### Form Component
**HTML**: Standard form elements with proper labels
**CSS**: Focus states, validation styles
**JS**: FormData API, validation logic

## Reference Files

For detailed guides, see:
- `references/MODERN_CSS_GUIDE.md` - Complete modern CSS features and patterns for HubSpot
- `references/HEROICONS_REFERENCE.md` - Heroicons library and icon font conversion patterns
- `references/BLOG_EMBEDDING.md` - Blog embedding requirements and testing
- `references/CONVERSION_GUIDE.md` - Complete step-by-step process with examples
- `references/TAILWIND_TO_CSS.md` - Converting existing Tailwind classes to modern CSS
- `references/REACT_TO_VANILLA.md` - React pattern transformations

## Example Templates

For working examples, see:
- `assets/templates/module-html-template.html` - HTML structure template
- `assets/templates/module-css-template.css` - Modern CSS organization template
- `assets/templates/module-js-template.js` - JavaScript module template

## Quick Start Workflow

1. **Read** the component code, complete assessment
2. **Identify** inline SVG icons to convert to Heroicons icon font
3. **Convert** JSX to HTML, add blog-safe wrapper
4. **Apply** modern CSS (Grid, Flexbox, Custom Properties) with Montserrat font
5. **Replace** inline SVG with Heroicons icon font classes (NO inline SVG)
6. **Rewrite** React to vanilla JS, implement state management
7. **Test** spacing, ensure proper blog embedding
8. **Generate** Markdown artifact with all code blocks
9. **Review** the artifact in Claude's interface
10. **Copy-paste** each code block into HubSpot Design Manager
11. **Test** in HubSpot preview and blog context
12. **Iterate** based on testing results

## Example Conversion - Before & After

This example shows how to convert a component with multiple heading levels into a blog-safe module.

### BEFORE (v0.dev React with multiple heading levels)

**Problem:** Uses H1, H2, H4 which conflict with blog post SEO structure.

```jsx
<div className="feature-section">
  <h1 className="main-title">Our Platform Features</h1>
  <h2 className="section-heading">Core Capabilities</h2>
  <h4 className="subsection">Data Integration</h4>
  <p className="body-text">Connect all your data sources seamlessly...</p>
  
  <div className="dark-card">
    <h3>Premium Feature</h3>
    <p>Advanced analytics and reporting</p>
    <a href="/learn-more">Learn More</a>
  </div>
</div>
```

### AFTER (HubSpot Blog-Safe)

**Solution:** Single H3 for module title, paragraphs with CSS classes for hierarchy.

```html
<div class="module-wrapper feature-section">
  <!-- Only ONE H3 allowed -->
  <h3 class="module-title">Our Platform Features</h3>
  
  <!-- Visual hierarchy using paragraph classes -->
  <p class="section-title">Core Capabilities</p>
  <p class="subsection-title">Data Integration</p>
  <p class="body-text">Connect all your data sources seamlessly...</p>
  
  <!-- Dark card with forced white text -->
  <div class="dark-card">
    <p class="card-title">Premium Feature</p>
    <p class="card-description">Advanced analytics and reporting</p>
    <a href="/learn-more" class="card-link">Learn More</a>
  </div>
</div>
```

### CSS for the Conversion

```css
/* MANDATORY: Universal Montserrat application */
.feature-section,
.feature-section * {
  font-family: 'Montserrat', sans-serif !important;
}

/* Scoped variables (NOT :root) */
.feature-section {
  --primary-color: #000FC4;
  --text-dark: #222222;
  --text-medium: #666666;
  --spacing-lg: 32px;
  --spacing-md: 16px;
}

/* Single H3 (module title) */
.module-title {
  font-size: 32px;
  font-weight: 700;
  color: var(--text-dark);
  margin: 0 0 var(--spacing-lg) 0;
}

/* Paragraph as section heading (replaces H2 visually) */
.section-title {
  font-size: 24px;
  font-weight: 600;
  color: var(--text-dark);
  margin: 0 0 20px 0;
}

/* Paragraph as subsection (replaces H4 visually) */
.subsection-title {
  font-size: 18px;
  font-weight: 600;
  color: var(--text-dark);
  margin: 0 0 12px 0;
}

/* Regular paragraph */
.body-text {
  font-size: 16px;
  font-weight: 400;
  color: var(--text-medium);
  line-height: 1.6;
  margin: 0 0 var(--spacing-md) 0;
}

/* Dark card section */
.dark-card {
  background-color: var(--primary-color);
  padding: 32px;
  border-radius: 8px;
  margin: var(--spacing-lg) 0 0 0;
}

/* CRITICAL: Force white text on dark background */
.dark-card,
.dark-card * {
  color: #ffffff !important;
}

/* Dark card typography */
.card-title {
  font-size: 24px;
  font-weight: 700;
  margin: 0 0 12px 0;
}

.card-description {
  font-size: 16px;
  font-weight: 400;
  line-height: 1.6;
  margin: 0 0 20px 0;
}

.card-link {
  font-size: 16px;
  font-weight: 600;
  text-decoration: underline;
}

.card-link:hover {
  text-decoration: none;
}
```

### Key Differences Highlighted

| Element | Before (Wrong) | After (Correct) | Reason |
|---------|----------------|-----------------|---------|
| Main heading | `<h1>` | `<h3 class="module-title">` | Blog already has H1 (post title) |
| Section heading | `<h2>` | `<p class="section-title">` | Blog uses H2 for main sections |
| Subsection | `<h4>` | `<p class="subsection-title">` | Use paragraphs for hierarchy |
| Font declaration | Scattered or missing | `.module-wrapper * { font-family: Montserrat !important; }` | Override blog fonts everywhere |
| CSS variables | `:root { --color: blue; }` | `.module-wrapper { --color: blue; }` | Avoid global conflicts |
| Dark text | `color: inherit` | `color: #ffffff !important` | Force white on dark backgrounds |

## Module Creation Checklist

Use this checklist for every HubSpot module you create or convert:

### HTML Structure
- [ ] **ONE H3 maximum** for main module title (never H1, H2, H4, H5, H6)
- [ ] **All other text uses `<p>` tags** with CSS classes for visual hierarchy
- [ ] **Module wrapper** has unique, semantic class name (e.g., `.three-pillars-module`)
- [ ] **Semantic HTML5** elements used where appropriate (article, section, nav)
- [ ] **Data attributes** used for JavaScript hooks (not classes)

### Icon Requirements
- [ ] **Heroicons inline SVG** - Copied directly from heroicons.com (not invented)
- [ ] **Outline style** - Not Solid or Mini variants
- [ ] **Stroke width 1.5** - Preserved from Heroicons default
- [ ] **Sizing classes** - `.icon-lg` or `.icon-xl` applied
- [ ] **Color forcing** - `color: #ffffff !important` in CSS

### CSS Requirements
- [ ] **First CSS rule**: `.module-wrapper, .module-wrapper * { font-family: 'Montserrat', sans-serif !important; box-sizing: border-box; }`
- [ ] **CSS variables scoped** to `.module-wrapper` (NEVER use `:root`)
- [ ] **`!important` on all font-family** declarations
- [ ] **`!important` on color** for any dark background sections
- [ ] **Paragraph size variants** created (.large-text, .medium-text, .description-text, .small-text, .label-text)
- [ ] **Modern CSS features** used (Grid, Flexbox, clamp, min, max)
- [ ] **Mobile-first** responsive design with appropriate breakpoints
- [ ] **No Tailwind** classes or utility CSS frameworks

### Layout Requirements
- [ ] **box-sizing: border-box** - On universal selector
- [ ] **Component alignment** - Seamless connections with matching borders
- [ ] **Width constraints** - Maximum 960px for blog embedding
- [ ] **No overflow** - All content stays within bounds
- [ ] **Margin discipline** - 0 margins at connection points

### Dark Background Handling
- [ ] Any section with dark background has **explicit white text color**
- [ ] Universal selector used: `.dark-section, .dark-section * { color: #ffffff !important; }`
- [ ] **Links specifically targeted** with white color (blog CSS overrides links)
- [ ] **All child elements** covered (p, span, a, strong, em, etc.)
- [ ] No reliance on `inherit` or `revert` (blog CSS will leak through)

### Typography Consistency
- [ ] **Only Montserrat** used throughout module (no font mixing)
- [ ] Font weights appropriate: 400 (regular), 600 (semibold), 700 (bold)
- [ ] Line heights specified for readability (1.4-1.6 for body text)
- [ ] Letter spacing used for uppercase/label text (1-2px)

### Blog Embedding Safety
- [ ] Module width constrained to **≤960px** maximum
- [ ] No fixed widths that break on mobile (use max-width instead)
- [ ] Touch targets **≥44px** for mobile usability
- [ ] Last child margins removed (`:last-child { margin-bottom: 0; }`)
- [ ] Module tested at 320px, 768px, 1000px+ widths
- [ ] No conflicts with blog post content above/below module

### Accessibility
- [ ] Heroicons inline SVG includes `aria-hidden="true"` for decorative icons
- [ ] Color contrast meets WCAG AA standards (4.5:1 for text)
- [ ] Focus states visible on interactive elements
- [ ] Keyboard navigation works for all interactions

### JavaScript (if applicable)
- [ ] IIFE wrapper for scope isolation
- [ ] `'use strict';` at top of IIFE
- [ ] DOM elements cached on init
- [ ] Event listeners attached with proper cleanup
- [ ] No jQuery or external dependencies
- [ ] Works with multiple instances on same page

### Common Mistakes to Avoid
- ❌ Using `:root` for CSS variables (conflicts with blog)
- ❌ Using H1, H2, H4, H5, H6 tags (breaks blog SEO structure)
- ❌ Mixing fonts (Lato, Charter, multiple families)
- ❌ Using `inherit` or `revert` for colors on dark backgrounds
- ❌ Forgetting `!important` on font-family declarations
- ❌ Not forcing white color on dark section links
- ❌ Exceeding 960px width (breaks blog layout)
- ❌ Using fixed pixel widths instead of max-width

### Pre-Deployment Checklist
- [ ] Code copied into HubSpot Design Manager (HTML, CSS, JS)
- [ ] Preview tested in HubSpot
- [ ] Module embedded in test blog post
- [ ] Responsive behavior verified on phone, tablet, desktop
- [ ] Dark mode (if applicable) tested
- [ ] Print styles checked (if needed for content)
- [ ] Performance: No unnecessary reflows or heavy computations
- [ ] Browser compatibility: Tested in Chrome, Firefox, Safari

## Troubleshooting

### Icon Issues

**Icons look wrong/ugly/blocky**: 
- **Problem:** You invented SVG paths instead of copying from heroicons.com
- **Fix:** Go to heroicons.com, find the correct icon, click "Copy SVG", paste the EXACT code

**Icons not showing at all**: 
- **Problem:** Missing required SVG attributes
- **Fix:** Verify SVG has `viewBox="0 0 24 24"`, `stroke="currentColor"`, and `fill="none"`

**Icons wrong color**:
- **Problem:** Missing color forcing in CSS
- **Fix:** Add `color: #ffffff !important` to icon CSS

### Layout Issues

**Components not aligned (sections overflow or stick out)**:
- **Problem:** Missing `box-sizing: border-box`
- **Fix:** Add to universal selector: `.module-wrapper * { box-sizing: border-box; }`

**Gap between connected sections**:
- **Problem:** Margins not set to 0 at connection points
- **Fix:** Set `margin-bottom: 0` on top section, `margin-top: 0` on bottom section

**Double line at section connection**:
- **Problem:** Both sections have borders at connection point
- **Fix:** Use `border-bottom: none` on top section, `border-top: none` on bottom section

**Sections don't line up on sides**:
- **Problem:** Border widths don't match
- **Fix:** Use same border width (e.g., both `2px`) on both components

### Dark Background Issues

**Text is black on dark background (unreadable)**:
- **Problem:** Blog CSS overriding text color
- **Fix:** Use multi-layer `!important` approach:
  ```css
  .dark-section * { color: #ffffff !important; }
  .dark-section p { color: #ffffff !important; }
  .dark-section-content * { color: #ffffff !important; }
  ```

**Some text is white, some is black**:
- **Problem:** Inconsistent `!important` usage
- **Fix:** Add `!important` to ALL color declarations in dark sections

**Light text shows as dark instead of light**:
- **Problem:** Using color values that blog CSS overrides
- **Fix:** Use `color: #ffffff !important;` + `opacity: 0.9;` instead of light color values

### Other Common Issues

**Layout broken**: Verify wrapper constraints; test at multiple widths
**JS not working**: Check console for errors, verify DOM caching
**Blog conflicts**: Check for CSS specificity issues; use more specific selectors
**Excess spacing**: Use `:last-child` selectors to remove trailing margins
**Responsive issues**: Test all breakpoints; use modern CSS functions (clamp, min, max)
**Font not applying**: Check that Montserrat declaration with `!important` is first CSS rule

## Common Mistakes & How to Avoid Them

### Mistake 1: Using Icon Fonts
**What it looks like:**
```html
<i class="hi hi-cog"></i>
```
```css
@font-face { font-family: 'Heroicons'; src: url('...'); }
```

**Why it's wrong:** Requires font hosting, complex setup, breaks easily in HubSpot

**Correct approach:**
```html
<svg class="icon icon-lg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
  <!-- Heroicons SVG path copied from heroicons.com -->
</svg>
```

### Mistake 2: Inventing SVG Paths
**What it looks like:**
```html
<svg viewBox="0 0 24 24">
  <path d="M12 1v6m0 6v6"/>
</svg>
```

**Why it's wrong:** Creates ugly, unprofessional icons

**Correct approach:** Always copy complete SVG code from heroicons.com

### Mistake 3: Missing box-sizing
**What it looks like:**
```css
.module-wrapper * {
  font-family: 'Montserrat', sans-serif !important;
  /* Missing box-sizing! */
}
```

**Why it's wrong:** Components overflow, layout breaks

**Correct approach:**
```css
.module-wrapper * {
  font-family: 'Montserrat', sans-serif !important;
  box-sizing: border-box;
}
```

### Mistake 4: Mismatched Borders
**What it looks like:**
```css
.top-section { border: 2px solid blue; }
.bottom-section { border: 3px solid blue; }
```

**Why it's wrong:** Creates visible misalignment, double lines

**Correct approach:**
```css
.top-section { 
  border: 2px solid blue;
  border-bottom: none;
  margin-bottom: 0;
}

.bottom-section { 
  border: 2px solid blue;
  border-top: none;
  margin-top: 0;
}
```

### Mistake 5: Weak Color Forcing on Dark Backgrounds
**What it looks like:**
```css
.dark-section {
  background: navy;
  color: white; /* No !important */
}
```

**Why it's wrong:** Blog CSS overrides, text becomes unreadable

**Correct approach:**
```css
.dark-section,
.dark-section * {
  color: #ffffff !important;
}

.dark-section p,
.dark-section span,
.dark-section div {
  color: #ffffff !important;
}
```

### Mistake 6: Using :root for Variables
**What it looks like:**
```css
:root {
  --primary-blue: #000FC4;
}
```

**Why it's wrong:** Conflicts with blog CSS variables

**Correct approach:**
```css
.module-wrapper {
  --primary-blue: #000FC4;
}
```

### Mistake 7: Forgetting Mobile Alignment
**What it looks like:**
```css
/* Only desktop alignment rules */
.pillar { border-bottom: none; }
.foundation { border-top: none; }
```

**Why it's wrong:** Breaks on mobile when layout stacks

**Correct approach:**
```css
/* Desktop */
.pillar { border-bottom: none; }
.foundation { border-top: none; }

/* Mobile */
@media (max-width: 768px) {
  .pillar:last-child { border-bottom: none; }
  .foundation { 
    border-top: 2px solid var(--primary-blue);
    border-radius: 12px;
  }
}
```

---

**References:**
[1] CSS Grid & Flexbox fundamentals
[2] CSS Custom Properties best practices
[3] Modern CSS Functions (clamp, min, max)
[4] CSS Nesting specification
[5] Modern CSS Selectors (:has, :is, :where)
