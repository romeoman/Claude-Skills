# Changelog

All notable changes to the v0-to-HubSpot Converter skill will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.4.0] - 2025-11-23

### 🔴 CRITICAL CHANGES

These changes fix fundamental issues that caused modules to fail in production.

#### Icon Implementation Complete Rewrite

**REMOVED:**
- Icon font approach (lines 156-247)
- All references to Heroicons icon font setup
- @font-face declarations for icon fonts
- Character code mapping guidance

**ADDED:**
- Comprehensive inline SVG implementation guide
- Step-by-step process for copying from heroicons.com
- Wrong/right examples showing common mistakes
- Icon implementation checklist
- CSS for proper icon sizing and color forcing

**Reason:** Icon fonts require complex hosting setup in HubSpot File Manager, use fragile character code mapping, and break easily when file paths change. Inline SVG from heroicons.com works immediately with no setup, no hosting, and no dependencies.

**Impact:** Future modules will have professional icons that work reliably.

#### Box Model & Layout Alignment Rules

**ADDED (after line 340):**
- Mandatory `box-sizing: border-box` guidance with examples
- Seamless component connection techniques
- Border alignment rules for stacked sections
- Margin discipline at connection points
- Border radius rules for connected components
- Layout debugging checklist

**Reason:** Without `box-sizing: border-box`, width calculations break (`width: 100%` + `padding: 40px` = 100% + 80px overflow). Mismatched borders and margins create visible gaps and misalignment.

**Impact:** Future modules will have perfect alignment and no overflow issues.

#### Dark Background Color Forcing

**EXPANDED (after line 589):**
- Multi-layer `!important` strategy with 5 layers
- Universal selectors for all elements
- Specific element type targeting
- Content container selectors
- Individual element forcing
- Link state handling
- Opacity-based light text technique
- Complete dark section example
- Why-use-opacity explanation
- Dark section checklist

**Reason:** Blog CSS aggressively overrides text colors. Single-layer color declarations get overridden, making text unreadable on dark backgrounds. Multi-layer approach with `!important` ensures text is always visible.

**Impact:** Future modules with dark backgrounds will have readable text in all contexts.

### Updated Documentation

#### Module Checklist (lines 1265-1272)

**CHANGED:**
- Removed: "Heroicons via icon font" item
- Added: Complete "Icon Requirements" section with 5 checklist items
- Added: "Layout Requirements" section with 5 checklist items
- Updated: CSS Requirements to include `box-sizing: border-box`

#### Troubleshooting (line 1340+)

**REPLACED:**
- Single-line troubleshooting entries
- Added: "Icon Issues" section with 3 detailed problems/solutions
- Added: "Layout Issues" section with 4 detailed problems/solutions
- Added: "Dark Background Issues" section with 3 detailed problems/solutions
- Kept: "Other Common Issues" for remaining problems

#### Common Mistakes Section (End of file)

**ADDED:**
- Complete new section with 7 common mistakes
- Each mistake includes: what it looks like, why it's wrong, correct approach
- Covers: icon fonts, invented SVG, missing box-sizing, mismatched borders, weak color forcing, :root variables, mobile alignment

### Minor Updates

#### Frontmatter

**CHANGED:**
- Description: "via icon font or CSS, NO inline SVG" → "inline SVG (copied directly from heroicons.com)"

#### Overview Section

**CHANGED:**
- "When to Use" bullet: "Converting inline SVG icons to Heroicons icon font/CSS" → "Using Heroicons inline SVG (copied from heroicons.com)"

#### Quick Reference Table

**CHANGED:**
- Row: "Lucide/Inline SVG Icons | Heroicons Icon Font/CSS" → "Lucide/Other Icons | Heroicons Inline SVG | Copy exact SVG code from heroicons.com"

#### Accessibility Checklist

**CHANGED:**
- "Heroicons icon font accessible (proper font loading and fallbacks)" → "Heroicons inline SVG includes `aria-hidden="true"` for decorative icons"

### Files Changed

- `SKILL.md`: 1358 → 1842 lines (+484 lines)
- `README.md`: Complete rewrite for v2.4.0
- `CHANGELOG.md`: This file

### Migration Guide

If you have existing modules using icon fonts:

1. **Replace icon font classes** with inline SVG from heroicons.com
2. **Add `box-sizing: border-box`** to your universal selector
3. **Check component connections** and apply border alignment rules
4. **Expand dark background CSS** to use multi-layer color forcing
5. **Test thoroughly** in blog context

### Breaking Changes

⚠️ **Icon implementation approach has completely changed**

Old approach (no longer recommended):
```html
<i class="hi-check"></i>
```

New approach (required):
```html
<svg class="icon icon-lg" viewBox="0 0 24 24" fill="none" stroke="currentColor">
  <!-- Full SVG path from heroicons.com -->
</svg>
```

### Known Issues

None. All production issues identified in previous version have been resolved.

### Contributors

- MAN Digital Team

---

## [2.3.0] - 2025-11-11

### Added
- Icon font policy section
- Blog embedding safety guidelines
- Dark background text handling

### Changed
- Updated CSS structure recommendations
- Improved heading hierarchy guidance

---

## [2.1.0] - 2025-11

### Added
- SEO-compliant heading hierarchy (maximum H3)
- Modern native CSS approach (removed Tailwind 4.1 CDN)
- Comprehensive CSS reference documentation

### Changed
- Complete rewrite of CSS generation approach
- Updated all templates and examples

---

## [2.0.0] - 2025

### Added
- Initial comprehensive skill documentation
- React to vanilla JavaScript conversion
- Heroicons icon system
- Blog embedding requirements

### Changed
- Restructured skill organization
- Added reference files and templates
