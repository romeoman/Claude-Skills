# v0.dev to HubSpot Custom Module Converter

## Overview

A comprehensive skill for converting v0.dev React/TypeScript components into production-ready HubSpot custom modules using modern native CSS, Heroicons inline SVG, and vanilla JavaScript.

## What's New in Version 2.4.0

### 🔴 CRITICAL: Icon Implementation Complete Rewrite

- **REMOVED**: Icon font approach (unreliable in HubSpot)
- **ADDED**: Inline SVG from heroicons.com (proven production approach)
  - Step-by-step process for copying exact SVG from heroicons.com
  - CSS for proper icon sizing and color forcing
  - Comprehensive wrong/right examples
  - Icon implementation checklist

**Why the change**: Icon fonts require complex setup, hosting, and break easily. Inline SVG works immediately with no dependencies.

### 🔴 CRITICAL: Box Model & Layout Alignment Rules

- **ADDED**: Mandatory `box-sizing: border-box` guidance
- **ADDED**: Seamless component connection techniques
  - Border alignment rules
  - Margin discipline at connection points
  - Border radius only on outer corners
- **ADDED**: Layout debugging checklist

**Why this matters**: Without `box-sizing: border-box`, width calculations break and components overflow.

### 🔴 CRITICAL: Dark Background Color Forcing

- **EXPANDED**: Multi-layer `!important` strategy
  - Universal selectors
  - Specific element types
  - Content containers
  - Individual elements
  - Link states
- **ADDED**: Opacity-based light text technique
- **ADDED**: Complete dark section examples

**Why this matters**: Blog CSS aggressively overrides text colors on dark backgrounds without multi-layer forcing.

### Updated Checklists & Troubleshooting

- **Module Checklist**: Now includes icon, layout, and box-sizing requirements
- **Troubleshooting**: Comprehensive icon, layout, and dark background fixes
- **Common Mistakes**: New section with 7 common mistakes and correct approaches

## Key Features

### 1. Output Format
- Single Markdown artifact with three code blocks (HTML, CSS, JS)
- Copy-paste ready for HubSpot Design Manager
- No file creation in Docker

### 2. Modern CSS Features
- **CSS Grid & Flexbox** for layouts
- **CSS Custom Properties** for theming and maintainability
- **Modern Functions** (clamp, min, max) for fluid responsive design
- **CSS Nesting** for cleaner, more organized code
- **Modern Selectors** (:has, :is, :where) for powerful styling

### 3. Icon System
- Heroicons inline SVG copied directly from heroicons.com
- CSS-based sizing (.icon-lg, .icon-xl)
- Color forcing with `!important` for reliability
- Full accessibility support with `aria-hidden="true"`

### 4. Layout System
- `box-sizing: border-box` on all elements
- Seamless component connections with matching borders
- Zero-margin discipline at connection points
- Perfect alignment at all screen sizes

### 5. Dark Background Handling
- Multi-layer color forcing with `!important`
- Universal selectors + specific element targeting
- Opacity-based light text variations
- Blog-proof text readability

### 6. Blog Integration
- Width constraints (≤960px)
- **Heading hierarchy**: Maximum H3 at 28px (never H1/H2 for SEO)
- Typography inheritance
- Proper spacing control
- Touch-friendly targets (≥44px)
- Responsive testing at 320px, 768px, 1000px+

## Quick Start

1. Export component from v0.dev
2. Complete pre-conversion assessment
3. Convert icons to Heroicons inline SVG (copy from heroicons.com)
4. Transform JSX to HTML
5. Apply modern native CSS with `box-sizing: border-box`
6. Convert React to vanilla JavaScript
7. Apply multi-layer color forcing for dark backgrounds
8. Generate Markdown artifact
9. Copy-paste into HubSpot Design Manager
10. Test in blog context

## File Structure

```
v0-to-hubspot-converter/
├── SKILL.md                    # Main skill documentation
├── README.md                   # This file
├── CHANGELOG.md                # Version history
├── references/
│   ├── MODERN_CSS_GUIDE.md     # Comprehensive modern CSS guide
│   ├── HEROICONS_REFERENCE.md  # Icon library and patterns
│   ├── BLOG_EMBEDDING.md       # Blog integration requirements
│   ├── CONVERSION_GUIDE.md     # Step-by-step conversion process
│   ├── TAILWIND_TO_CSS.md      # Tailwind class conversion tables
│   └── REACT_TO_VANILLA.md     # React transformation patterns
├── assets/
│   ├── templates/
│   │   ├── module-html-template.html      # HTML structure template
│   │   ├── module-css-template.css        # Full CSS organization
│   │   ├── module-css-minimal.css         # Minimal CSS template
│   │   └── module-js-template.js          # JavaScript module template
│   └── examples/
│       ├── revops-timeline-module.html    # Complete working example
│       ├── revops-timeline-module.css     # Example CSS
│       └── revops-timeline-module.js      # Example JavaScript
```

## Usage

When Claude reads this skill, it will:

1. **Assess** the component complexity and estimate time
2. **Convert** icons to Heroicons inline SVG from heroicons.com
3. **Transform** JSX to semantic HTML
4. **Apply** modern native CSS with proper box-sizing
5. **Implement** seamless component connections
6. **Force** text colors on dark backgrounds with multi-layer approach
7. **Rewrite** React hooks to vanilla JavaScript
8. **Generate** a Markdown artifact with three code blocks
9. **Ensure** blog-safe embedding and responsive design

## Browser Support

All CSS features in this skill are supported in:
- Chrome 90+
- Firefox 88+
- Safari 15+
- Edge 90+

For older browsers, feature queries can provide fallbacks.

## When to Use This Skill

- Converting v0.dev components to HubSpot modules
- Creating custom HubSpot modules from React applications
- Building responsive, interactive HubSpot modules
- Embedding modules cleanly inside blog posts
- Replacing framework-based CSS with modern native CSS
- Creating production-quality modules that work reliably

## Best Practices

1. **Icons**: Always copy exact SVG from heroicons.com - never invent paths
2. **Box Sizing**: Include `box-sizing: border-box` on universal selector
3. **Layout Alignment**: Match border widths, remove connecting borders, zero margins
4. **Dark Backgrounds**: Use multi-layer `!important` color forcing
5. **Mobile-First Design**: Start with mobile styles, enhance for larger screens
6. **CSS Variables**: Scope to `.module-wrapper` (never `:root`)
7. **Heading Hierarchy**: Maximum H3 at 28px - never H1/H2 for blog SEO
8. **Modern Functions**: Leverage clamp(), min(), max() for fluid sizing
9. **Semantic HTML**: Use proper HTML5 elements
10. **Accessibility**: Include ARIA attributes and keyboard navigation
11. **Blog Context**: Always test in blog post embedding
12. **Performance**: Cache DOM queries, avoid layout thrashing

## Troubleshooting

**Icons look wrong/ugly**: You invented SVG paths - copy exact code from heroicons.com
**Components overflow**: Missing `box-sizing: border-box` on universal selector
**Gap between sections**: Margins not set to 0 at connection points
**Double line at connection**: Remove connecting borders with `border-top/bottom: none`
**Text black on dark background**: Use multi-layer `!important` color forcing
**Layout broken**: Verify wrapper constraints and test at multiple widths
**JS not working**: Check console for errors, verify DOM caching
**Responsive issues**: Test all breakpoints with modern CSS functions

## Resources

- [Heroicons](https://heroicons.com/) - Icon library (copy SVG from here)
- [MDN Web Docs - CSS](https://developer.mozilla.org/en-US/docs/Web/CSS) - CSS reference
- [CSS-Tricks](https://css-tricks.com/) - CSS tutorials and guides
- [Modern CSS Solutions](https://moderncss.dev/) - Modern CSS patterns

## Version

**Current Version**: 2.4.0 (Production-Proven Implementation Edition)
**Last Updated**: November 2025

## Key Changes from 2.3.0

1. Icon implementation: icon fonts → inline SVG from heroicons.com
2. Layout system: Added mandatory box-sizing and alignment rules
3. Dark backgrounds: Expanded to multi-layer color forcing
4. Checklists: Updated with new requirements
5. Troubleshooting: Comprehensive fixes for all common issues
6. Common Mistakes: New section with 7 mistakes and solutions

## License

This skill is provided as-is for use with Claude AI and HubSpot Design Manager.

## Contributing

This skill is maintained as part of MAN Digital's content creation toolkit. For questions or improvements, contact the team.
