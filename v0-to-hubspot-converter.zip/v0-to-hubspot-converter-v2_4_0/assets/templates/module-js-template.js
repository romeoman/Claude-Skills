/**
 * ============================================
 * [COMPONENT_NAME] MODULE - module.js
 * HubSpot Custom Module JavaScript Template
 * Created: [DATE]
 * ============================================
 */

(function() {
  'use strict';
  
  // ============================================
  // CONFIGURATION
  // ============================================
  
  const CONFIG = {
    debug: false, // Set to true for console logging during development
    animationDuration: 300,
    componentName: '[component-name]'
  };
  
  // ============================================
  // STATE MANAGEMENT
  // ============================================
  
  /**
   * Application state
   * Centralized state object for all component data
   */
  let state = {
    // Example state properties:
    // activeTab: 0,
    // isOpen: false,
    // selectedItems: [],
    // formData: {}
  };
  
  // ============================================
  // DOM ELEMENT REFERENCES
  // ============================================
  
  /**
   * Cached DOM elements
   * Store references to frequently accessed elements for performance
   */
  let elements = {
    container: null,
    // Add more elements as needed:
    // buttons: [],
    // forms: [],
    // tabs: [],
    // content: null
  };
  
  /**
   * Cache DOM elements
   * @returns {boolean} Success status
   */
  function cacheElements() {
    // Cache the main container
    elements.container = document.querySelector('.' + CONFIG.componentName + '-wrapper');
    
    if (!elements.container) {
      if (CONFIG.debug) {
        console.error('[' + CONFIG.componentName + '] Container not found');
      }
      return false;
    }
    
    // Cache additional elements
    // Example:
    // elements.buttons = elements.container.querySelectorAll('.btn');
    // elements.tabs = elements.container.querySelectorAll('[data-tab-id]');
    // elements.tabContents = elements.container.querySelectorAll('[data-tab-content]');
    // elements.form = elements.container.querySelector('form');
    
    if (CONFIG.debug) {
      console.log('[' + CONFIG.componentName + '] Elements cached successfully');
    }
    
    return true;
  }
  
  // ============================================
  // STATE UPDATE FUNCTIONS
  // ============================================
  
  /**
   * Update state and trigger re-render
   * @param {Object} updates - State updates to apply
   */
  function updateState(updates) {
    // Merge updates into state
    Object.assign(state, updates);
    
    if (CONFIG.debug) {
      console.log('[' + CONFIG.componentName + '] State updated:', state);
    }
    
    // Trigger UI update
    render();
  }
  
  /**
   * Example: Set active tab
   * @param {number} index - Tab index
   */
  // function setActiveTab(index) {
  //   updateState({ activeTab: index });
  // }
  
  /**
   * Example: Toggle open state
   */
  // function toggleOpen() {
  //   updateState({ isOpen: !state.isOpen });
  // }
  
  // ============================================
  // UI UPDATE FUNCTIONS
  // ============================================
  
  /**
   * Main render function
   * Updates the UI based on current state
   */
  function render() {
    if (!elements.container) return;
    
    // Update UI based on state
    // Example: renderActiveTab();
    // Example: renderOpenState();
    // Example: updateButtonStates();
    
    if (CONFIG.debug) {
      console.log('[' + CONFIG.componentName + '] Rendered');
    }
  }
  
  /**
   * Example: Render active tab
   */
  // function renderActiveTab() {
  //   elements.tabs.forEach(function(tab, index) {
  //     const isActive = index === state.activeTab;
  //     tab.classList.toggle('active', isActive);
  //   });
  //   
  //   elements.tabContents.forEach(function(content, index) {
  //     const isVisible = index === state.activeTab;
  //     content.classList.toggle('hidden', !isVisible);
  //   });
  // }
  
  // ============================================
  // EVENT HANDLERS
  // ============================================
  
  /**
   * Handle button clicks
   * @param {Event} event - Click event
   */
  function handleButtonClick(event) {
    const button = event.currentTarget;
    
    // Your logic here
    // Example: const action = button.dataset.action;
    
    if (CONFIG.debug) {
      console.log('[' + CONFIG.componentName + '] Button clicked:', button);
    }
  }
  
  /**
   * Handle tab clicks
   * @param {Event} event - Click event
   */
  // function handleTabClick(event) {
  //   const tabId = parseInt(event.currentTarget.dataset.tabId, 10);
  //   setActiveTab(tabId);
  // }
  
  /**
   * Handle form submission
   * @param {Event} event - Submit event
   */
  // function handleFormSubmit(event) {
  //   event.preventDefault();
  //   
  //   const formData = new FormData(event.target);
  //   const data = Object.fromEntries(formData);
  //   
  //   if (CONFIG.debug) {
  //     console.log('[' + CONFIG.componentName + '] Form submitted:', data);
  //   }
  //   
  //   // Process form data
  // }
  
  /**
   * Handle input changes
   * @param {Event} event - Input event
   */
  // function handleInputChange(event) {
  //   const input = event.target;
  //   const value = input.value;
  //   const name = input.name;
  //   
  //   updateState({
  //     formData: {
  //       ...state.formData,
  //       [name]: value
  //     }
  //   });
  // }
  
  // ============================================
  // EVENT LISTENER ATTACHMENT
  // ============================================
  
  /**
   * Attach all event listeners
   */
  function attachEventListeners() {
    // Attach button click listeners
    // Example:
    // elements.buttons.forEach(function(button) {
    //   button.addEventListener('click', handleButtonClick);
    // });
    
    // Attach tab click listeners
    // Example:
    // elements.tabs.forEach(function(tab) {
    //   tab.addEventListener('click', handleTabClick);
    // });
    
    // Attach form submit listener
    // Example:
    // if (elements.form) {
    //   elements.form.addEventListener('submit', handleFormSubmit);
    // }
    
    if (CONFIG.debug) {
      console.log('[' + CONFIG.componentName + '] Event listeners attached');
    }
  }
  
  // ============================================
  // HELPER FUNCTIONS
  // ============================================
  
  /**
   * Find element by data attribute
   * @param {string} attribute - Data attribute name
   * @param {string} value - Attribute value
   * @returns {Element|null}
   */
  function findElementByData(attribute, value) {
    return document.querySelector('[data-' + attribute + '="' + value + '"]');
  }
  
  /**
   * Toggle class on element
   * @param {Element} element - DOM element
   * @param {string} className - Class name to toggle
   */
  function toggleClass(element, className) {
    if (element.classList.contains(className)) {
      element.classList.remove(className);
    } else {
      element.classList.add(className);
    }
  }
  
  /**
   * Debounce function
   * @param {Function} func - Function to debounce
   * @param {number} wait - Wait time in milliseconds
   * @returns {Function}
   */
  function debounce(func, wait) {
    let timeout;
    return function executedFunction() {
      const context = this;
      const args = arguments;
      const later = function() {
        timeout = null;
        func.apply(context, args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }
  
  // ============================================
  // INITIALIZATION
  // ============================================
  
  /**
   * Initialize the module
   */
  function init() {
    if (CONFIG.debug) {
      console.log('[' + CONFIG.componentName + '] Initializing...');
    }
    
    // Cache DOM elements
    if (!cacheElements()) {
      console.error('[' + CONFIG.componentName + '] Initialization failed - elements not found');
      return;
    }
    
    // Attach event listeners
    attachEventListeners();
    
    // Initial render
    render();
    
    if (CONFIG.debug) {
      console.log('[' + CONFIG.componentName + '] Initialized successfully');
    }
  }
  
  // ============================================
  // CLEANUP (Optional)
  // ============================================
  
  /**
   * Cleanup function for removing event listeners
   * Call this if the module needs to be destroyed
   */
  // function cleanup() {
  //   // Remove event listeners
  //   // Clear intervals/timeouts
  //   // Reset state
  //   
  //   if (CONFIG.debug) {
  //     console.log('[' + CONFIG.componentName + '] Cleaned up');
  //   }
  // }
  
  // ============================================
  // ENTRY POINT
  // ============================================
  
  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    // DOM already loaded
    init();
  }
  
  // Optional: Expose cleanup function globally if needed
  // window.cleanupComponent = cleanup;
  
})();

/*
=================================================
USAGE NOTES:
1. Replace [COMPONENT_NAME] and [component-name] throughout
2. Uncomment and customize the example functions as needed
3. Add your state properties to the state object
4. Cache your DOM elements in cacheElements()
5. Implement your event handlers
6. Update the render() function to reflect state changes
7. Set CONFIG.debug = true during development
8. Test thoroughly in HubSpot preview
=================================================
*/
