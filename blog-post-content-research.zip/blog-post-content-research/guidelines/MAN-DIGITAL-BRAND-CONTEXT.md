# MAN Digital Brand Context

**MANDATORY READING: Reference this document during planning phase to ensure every blog post reflects MAN Digital's positioning and differentiators.**

---

## 🎯 Core Positioning Statement

**WE DON'T WRITE ABOUT HUBSPOT FEATURES—WE WRITE ABOUT HOW REVOPS SUPPORTS GTM LEADERS USING HUBSPOT AS THE ENABLER.**

MAN Digital is a **RevOps consultancy** that standardizes revenue operations on HubSpot. We're process-first, tool-second—mapping data models and playbooks, then wiring tools so signals drive action.

---

## 👥 Client Profile (Who We Serve)

### Primary Audience
- **Company Size**: Mid-to-large B2B firms (€5M+ revenue)
- **Team Structure**: Multi-market teams
- **Geography**: Priority Poland; opportunistic in DACH, Nordics, UK
- **HubSpot Status**: HubSpot already in place or planned for implementation

### Decision Makers

**Primary Buyer:**
- Head of Marketing
- CMO
- Marketing Manager

**Secondary Buyers:**
- CRO (Chief Revenue Officer)
- Head of Sales / Sales Manager
- Head of CS / CS Operations
- CEO (Series A companies, max 250 employees)

### Pain Points They Experience
- **Disconnected systems** causing manual admin work
- **No trusted forecasts** - leaders flying blind
- **Value erosion** post go-live (dashboards decay, adoption slips)
- **Siloed wins** from tool-led vendors that don't translate to actual processes
- **Reactive CS operations** with unknown churn risk
- **Bad data** breaking routing and wasting time
- **Entropy post-launch** with no owner for continuous improvement

---

## 🏢 Company Approach & Methodology

### Three-Phase Framework: **Assessment → Backbone → Run**

**1. Assessment Phase**
- Operational Reality Assessment
- Portal audit
- Process mapping
- Identify gaps and opportunities

**2. Backbone Phase**
- HubSpot process/data standardization
- Data model design
- Automations and workflows
- Process diagrams and SOPs
- Enablement

**3. Run Phase (Ongoing)**
- RevOps as a Service with SLAs
- Weekly status updates
- Backlog execution
- Quality assurance
- Renewal roadmaps
- Continuous improvement each sprint

### Core Philosophy

**Process-First, Tool-Second:**
- We map the data model and playbooks FIRST
- Then wire tools so signals drive action in HubSpot
- Tools serve the process, not the other way around

**Ongoing Operations, Not One-Off Projects:**
- Weekly cadence with SLA-based service
- Continuous governance and improvement
- Prevents value erosion and entropy
- Keeps systems improving sprint over sprint

---

## 🎁 Service Offerings

### Flagship Service
**RevOps as a Service**
- Standardize revenue operations on HubSpot
- Unify tools and data
- Instrument reliable forecasting and attribution
- Stand up Customer Success health scoring
- Run it all with SLAs and weekly cadence

### Core Services

**1. RevOps Foundation (Assessment & Backbone)**
- Operational Reality Assessment
- HubSpot backbone for process, data model, automations
- Enablement and SOPs
- **Benefit**: Faster time-to-value, shared truth, de-risked scope

**2. Sales Ops & Coaching Visibility**
- Sales methodology operationalization (SPIN, MEDDPICC, Sandler)
- Pipelines, playbooks, activity/forecast dashboards
- Coaching views for managers
- **Benefit**: Predictable pipeline, rep lift, forecast accuracy

**3. Marketing Ops & Attribution**
- Attribution-first reporting
- Multi-Touch Attribution (MTA) dashboards
- Lifecycle routing and nurture automation
- Campaign source tracking
- **Benefit**: Credible ROI, fewer rejected leads, smarter budget allocation

**4. CS Ops & Health Scoring**
- Customer health score models
- Ticket integration and automation
- CS playbooks and enablement
- Real-time churn alerts
- **Benefit**: Early churn flags, higher NRR, consistent CS delivery

**5. Data Quality & Enrichment**
- Pre-ingest validation and enrichment
- Deduplication logic
- Scheduled data hygiene
- Validation rules and enrichment APIs
- **Benefit**: Clean segments, reliable workflows, better reporting

**6. Run & Governance (SLA-based)**
- Weekly status updates
- Backlog management
- Naming convention hygiene
- Renewal roadmaps
- NPS and review management
- **Benefit**: Continuous improvement, transparency, resilience

**7. Integrations & Data Layer (Add-on)**
- Custom implementations architected to client's data model
- Custom objects, APIs, apps
- Custom AI agents
- **Benefit**: Signals flow to HubSpot, fewer manual fixes

### Additional Services
- HubSpot Onboarding
- Custom Integrations

---

## 🥊 Key Differentiators

### What Makes MAN Digital Different

**1. Process-First, Tool-Second Approach**
- **Others**: Lead with tool features ("look what this platform can do!")
- **MAN Digital**: Map your processes and data model first, then configure tools to serve those processes
- **Result**: Tools that actually drive action, not just pretty dashboards

**2. Ongoing Operations Model (Not One-Off Projects)**
- **Others**: One-off projects that decay after launch
- **MAN Digital**: RevOps as a Service with weekly cadence, SLAs, continuous improvement
- **Result**: Systems that keep improving, value that compounds over time

**3. Assessment-Driven Implementation**
- **Others**: Dive straight into configuration
- **MAN Digital**: Start with Operational Reality Assessment to understand current state
- **Result**: De-risked scope, faster time-to-value, implementations that fit reality

**4. Sales Methodology Operationalization**
- **Others**: Basic CRM setup with generic pipelines
- **MAN Digital**: Operationalize proven methodologies (SPIN, MEDDPICC, Sandler) in HubSpot
- **Result**: Sales process that enables coaching and forecast accuracy

**5. Attribution Framework (Not First-Touch Only)**
- **Others**: Simple first-touch or last-touch attribution
- **MAN Digital**: Multi-Touch Attribution frameworks that marketing can defend
- **Result**: Credible ROI, better budget allocation, sales accepts lead quality

**6. Health Scoring & CS Enablement**
- **Others**: Reactive support, ticketing doesn't equal health
- **MAN Digital**: Proactive health scoring with playbooks and real-time alerts
- **Result**: Early churn intervention, higher NRR

**7. HubSpot as the Backbone (Not Tool Chaos)**
- **Others**: Best-of-breed tool sprawl with integration chaos
- **MAN Digital**: Standardize on HubSpot as single source of truth, integrate strategically
- **Result**: Unified data model, reliable reporting, fewer sync failures

---

## 💪 Team Expertise & Capabilities

### Core Competencies

**Revenue Operations Expertise:**
- Process mapping and standardization
- Data model design
- Workflow automation
- Forecasting and attribution frameworks
- Cross-functional alignment (Marketing, Sales, CS)

**HubSpot Technical Expertise:**
- Portal architecture and configuration
- Custom objects and properties
- Workflow automation
- API integrations
- Custom apps and AI agents
- Operations Hub advanced features

**Go-To-Market Operations:**
- Sales methodology implementation (SPIN, MEDDPICC, Sandler)
- Marketing attribution and lifecycle management
- Customer Success health scoring
- Data quality and enrichment
- Reporting and analytics

**Project Management & Governance:**
- SLA-based service delivery
- Weekly status and backlog management
- Change management and enablement
- Documentation (SOPs, process diagrams)
- Continuous improvement frameworks

**Systems Integration:**
- API architecture and custom integrations
- Data layer design
- Multi-system orchestration
- Pre-ingest validation
- Custom development when needed

---

## 📝 Content Guidelines: How to Reflect MAN Digital's Brand

### When Writing Blog Posts

**Always Position As:**
- ✅ RevOps team solving GTM leader problems
- ✅ HubSpot as the enabler, not the hero
- ✅ Process-first mindset (map processes, then configure tools)
- ✅ Ongoing partnership, not one-off project
- ✅ Strategic operator, not just admin

**Never Position As:**
- ❌ HubSpot fanboys selling platform features
- ❌ Generic marketing automation agency
- ❌ One-off implementation shop
- ❌ Tool-first consultants

### Use Cases to Reference

When relevant to the blog topic, reference these real use cases:
- Sales methodology operationalization (SPIN, MEDDPICC)
- Multi-Touch Attribution frameworks
- Customer health scoring models
- Data quality and enrichment workflows
- Weekly SLA-based RevOps service
- Assessment → Backbone → Run methodology

### Language & Tone

**Use terms like:**
- "Standardize revenue operations"
- "Process-first, tool-second"
- "HubSpot as the backbone"
- "RevOps as a Service"
- "Assessment → Backbone → Run"
- "Operationalize [methodology/process]"
- "Single source of truth"
- "SLA-based service delivery"

**Avoid terms like:**
- "Best-of-breed tools" (implies tool sprawl)
- "Revolutionary platform" (too vendor-focused)
- "One-size-fits-all solution" (we do custom assessment)
- "Set it and forget it" (we provide ongoing ops)

### Competitive Context

When discussing alternatives (subtly, never by name):

**DIY Approach:**
- Leads to: Disconnected systems, manual admin, no trusted forecasts
- MAN Digital provides: Assessment, backbone, ongoing governance

**One-Off Projects:**
- Leads to: Value erosion, decay, no owner
- MAN Digital provides: SLA-based continuous improvement

**Tool-Led Vendors:**
- Leads to: Siloed wins, signals don't drive action
- MAN Digital provides: Process-first approach, signals drive HubSpot workflows

---

## ✅ Brand Validation Checklist

Before publishing any blog post, verify:

- [ ] **Positioning Clear**: RevOps consultancy supporting GTM leaders, not HubSpot feature seller
- [ ] **Process-First**: Content emphasizes process/strategy before tools/features
- [ ] **Client Relevance**: Speaks to mid-to-large B2B firms with HubSpot
- [ ] **Decision Maker Focus**: Addresses Marketing Leaders, CROs, Sales Leaders, or CS Ops
- [ ] **Pain Points Referenced**: Addresses real client problems (disconnected systems, no trusted forecasts, value erosion, etc.)
- [ ] **Differentiators Present**: Shows MAN Digital's unique approach (assessment-first, ongoing ops, process-first, etc.)
- [ ] **HubSpot Context**: HubSpot positioned as enabler, not the hero
- [ ] **Ongoing Partnership**: Implies continuous improvement, not one-off solution
- [ ] **Service Relevance**: Connects to MAN Digital's actual service offerings
- [ ] **Methodology Reference**: When relevant, references real frameworks (SPIN, MEDDPICC, health scoring, attribution, etc.)
- [ ] **No Tool Worship**: Avoids generic tool feature lists without process context
- [ ] **Strategic Positioning**: Positions readers as strategic operators, not just admins

---

## 🎯 Quick Reference: Brand DNA

**WHO WE ARE**: RevOps consultancy standardizing revenue operations on HubSpot

**WHO WE SERVE**: Mid-to-large B2B firms (€5M+) with HubSpot, primarily Marketing Leaders and CROs

**WHAT WE DO**: Assessment → Backbone → Run methodology with SLA-based ongoing service

**HOW WE'RE DIFFERENT**: Process-first (not tool-first), ongoing operations (not one-off projects), assessment-driven (not assumptions)

**WHAT WE ENABLE**: Unified data, trusted forecasts, proactive CS, credible attribution, continuous improvement

**OUR LENS**: RevOps supporting GTM leaders, HubSpot as the enabler

---

**Remember: Every blog post should pass the "MAN Digital smell test" - would a reader clearly understand we're RevOps operators who think process-first and deliver ongoing value, not just HubSpot implementers?**
