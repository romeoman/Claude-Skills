# SEO guidelines

### Keyword Integration
*   **Natural placement**: Keywords should flow naturally
*   **Semantic variations**: Use related terms and synonyms
*   **Strategic density**: 1-2% keyword density
*   **Title optimization**: Include primary keyword in H1
### Meta Elements
#### Title Tags (50-60 characters)
Pattern: `[Topic] for RevOps: [Benefit] | MAN Digital`
Example: "HubSpot Custom Objects for RevOps: Unify Revenue Data | MAN Digital"
#### Meta Descriptions (150-160 characters)
Pattern: `Transform [challenge] with [solution]. Learn how RevOps teams use [topic] to [benefit]. [CTA].`
Example: "Transform siloed data with custom objects. Learn how RevOps teams unify revenue operations in HubSpot. Get our implementation guide."
### Header Hierarchy
*   **H1**: One per page, includes primary keyword
*   **H2**: Major sections, use keyword variations
*   **H3**: Subsections, use long-tail keywords
*   **H4**: Lists and details, natural language