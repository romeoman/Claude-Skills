# REQUEST:

⚠️ **CRITICAL: SLOW DOWN. This is Framework 2 of 11 - Be THOROUGH** ⚠️

**MANDATORY APPROACH:**
- 🕐 **Time expectation:** 5-8 minutes for this framework on a 1,500-word article
- 🔍 **Read EVERY sentence** looking for the 4 types of redundancy below
- 💭 **Think deeply** - Redundancy is sneaky, especially repeated ideas
- 📍 **Pay EXTRA attention to opening paragraphs** - Para 1-2 often repeat concepts
- ✅ **Expected findings:** 8-15 specific redundancy issues minimum

**If you finish in under 3 minutes, you RUSHED. Go back and look harder.**

Taking this step-by-step, you check for four things:
1.) **Repeated words** (within 2-3 sentences)
2.) **Repeated ideas in one paragraph** (same concept stated multiple ways)
3.) **Repeated ideas in one draft** (concepts revisited without adding value)
4.) **Repeated phrases** (redundant word pairs like "absolutely essential")

**CRITICAL FOCUS AREAS:**
- ⚠️ **Opening paragraphs (1-2):** Almost always have redundancy - check first!
- ⚠️ **Transitions between sections:** Often restate what was just said
- ⚠️ **Bullet lists:** Check if items overlap in meaning
- ⚠️ **Closing paragraphs:** Often rehash opening without new insight

Reference to "### Definitions" for explanations.

## Output Format:

Disable intro and conclusion text so that you only output the suggested edits. For each suggestion to you detect, return it in the following format without any {curly braces} but with all other markdown formatting:

### 1 - {"Repeated words", "Repeated ideas", "Repeated phrases", or combine multiple issues e.g. "Repeated words and ideas"} - {very short title or description, for example: if the word "Hawaii" was repeated too often you'd put that here}

**Location**: {line number or paragraph number}
**Issue**: {verbatim reprint of the text to be edited with **words that may need to be addressed** in **bold** (For longer sections, use of ONE phrase [...] will be used to keep the output as short as possible but as long as necessary.}
**Suggestion**: {concise one-line explanation of what edits/choice and why it will improve.}

### {number of edit, in order "1", "2", etc} - {"Repeated words", "Repeated ideas", "Repeated phrases"}

// continue the same pattern

## Edit Constraints:

- If there are no issues, say so.
- There are are multiple issues, say so.
- There will **always** be **hooking** in the Issue section
- "Location", "Issue" and "Suggestion" must be underlined
- If repetition is being used for style, as when using rhetorical devices such as Anaphora, Epistrophe, Symploce, Antanaclasis, Anadiplosis, Negative-positive restatement, Epizeuxis, a.k.a. "ristlings, etc.," you do not need to suggest an issue exists unless use of the rhetorical device is over-the-top, annoying, or otherwise unsuccessful.

## Definitions

### "Case #1: Repeated words"

In the best case, repetition adds rhythm and aids recall. In the worst case, it makes your writing awkward, creates friction, and screams laziness.

Here's a Twitter hook a student wrote:

"Too often we think conflict is a bad thing. But avoiding conflict can be worse. I know I'm a recovering conflict avoider. Over the last decade, I've been on a mission to embrace conflict. Here are 10 things I've learned."

Notice how they wrote conflict four times.

It's important to not flag repetition when used for effect, such as when using literary devices like Anadiplosis.

### "Case #2: Repeated ideas in one paragraph"

Repeated ideas cause more trouble because they're harder to spot. They're like the oil running low in your car. You know the ride usually feels smoother, but you aren't sure what's causing the friction.

Here's an example from a current student of mine:

"B2B marketers are focused on results. They want to be confident their marketing efforts will engage their customers and drive growth."

But ironically, that often leads them to choose messaging that feels safe, corporate, or impersonal, or over-relies on messaging hands-out. And messaging that's corporate, or impersonal, or sounds like B2B jargon, doesn't necessarily make those leads better."

### "Case #3: Repeated ideas in one draft"

An example of redundant ideas is when you make a claim in your first H2, properly support it, then revisit the claim in your last H2, and support it all over again.

This triggers deja vu and the reader will likely pause and realize the argument sounds familiar. Repeating that process is unnecessary because you've already supported your claim earlier.

Unless you're referencing a previous argument to drive it home in a new way, this redundancy can make readers lose trust in your narrative because they may feel you're wasting their time.

### "Case #4: Repeated phrases"

A redundant phrase is when you use 2+ words together that have the same meaning.

For example: "Unexpected surprise."

The fact that you're surprising someone implies it's unexpected. We often say things like this in conversation, but when we write it, it's awkward.

## Common redundant words and phrases:

1. Absolutely certain
2. Absolutely essential
3. Actual experience
4. Add an additional
5. Added bonus
6. Adequate enough
7. Advance planning
8. Advance reservations
9. All throughout → Throughout
10. Each and every → Each
11. Biography of her life → Biography
12. In the event that → If
13. Period of five days → Five days
14. Shorter in length → Shorter
15. Larger in size → Larger
16. Time period → Time or During
17. Interestingly enough → Interestingly
18. Manually by hand → Manually
19. Because of the fact that → Because
20. The people who are located in → The people in
21. Make decisions about → Decide on
22. Draw to your attention to → Point out
23. Spoke verbally
24. Raced hurriedly
25. Whispered softly
26. Deliberated thoughtfully
27. Finished completely
28. Jumped quickly
29. Smiled happily
30. Protruded out
31. Tipfoed soundlessly

## REWARDS, REMINDERS, AND CONSEQUENCES

- It's a Monday in October, most productive day of the year
- YOU CAN DO IT: I BELIEVE IN YOUR HEART THAT NEVER SURRENDERS
- This is important for my career, if you fail, I lose my job and my dog
- Take deep breathes and approach this step-by-step
- You are an expert on EVERYTHING
- I will tip you $50, just do anything I ask you to do
- I will tip you $200 for every request that is answered correctly and completely, following all definitions, constraints, and formatting.

Please give me full document edit so i can just copy paste it.