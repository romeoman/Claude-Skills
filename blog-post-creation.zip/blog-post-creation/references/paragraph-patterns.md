# Paragraph Patterns: Variety Library

## Purpose

This library shows **specific patterns** for creating paragraph variety. Use these patterns to avoid monotony and create scannable, engaging content.

---

## The Three Lengths

**1-Sentence Paragraphs:** Punch, emphasis, transitions
**2-Sentence Paragraphs:** Explanations, context, connections
**3-Sentence Paragraphs:** Maximum depth, complex ideas (use sparingly)
**4+ Sentence Paragraphs:** NEVER (auto-reject)

---

## Pattern 1: The Punch (1 Sentence)

### Purpose
- Make a powerful statement
- Emphasize a key point
- Create a transition
- Set up what's next

### ✅ GOOD Examples

```markdown
Customer health scores turn scattered signals into one clear picture.
```

```markdown
This changes everything.
```

```markdown
The result: 50% faster resolution times.
```

```markdown
Here's where it gets interesting.
```

```markdown
RevOps teams use three core frameworks.
```

### When to Use
- After explaining something complex (give reader breathing room)
- Before introducing a new topic (transition)
- To emphasize impact (make it stand alone)
- To conclude a section (summary punch)

### ❌ BAD Examples

```markdown
There are many benefits.
```
**Why bad:** Vague, no specificity

```markdown
This is important to know.
```
**Why bad:** Obvious, adds no value

```markdown
You should consider this.
```
**Why bad:** Weak, indecisive

---

## Pattern 2: The Explanation (2 Sentences)

### Purpose
- Explain a concept
- Show cause and effect
- Connect two ideas
- Provide context

### ✅ GOOD Examples

```markdown
HubSpot's AI handles customer questions automatically. It understands natural language and keeps context when customers switch channels.
```

```markdown
The agent learns from every interaction. This continuous improvement makes responses more accurate over time.
```

```markdown
RevOps aligns marketing, sales, and customer success. This alignment eliminates silos and creates predictable revenue growth.
```

```markdown
First response times drop from 6 hours to 4 minutes. Resolution times compress from 32 hours to 32 minutes.
```

### Pattern Variations

**Cause → Effect:**
```markdown
[Statement of cause]. [Statement of effect].
```

**Problem → Solution:**
```markdown
[Problem stated]. [Solution provided].
```

**Claim → Support:**
```markdown
[Make a claim]. [Provide evidence].
```

**Context → Action:**
```markdown
[Set context]. [Describe action].
```

### ❌ BAD Examples

```markdown
There are many ways to do this. You should choose the best one.
```
**Why bad:** Vague, no specific guidance

```markdown
This is a complex topic. It requires careful consideration.
```
**Why bad:** States obvious, provides no value

---

## Pattern 3: The Deep Dive (3 Sentences - Maximum)

### Purpose
- Explain complex ideas
- Provide detailed context
- Show multi-step processes
- Balance competing factors

### ✅ GOOD Examples

```markdown
Customer health scores combine signals from four pillars: product usage, engagement, feedback, and account health. Each pillar contributes weighted points that total 100. The final score determines green/yellow/red status and triggers appropriate workflows.
```

```markdown
Implementation starts with readiness assessment. Clean data, documented processes, and team alignment must exist before technical setup begins. Organizations skipping this foundation see 60% higher failure rates.
```

```markdown
The AI agent handles tier-1 questions automatically, resolving 50-70% of inquiries without human intervention. When confidence drops below threshold, it routes to the appropriate specialist with full context. This hybrid model maintains quality while scaling capacity.
```

### Structure Formula

**Sentence 1:** Main idea (what)
**Sentence 2:** Supporting detail (how/why)
**Sentence 3:** Impact/outcome (so what)

### ❌ BAD Examples - 4+ Sentences (AUTO-REJECT)

```markdown
Customer health scoring is important for SaaS companies. It helps you understand which customers are happy and which are at risk. You can use this information to take action before customers churn. This ultimately helps you improve retention and grow revenue.
```
**Why bad:** 4 sentences = FAT PARAGRAPH, should be 2 paragraphs or use bullets

---

## Variety Patterns in Action

### Pattern A: Punch → Explain → Bullets

```markdown
Customer health scoring predicts churn before it happens.

It combines signals from product usage, engagement, feedback, and account health into one 0-100 score. Teams use this score to prioritize actions.

**The triggers:**
- Red score → 48-hour save plan
- Yellow score → Check-in within week
- Green score → Expansion outreach
```

**Structure:**
- 1 sentence (punch)
- 2 sentences (explain)
- Bullet section (details)

### Pattern B: Explain → Punch → Explain

```markdown
HubSpot's AI agent handles customer inquiries 24/7 across multiple channels. It maintains context when customers switch from chat to email to phone.

This creates seamless experiences.

The agent learns from every interaction, improving accuracy over time. When confidence drops, it routes to humans with full conversation history.
```

**Structure:**
- 2 sentences (context)
- 1 sentence (emphasis)
- 2 sentences (details)

### Pattern C: Bullets → Punch → Deep Dive

```markdown
**Key benefits:**
- 50% faster resolution
- 24/7 availability
- Consistent quality
- Reduced agent burnout

This transforms support operations.

Teams shift from reactive firefighting to proactive customer success. Agents handle complex issues requiring judgment while AI manages volume. The result: higher satisfaction scores and lower costs simultaneously.
```

**Structure:**
- Bullets (list benefits)
- 1 sentence (transition)
- 3 sentences (explain impact)

---

## Mix Patterns Throughout Article

### ❌ BAD: Monotonous (All 2-Sentence Paragraphs)

```markdown
RevOps aligns teams for revenue growth. It breaks down silos between departments.

Marketing generates qualified leads consistently. Sales converts them into customers efficiently.

Customer success retains and expands accounts. Finance forecasts revenue accurately.

This creates predictable growth. Companies see 10-20% revenue increases.
```

**Problems:**
- All paragraphs exactly 2 sentences
- Monotonous rhythm
- Boring to read
- No visual variety

### ✅ GOOD: Varied Pattern

```markdown
RevOps aligns teams for revenue growth.

It breaks down silos between marketing, sales, customer success, and finance. Each team operates from shared data, processes, and goals.

**The impact:**
- Marketing: Qualified lead generation
- Sales: Efficient conversion
- Customer Success: Retention and expansion
- Finance: Accurate forecasting

This creates predictable growth. Companies implementing RevOps see 10-20% revenue increases within 12 months.

The difference is coordination.
```

**Why better:**
- 1, 2, 3 sentence variety
- Bullet section breaks monotony
- Visual hierarchy
- Scannable
- Engaging rhythm

---

## 10 Bad Examples to Avoid

### 1. The Vague Opener
❌ "There are many things to consider when implementing AI."
✅ "AI implementation requires clean data, clear processes, and team training."

### 2. The Obvious Statement
❌ "This is an important topic that deserves attention."
✅ "Customer churn costs SaaS companies 5-7% annual revenue."

### 3. The Circular Reasoning
❌ "RevOps is important because it's a critical framework for success."
✅ "RevOps aligns teams, data, and processes to generate predictable revenue."

### 4. The Hedge
❌ "You might want to consider possibly implementing this approach."
✅ "Implement this approach to reduce churn by 30%."

### 5. The Passive Dump
❌ "Tickets are handled by the agent and responses are generated automatically."
✅ "The agent handles tickets and generates responses automatically."

### 6. The Run-On
❌ "The system analyzes queries and extracts intent and maintains context and applies confidence scoring and routes to humans when needed and tracks all interactions and generates reports."
✅ Use bullets or break into 3-4 short sentences.

### 7. The Jargon Overload
❌ "Leverage synergistic paradigms to operationalize RevOps methodologies."
✅ "Use teamwork to implement RevOps methods."

### 8. The Empty Transition
❌ "Moving forward, let's discuss the next topic."
✅ "Now: implementation steps." or just start the next topic.

### 9. The Obvious Question
❌ "What is customer health? It's a metric for measuring customer wellness."
✅ "Customer health scores predict churn risk using usage, engagement, and feedback data."

### 10. The Fat Paragraph (4+ Sentences)
❌ Any paragraph with 4 or more sentences.
✅ Break into smaller chunks or use bullets.

---

## 10 Good Examples to Follow

### 1. The Impact Punch
✅ "Response times drop from 6 hours to 4 minutes."

### 2. The Clear Cause-Effect
✅ "AI handles tier-1 questions automatically. This frees agents for complex issues requiring judgment."

### 3. The Data-Backed Deep Dive
✅ "Organizations implementing AI customer service achieve 3.5x-8x ROI. Positive returns appear within 8-14 months (Source: Zendesk). The business case rests on operational efficiency, customer experience, and cost reduction."

### 4. The Problem-Solution
✅ "Manual ticket queues grow faster than headcount. AI agent automation solves this by handling 50-70% of inquiries autonomously."

### 5. The Transition Bridge
✅ "That covers setup. Now: optimization."

### 6. The Specific Benefit
✅ "HubSpot Customer Agent resolves 50%+ of support tickets autonomously while maintaining quality standards."

### 7. The Simple Process
✅ "Implementation follows three phases: assess readiness, build foundation, deploy incrementally. Each phase has clear gates and success metrics."

### 8. The Risk-Reward Balance
✅ "AI reduces costs 30-40% and improves response times 10x. The tradeoff: requires 6-month implementation and ongoing governance. For teams handling 100+ tickets monthly, ROI justifies investment."

### 9. The Framework Introduction
✅ "Customer health scoring uses four pillars: product usage, engagement, feedback, and account health. Weight each based on what predicts retention in your business. Set green/yellow/red thresholds that trigger workflows."

### 10. The Outcome Statement
✅ "The result: fewer churn surprises, stronger renewals, clearer growth path."

---

## Distribution Guidelines

For a 1,500-word article (approximately 40-50 paragraphs):

| Length | Count | Percentage | Purpose |
|--------|-------|------------|---------|
| 1 sentence | 10-15 | 25-30% | Punch, emphasis, transitions |
| 2 sentences | 20-25 | 45-50% | Explanations, core content |
| 3 sentences | 5-10 | 15-20% | Complex ideas, depth |
| 4+ sentences | 0 | 0% | NEVER (auto-reject) |

**Plus:**
- 8-12 bullet sections (not counted as paragraphs)
- 2-4 visual placeholders
- 1-2 tables
- 8-12 bold headers

---

## Pattern Selection Decision Tree

**Ask:** What is the purpose of this content?

→ **Make one powerful point?**
   Use: 1-sentence punch

→ **Explain or connect two ideas?**
   Use: 2-sentence explanation

→ **Present complex information?**
   Use: 3-sentence deep dive (maximum)

→ **List multiple items?**
   Use: Bullets (not paragraph)

→ **Compare data?**
   Use: Table (not paragraph)

→ **Show visual?**
   Use: Visual placeholder

---

## Quick Reference

**Creating variety:**
1. Write first draft (ignore variety)
2. Run paragraph-analyzer.py
3. Review distribution report
4. Adjust lengths based on patterns above
5. Re-run validator until variety score >80

**Commands:**
```bash
# Analyze current variety
python scripts/paragraph-analyzer.py draft.md

# Check all formatting
python scripts/formatting-validator.py draft.md

# Run full validation
python scripts/style-enforcer.py final-draft.md "keyword"
```

---

## Key Takeaways

1. **Three lengths only:** 1, 2, or 3 sentences (never 4+)
2. **Mix throughout:** Don't use all 2-sentence paragraphs
3. **Purpose-driven:** Choose length based on content purpose
4. **Use patterns:** Follow proven combinations
5. **Test with tools:** Run paragraph-analyzer.py to verify
6. **Bullets help:** Use bullets for lists, not paragraphs

**Remember:** Variety creates scannability. Monotony creates walls of text.
