# Editing Excellence: Real Examples of Thorough vs Rushed Work

## Purpose

This document shows what THOROUGH editing looks like vs RUSHED editing, using real examples.

**Use this as your quality standard:** If your editing doesn't look like the "Thorough" examples below, you RUSHED and need to redo it.

**IMPORTANT:** This thoroughness standard applies to **ALL 11 editing frameworks**, not just Framework 1. Each framework has:
- ⚠️ Warnings about slowing down
- ⏱️ Time expectations (3-8 minutes per framework)
- 🔍 Specific patterns to hunt for
- ✅ Expected minimum findings

**Total editing time expected: 60-90 minutes for all 11 frameworks on a 1,500-word article**

---

## The Thoroughness Standard

**A properly edited 1,500-word article should have:**
- **20-30+ specific findings** with exact locations
- **Multiple synthesis notes** combining related edits
- **Concrete suggestions** in the original writing style
- **15-20 minutes minimum** of careful review time

**If you have fewer than 15 findings, you RUSHED.**
**If you finished in under 10 minutes, you RUSHED.**

---

## Example 1: Opening Paragraph Redundancy

### RUSHED EDIT (❌ Unacceptable):
"The opening could be tighter."

### THOROUGH EDIT (✅ What We Want):

**1 - Tighten opening and reduce redundancy**
Location: Paragraph 1 (first two sentences)
Issue: Two sentences repeat **"time spent"** and **"lost to tactics vs. strategy"**; second sentence restates the first with similar phrasing.
Suggestion: Merge for punch and specificity: "Social media managers spend 3–5 hours a day creating, scheduling, and tracking across platforms—15–25 hours a week lost to execution instead of strategy."

**Why this is thorough:**
- Identifies EXACT location (Paragraph 1, first two sentences)
- Explains SPECIFIC problem (repetition of concepts)
- Provides CONCRETE rewrite in the original style
- Shows what to change and why

---

## Example 2: Headers

### RUSHED EDIT (❌ Unacceptable):
"Headers could be more engaging."

### THOROUGH EDIT (✅ What We Want):

**3 - Sharpen subhead to outcome**
Location: H3 "What Is a Social Agent?"
Issue: **Definition header is generic**; style guide favors outcome-first framing.
Suggestion: "What a Social Agent Does (and Why It Matters)"

**10 - Add outcome-first subhead**
Location: H3 "AI-Powered Content Generation"
Issue: **Descriptive, not outcome-driven.**
Suggestion: "AI-Powered Content Generation That Sounds Like Your Brand"

**Why this is thorough:**
- Identifies EVERY header that needs improvement
- Explains the principle (outcome-first vs descriptive)
- Provides concrete alternatives
- Follows the style guide requirement

---

## Example 3: Statistics Without Context

### RUSHED EDIT (❌ Unacceptable):
"Add more specificity to stats."

### THOROUGH EDIT (✅ What We Want):

**26 - Success metrics: remove generic claims, add numbers**
Location: "Real-World Implementation Success" bullets
Issue: Vague magnitude (**"2–3x more posts," "20–30%"**) without timeframe or baseline; **"significantly" is filler.**
Suggestion: Add timeframe and baseline:
- Content volume: 2–3x more posts/month in 30 days without adding headcount
- Engagement: +20–30% within 8 weeks via optimized timing and formats
- Consistency: unified voice across channels and teams from day one
- Strategic capacity: shift 10–15 hours/week to planning and analysis
- Cost efficiency: reduce external content spend by 25–40%

**Why this is thorough:**
- Shows BEFORE and AFTER for every bullet
- Adds timeframes ("in 30 days", "within 8 weeks")
- Adds baselines and context
- Removes filler words ("significantly")
- Provides complete rewrite

---

## Example 4: Active Voice and Strong Verbs

### RUSHED EDIT (❌ Unacceptable):
"Use more active voice."

### THOROUGH EDIT (✅ What We Want):

**2 - Use active voice and avoid indirect phrasing**
Location: Paragraph 2 (sentence 1–2)
Issue: **"cuts that time in half"** is vague; **"Marketing teams redirect saved hours"** is passive-ish and clunky.
Suggestion: Make the benefit explicit and active: "HubSpot's Breeze Social Media Agent halves that time. It generates on-brand posts, optimizes scheduling, and analyzes performance—inside your HubSpot workflows—so your team can spend those hours on campaign strategy, audience research, and relationship building."

**Why this is thorough:**
- Identifies specific weak verbs ("cuts" instead of "halves")
- Explains why it's weak (vague, passive-ish)
- Provides complete rewrite showing active construction
- Maintains original style and punctuation patterns

---

## Example 5: Style Consistency

### RUSHED EDIT (❌ Unacceptable):
"Fix formatting."

### THOROUGH EDIT (✅ What We Want):

**30 - Global style cleanup (synthesis of multiple micro-edits)**
Location: Entire document
Issue: **Inconsistencies in dashes, quotes, contractions, and capitalization.**
Suggestion:
- Use en dashes for numeric ranges (3–5, 15–25).
- Use curly quotes and apostrophes (HubSpot's, It's).
- Prefer contractions for conversational tone.
- Standardize title case on headings and sentence case on bullets.
- Replace HTML entities (') with proper punctuation.

**Specific fixes needed:**
- "3-5 hours" → "3–5 hours" (every instance)
- "don't" → "don't" (every instance)
- "AI's" → "AI's" (every instance)
- "&apos;" → "'" (every instance)

**Why this is thorough:**
- Creates a synthesis note for global issues
- Lists specific patterns to find and fix
- Shows exact before/after for each pattern
- Applies to entire document systematically

---

## Example 6: CTA Improvement

### RUSHED EDIT (❌ Unacceptable):
"CTA could be more specific."

### THOROUGH EDIT (✅ What We Want):

**29 - Final CTA: move from generic to action + measurement**
Location: "Transform Your Social Strategy Today" closing paragraph
Issue: Generic **"explore features," "set up preferences," "Scale what works"**; lacks a time‑boxed next step and measurement.
Suggestion: "Run a 30‑day test: set brand preferences, generate a month of posts, A/B two headline styles per platform, and track engagement, CTR, and influenced pipeline. Keep the winners. Retrain the agent with your best performers."

**Why this is thorough:**
- Shows exact generic phrases to remove
- Explains what's missing (time-box, measurement)
- Provides complete rewrite with specific actions
- Includes success metrics (engagement, CTR, pipeline)
- Gives clear timeframe (30 days)

---

## Example 7: Synthesis of Related Edits

### RUSHED EDIT (❌ Unacceptable):
Multiple separate notes about the same section.

### THOROUGH EDIT (✅ What We Want):

**Synthesis Note (combining edits 1, 2, 5)**
Location: Opening section
Issue: Repetition of **"time saved"** and **"strategy vs execution"** across first two paragraphs + passive phrasing + generic outcome.
Suggestion: Consolidate into a single, sharper opening that quantifies the problem (Edit 1), states the solution and benefit in active voice (Edit 2), and frames the outcome in business terms (Edit 5).

**Why this is thorough:**
- Combines related issues into one note
- Explains which edits are being synthesized
- Shows the combined fix addresses all issues
- More efficient than separate notes

---

## The Pattern Recognition Test

**After your edit, check if your findings show these patterns:**

✅ **Thorough Edit Has:**
- Exact locations (paragraph numbers, sentence numbers, section names)
- Specific issues in bold (what's wrong and why)
- Concrete suggestions (complete rewrites in original style)
- Multiple categories covered (redundancy, headers, stats, voice, style)
- Synthesis notes for related issues
- 20-30+ total findings

❌ **Rushed Edit Has:**
- Vague locations ("beginning," "middle")
- Generic issues ("could be better," "needs work")
- No concrete suggestions (just principles)
- Only 1-2 categories covered
- No synthesis
- 3-5 total findings

---

## Time Investment Reality Check

**For Framework 1 (Comprehensive Edit Checklist) on a 1,500-word article:**
- **Rushed edit:** 2-5 minutes → Misses 25+ issues → FAILURE
- **Adequate edit:** 10-12 minutes → Catches 15-20 issues → ACCEPTABLE
- **Thorough edit:** 15-20 minutes → Catches 30+ issues → EXCELLENT

**For ALL 11 Frameworks Combined on a 1,500-word article:**
- **Framework 1 (Comprehensive):** 15-20 minutes
- **Framework 2 (Redundancy):** 5-8 minutes  
- **Framework 3 (Active Voice):** 5-7 minutes
- **Framework 4 (Parallelism):** 4-6 minutes
- **Framework 5 (Tenses):** 4-6 minutes
- **Framework 6 (Sentence Structure):** 5-7 minutes
- **Framework 7 (Specificity):** 5-7 minutes
- **Framework 8 (Arguments):** 5-6 minutes
- **Framework 9 (Structure):** 5-7 minutes
- **Framework 10 (Takeaways):** 4-5 minutes
- **Framework 11 (Final Polish):** 10-15 minutes

**TOTAL TIME EXPECTED: 60-90 minutes for thorough editing of all 11 frameworks**

**If you finished ALL 11 frameworks in under 45 minutes, you RUSHED. Go back.**

---

## Your Editing Checklist

Before you say "done," verify:

□ Did I find 20-30+ specific issues?
□ Did I check opening paragraphs for redundancy?
□ Did I verify all headers are outcome-first?
□ Did I add timeframes/baselines to all stats?
□ Did I check style consistency (dashes, quotes, formatting)?
□ Did I remove all filler words?
□ Did I convert passive to active voice?
□ Did I make the CTA specific with measurements?
□ Did I create synthesis notes for related edits?
□ Did I spend 15+ minutes on this?

**If you answered NO to any of these, you need to edit more.**

---

## Remember

**You are the quality gatekeeper.** If you rush through editing, the entire article suffers no matter how good the research and drafting were.

**Take your time. Be thorough. Find everything.**

The difference between good and great is in the editing.
