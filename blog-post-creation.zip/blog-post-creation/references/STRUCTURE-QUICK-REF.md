# Blog Post Structure Quick Reference

## 🎯 The Core Principle (V4)

**Use VARIETY, not uniformity. Content must LOOK like example-1-health-score.md when scrolling.**

---

## ✅ Required Elements Per Article

### Paragraph Variety
- [ ] 10-15 single-sentence paragraphs
- [ ] 20-25 two-sentence paragraphs
- [ ] 5-10 three-sentence paragraphs (maximum length)
- [ ] **NOT uniform blocks** - mix all three lengths

### Bullets & Lists
- [ ] 8-12 bullet sections minimum (extensive use)
- [ ] 3-5 instances of sub-bullets (nested lists)
- [ ] Use for: features, benefits, steps, options, criteria

### Visual Placeholders
- [ ] 2-4 minimum per article
- [ ] [Screenshot: ...], [Diagram: ...], [Chart: ...]
- [ ] Every 3-5 paragraphs

### Tables
- [ ] 1-2 for comparisons (when comparing data/options)
- [ ] Features, time savings, specifications, pricing

### Bold Headers
- [ ] 8-12 per article
- [ ] **Why this matters**, **How it works**, etc.

---

## 📋 Format Decision Matrix

| Content Type | Format |
|--------------|--------|
| Listing things (features, benefits) | Bullets + sub-bullets |
| Single powerful statement | 1-sentence paragraph |
| Simple explanation | 2-sentence paragraph |
| Complex idea (maximum) | 3-sentence paragraph |
| Comparing options/data | Table |
| Showing interface/workflow | Visual placeholder |
| Adding structure | Bold header |

---

## 🎯 The Scroll Test (MANDATORY)

**Before declaring article complete:**

1. Open `examples/example-1-health-score.md`
2. Open your article
3. Scroll through BOTH side-by-side
4. Ask: Do they LOOK similar?

**Must match:**
- ✅ Bullet density (many sections)
- ✅ White space (breathing room)
- ✅ Variety (1, 2, 3 sentence mix)
- ✅ Visual placeholders (2-4)
- ✅ Scannability (easy to skim)

**If NO → REJECTED**

---

## ❌ Automatic Rejection Criteria

**Article is REJECTED if:**

- ❌ Every paragraph is 2-3 sentences (need variety)
- ❌ Fewer than 8 bullet sections
- ❌ No visual placeholders
- ❌ No sub-bullets
- ❌ No tables when comparing data
- ❌ Fewer than 8 bold headers
- ❌ Looks like uniform text blocks
- ❌ Doesn't look like examples (fails scroll test)

---

## ✅ Example Pattern from example-1

**Lines 1-50 structure:**

```
Single sentence hook (line 3)

Two sentence paragraph (lines 5-6)

Single sentence (line 7)

**Bold header** (line 9)

- Bullets (lines 11-15)

**Another bold header** (line 17)

- Bullets with sub-bullets (lines 19-30)
  - Nested items

[Screenshot] placeholder (line 32)

Two sentence paragraph (line 34)

**Bold header** (line 36)

- More bullets (lines 38-42)
```

**This is the VARIETY pattern to match.**

---

## 🔍 Structure Verification Checklist

**After editing, verify:**

- [ ] Paragraph variety (10-15, 20-25, 5-10 distribution)
- [ ] 8-12 bullet sections
- [ ] 2-4 visual placeholders
- [ ] 3-5 sub-bullet instances
- [ ] 1-2 tables (if comparing)
- [ ] 8-12 bold headers
- [ ] ZERO paragraphs with 4+ sentences
- [ ] Line breaks between ALL paragraphs
- [ ] **SCROLL TEST PASSED**

---

## 💡 Remember

**WRONG interpretation:**
"Every paragraph should be 2-3 sentences" → Creates monotonous blocks

**CORRECT interpretation:**
"Use 1, 2, OR 3 sentences for VARIETY" → Creates scannable, professional content

**Key insight:**
Reading the rules didn't help. SEEING the variety in examples is what matters. Always perform the scroll test.

---

**Quick access:** `references/STRUCTURE-QUICK-REF.md`
**Version:** 4.0 - Emphasizes VARIETY + BULLETS + VISUALS
