# SEO Competitor Analysis Template

Use this template to document on-page SEO analysis of ranking competitors identified via `dataforseo:serp_organic_live_advanced`.

---

## Article Information

**Target Keyword:** `[Your target keyword]`

**Analysis Date:** `[YYYY-MM-DD]`

**SERP Analysis Completed:** ☑ Yes / ☐ No

**Number of Competitors Analyzed:** `[3-5 recommended]`

---

## SERP Results Summary

| Position | URL | Domain | Title | Meta Description | Notes |
|----------|-----|--------|-------|------------------|-------|
| 1 | [URL] | [domain.com] | [Page title] | [Meta desc] | [High authority, recent] |
| 2 | [URL] | [domain.com] | [Page title] | [Meta desc] | [Comprehensive guide] |
| 3 | [URL] | [domain.com] | [Page title] | [Meta desc] | [Feature-focused] |
| 4 | [URL] | [domain.com] | [Page title] | [Meta desc] | [Case study angle] |
| 5 | [URL] | [domain.com] | [Page title] | [Meta desc] | [How-to format] |

**Selection for Deep Analysis:**
- Position 1: [URL] - Reason: [Top ranking, authoritative domain]
- Position 2: [URL] - Reason: [Comprehensive coverage]
- Position 3: [URL] - Reason: [Unique angle]

---

## Competitor #1: [Domain Name]

**URL:** `[Full URL]`

**SERP Position:** `#1`

**Analysis Tool:** `dataforseo:on_page_content_parsing`

### Basic Metrics
- **Word Count:** `[X,XXX words]`
- **Publish Date:** `[YYYY-MM-DD or "Not visible"]`
- **Last Updated:** `[YYYY-MM-DD or "Not visible"]`
- **Reading Time:** `[X min read]`

### Heading Structure

**H1 (Single):**
```
[Exact H1 text]
```
- Keyword placement: ☑ Exact match / ☐ Variation / ☐ Not present
- Character count: `[XX chars]`

**H2 Structure (List all):**
1. `[H2 heading 1]` - Keyword: ☑/☐
2. `[H2 heading 2]` - Keyword: ☑/☐
3. `[H2 heading 3]` - Keyword: ☑/☐
4. `[H2 heading 4]` - Keyword: ☑/☐
5. `[H2 heading 5]` - Keyword: ☑/☐
6. `[H2 heading 6]` - Keyword: ☑/☐

**Total H2 Count:** `[X]`

**H3 Usage:**
- Total H3s: `[X]`
- Average H3s per H2: `[X]`
- Depth level: ☐ Shallow (0-1 per H2) / ☑ Medium (2-3 per H2) / ☐ Deep (4+ per H2)

### Meta Elements

**Meta Title:**
```
[Exact meta title]
```
- Length: `[XX chars]` - Status: ☑ Optimized (50-60) / ☐ Too long / ☐ Too short
- Keyword: ☑ Present / ☐ Not present
- Brand: ☑ Included / ☐ Not included

**Meta Description:**
```
[Exact meta description]
```
- Length: `[XXX chars]` - Status: ☑ Optimized (150-160) / ☐ Too long / ☐ Too short
- Keyword: ☑ Present / ☐ Not present
- CTA: ☑ Included / ☐ Not included

### Content Structure

**Opening (First 100 Words):**
- Keyword in first paragraph: ☑ Yes / ☐ No
- Hook type: ☐ Statistic / ☐ Question / ☑ Problem/Solution / ☐ Story
- Value proposition clarity: ☑ Clear / ☐ Vague

**Body Structure:**
- Paragraph variety: ☑ Varied (1-3 sentences) / ☐ Uniform
- Bullet sections: `[X sections]` - Count: ☐ Minimal (1-3) / ☑ Moderate (4-7) / ☐ Extensive (8+)
- Visual elements: `[X visuals]` - Types: ☐ Screenshots / ☐ Diagrams / ☐ Charts / ☐ Infographics
- Tables: `[X tables]`
- Lists: `[X lists]` (numbered + bulleted)

**Conclusion:**
- Keyword mentioned: ☑ Yes / ☐ No
- CTA present: ☑ Yes / ☐ No
- Takeaway summary: ☑ Yes / ☐ No

### Technical SEO Elements

**Internal Links:**
- Count: `[X internal links]`
- Link placement: ☐ Contextual / ☐ Sidebar / ☐ Footer / ☑ Mixed
- Anchor text diversity: ☑ Varied / ☐ Repetitive

**External Links:**
- Count: `[X external links]`
- Authority level: ☐ High (gov, edu, major publications) / ☑ Medium / ☐ Low
- Link purpose: ☐ Citations / ☐ Resources / ☑ Mixed

**Schema Markup:**
- Types present:
  - ☑ Article schema
  - ☐ HowTo schema
  - ☐ FAQPage schema
  - ☐ Breadcrumb schema
  - ☐ Review schema
  - ☐ Video schema

**Images:**
- Count: `[X images]`
- Alt text: ☑ Present / ☐ Missing / ☐ Inconsistent
- Optimization: ☑ Optimized / ☐ Heavy files

### Keyword Usage

**Primary Keyword Density:**
- Total mentions: `[X times]`
- Density: `[X.X%]` - Status: ☑ Natural (1.5-2.5%) / ☐ Over-optimized / ☐ Under-optimized
- Placement locations:
  - ☑ H1
  - ☑ First 100 words
  - ☑ H2s (some)
  - ☑ Conclusion
  - ☐ URL slug
  - ☑ Meta elements

**Keyword Variations:**
- Variation 1: `[variation]` - Count: `[X]`
- Variation 2: `[variation]` - Count: `[X]`
- Variation 3: `[variation]` - Count: `[X]`

**LSI Keywords Identified:**
- `[related term 1]`
- `[related term 2]`
- `[related term 3]`
- `[related term 4]`
- `[related term 5]`

### Content Gaps (What's Missing?)

**Topics Not Covered:**
1. `[Gap 1: Topic they didn't cover]`
2. `[Gap 2: Another missing topic]`
3. `[Gap 3: Shallow coverage area]`

**Opportunities:**
1. `[Opportunity 1: More depth on X]`
2. `[Opportunity 2: Better visuals for Y]`
3. `[Opportunity 3: Update stats for Z]`

---

## Competitor #2: [Domain Name]

**URL:** `[Full URL]`

**SERP Position:** `#2`

[Repeat same structure as Competitor #1]

---

## Competitor #3: [Domain Name]

**URL:** `[Full URL]`

**SERP Position:** `#3`

[Repeat same structure as Competitor #1]

---

## Cross-Competitor Pattern Analysis

### Word Count Patterns
| Competitor | Word Count | Status |
|------------|------------|--------|
| Competitor 1 | [X,XXX] | Highest |
| Competitor 2 | [X,XXX] | Medium |
| Competitor 3 | [X,XXX] | Lowest |
| **Average** | **[X,XXX]** | **Target baseline** |
| **Our Target** | **[X,XXX]** | **Match or exceed by 10-15%** |

### Heading Count Patterns
| Competitor | H2 Count | H3 Count | H2:H3 Ratio |
|------------|----------|----------|-------------|
| Competitor 1 | [X] | [X] | [X:X] |
| Competitor 2 | [X] | [X] | [X:X] |
| Competitor 3 | [X] | [X] | [X:X] |
| **Average** | **[X]** | **[X]** | **[X:X]** |
| **Our Target** | **[X]** | **[X]** | **[X:X]** |

### Common H2 Topics (Across All Competitors)

**Universal Topics (All 3 have):**
1. `[Common topic 1]` - Must include
2. `[Common topic 2]` - Must include
3. `[Common topic 3]` - Must include

**Frequent Topics (2 of 3 have):**
1. `[Frequent topic 1]` - Consider including
2. `[Frequent topic 2]` - Consider including

**Unique Topics (Only 1 has):**
1. `[Unique topic 1]` - Differentiation opportunity
2. `[Unique topic 2]` - Gap or niche angle?

### Meta Element Patterns

**Title Patterns:**
- **Pattern A:** `[Keyword] Guide: [Benefit] | [Brand]` (2 competitors)
- **Pattern B:** `[Number] [Keyword] [Action Words] in [Year]` (1 competitor)
- **Our Pattern:** `[Topic] for RevOps: [Benefit] | MAN Digital`

**Description Patterns:**
- Average length: `[XXX chars]`
- CTA usage: `[X of 3]` include CTA
- Keyword placement: `[X of 3]` include keyword
- Common phrases: `[Learn, Discover, Master, Transform]`

### Content Structure Patterns

**Opening Hooks:**
- Statistics: `[X of 3]` use stats
- Questions: `[X of 3]` use questions
- Problem/Solution: `[X of 3]` use problem framing
- **Recommendation:** `[Use most common + our unique angle]`

**Body Format:**
- Bullet density: Average `[X sections]` per article
- Visual frequency: Average `[1 visual per X paragraphs]`
- Table usage: `[X of 3]` use comparison tables
- **Our Standard:** `[8-12 bullet sections, 2-4 visuals, 1-2 tables]`

### Technical SEO Patterns

**Schema Markup:**
- Article schema: `[X of 3]` (Required)
- HowTo schema: `[X of 3]` (Optional)
- FAQPage schema: `[X of 3]` (Optional)
- **Our Baseline:** Article + [additional schema if relevant]

**Internal Linking:**
- Average internal links: `[X links]`
- Link placement: `[Contextual / Sidebar / Mixed]`
- **Our Target:** `[3-5 contextual internal links]`

---

## SEO Gaps & Opportunities Summary

### Content Gaps (What Competitors Miss)

**High-Priority Gaps (Clear Opportunities):**
1. **Gap:** `[Topic/angle all competitors miss]`
   - **Opportunity:** `[How we can fill this]`
   - **Value:** `[Why this matters to our audience]`

2. **Gap:** `[Shallow coverage area]`
   - **Opportunity:** `[Deeper analysis we can provide]`
   - **Value:** `[Competitive advantage]`

3. **Gap:** `[Outdated information]`
   - **Opportunity:** `[Update with 2025 data]`
   - **Value:** `[Freshness signal]`

**Medium-Priority Gaps:**
1. `[Gap 4]` - `[Opportunity description]`
2. `[Gap 5]` - `[Opportunity description]`

### Technical SEO Opportunities

**Schema Markup:**
- Missing schema types: `[HowTo, FAQPage, Video, etc.]`
- Opportunity: `[Implement additional schema for rich snippets]`

**Visual Elements:**
- Competitor average: `[X visuals]`
- Opportunity: `[Use X+2 visuals for better engagement]`

**Content Depth:**
- Competitor average: `[X,XXX words]`
- Opportunity: `[Exceed by 10-15% with quality content]`

---

## Content Strategy Recommendations

### Must-Have Elements (Based on Competitor Analysis)

**Structure:**
- ☑ H1 with target keyword
- ☑ `[5-8]` H2 sections (based on competitor average)
- ☑ `[2-3]` H3s per H2 (medium depth)
- ☑ `[X,XXX]` words minimum (match or exceed competitor average)

**Content Topics (Priority Order):**
1. ☑ **[Universal topic 1]** - All competitors cover this (required)
2. ☑ **[Universal topic 2]** - All competitors cover this (required)
3. ☑ **[Universal topic 3]** - All competitors cover this (required)
4. ☑ **[Gap topic 1]** - NONE cover this (our differentiation)
5. ☑ **[Gap topic 2]** - NONE cover this (competitive advantage)
6. ☐ **[Frequent topic 1]** - 2 of 3 cover (consider if relevant)

**Technical SEO:**
- ☑ Meta title: 50-60 chars with keyword
- ☑ Meta description: 150-160 chars with CTA
- ☑ Internal links: `[3-5]` contextual links
- ☑ External links: `[3-5]` authoritative sources
- ☑ Schema: Article + `[additional types]`
- ☑ Alt text: All images optimized

### Differentiation Strategy

**How We'll Stand Out:**
1. **Content Gaps:** `[Fill topics competitors miss]`
2. **Depth:** `[Exceed average word count by 10-15%]`
3. **Visuals:** `[More/better visuals than competitors]`
4. **Freshness:** `[2025 data, recent examples]`
5. **Angle:** `[Our unique MAN Digital RevOps positioning]`

### SEO Optimization Targets

| Element | Competitor Baseline | Our Target | Rationale |
|---------|---------------------|------------|-----------|
| Word Count | [X,XXX avg] | [X,XXX] | Exceed by 10-15% |
| H2 Sections | [X avg] | [X] | Match or +1 for gap topics |
| H3 Depth | [X avg per H2] | [X per H2] | Match for depth |
| Bullet Sections | [X avg] | [8-12] | Our standard (may exceed) |
| Visual Elements | [X avg] | [2-4] | Our minimum |
| Internal Links | [X avg] | [3-5] | Contextual, strategic |
| Keyword Density | [X.X% avg] | [1.5-2.5%] | Natural, not over-optimized |

---

## Action Items for Drafting

**Before Drafting:**
- [ ] Confirmed target keyword: `[keyword]`
- [ ] Analyzed top 3-5 SERP competitors
- [ ] Identified universal topics (must include)
- [ ] Identified content gaps (differentiation)
- [ ] Set word count target: `[X,XXX words]`
- [ ] Planned heading structure: `[X H2s]`

**During Drafting:**
- [ ] Include all universal topics from competitors
- [ ] Fill identified content gaps
- [ ] Match or exceed word count target
- [ ] Use heading structure based on patterns
- [ ] Place keyword in H1, first 100 words, H2s, conclusion
- [ ] Add internal links (3-5 contextual)
- [ ] Add external links (3-5 authoritative)

**After Drafting (Phase 3.5 SEO Validation):**
- [ ] Verify H1 includes target keyword
- [ ] Count H2s: `[Target: X]`
- [ ] Count H3s: `[Target: X]`
- [ ] Verify word count: `[Target: X,XXX]`
- [ ] Check keyword placement (H1, first para, conclusion)
- [ ] Confirm meta title: 50-60 chars
- [ ] Confirm meta description: 150-160 chars
- [ ] Verify internal links: 3-5 present
- [ ] Verify external links: 3-5 present

---

## Notes & Observations

`[Add any additional insights, patterns, or observations from the analysis]`

---

**Analysis Completed By:** `[Your name]`

**Ready for Drafting:** ☑ Yes / ☐ No (if no, list what's missing)
