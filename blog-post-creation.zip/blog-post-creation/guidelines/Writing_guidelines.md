# Writing Guidelines

## Core Writing Principle

### **We don't write about HubSpot features—we write about how RevOps supports GTM leaders using HubSpot as the enabler.**

**Every article must answer:**
1. What is the big GTM or business problem?
2. How does this solve a business/GTM problem?
3. What impact does this create?
4. What's the transformation story?

Rule of Thumb:
❌ Bad = feature-focused, tutorial
✅ Good = outcome-focused, transformation

**Content Principles**
- Always lead with **business outcome**, not technical feature
- Use **HubSpot screenshots, workflows, and templates** (make it tangible)
- Provide **downloadable frameworks** where possible

## Critical Opening Structure

### THE HOOK SENTENCE (Mandatory)

**Every article must start with ONE sentence that:**
- Naturally embeds the target keyword
- States the transformation or key value
- Is complete and standalone
- Sets executive tone immediately

**Perfect examples:**

✅ "The revenue operations (RevOps) framework helps your company be more efficient by aligning processes, people, technology, and data."
- Keyword: ✓ (revenue operations framework)
- Complete thought: ✓
- Value clear: ✓  
- No preamble: ✓

✅ "HubSpot launches 22 built-in agents that automate marketing, sales, and service workflows."
- Keyword: ✓ (HubSpot AI agents)
- Immediate news: ✓
- Clear benefit: ✓
- Direct: ✓

### Second Sentence: Amplify with Specificity

Add context using:
- Research/statistics with citations
- Trend data
- Specific numbers

**Format for citations:** ([_Source Name_](URL))

**Example:**
"This joins the 66% of marketers ([_HubSpot AI Trends for Marketers_](https://offers.hubspot.com/ai-marketing)) using AI to scale operations while concentrating on strategic revenue growth."

**Elements:**
- Statistic: ✓ (66%)
- Citation: ✓ (linked source)
- Context: ✓ (trend validation)
- Italics emphasis: ✓

### NO TL;DR Sections

**Do NOT include:**
- TL;DR bullets at the beginning
- Summary sections before content
- Table of Contents (unless article >3000 words)

**Why:** Executive readers want to dive in. The hook sentence does the summary work.

## Article Framework

| Section | Purpose | Example from RevOps Framework Post |
|---------|---------|-------------------------------------|
| **Opening Hook** | Keyword + value | "The revenue operations (RevOps) framework helps your company be more efficient by aligning processes, people, technology, and data." |
| **Context Block** | Explain the 'what' | "It consists of four elements: Process, People, Technology, Data" |
| **Why It Matters** | Business impact | "Connected processes... accurate data... informed forecasts" |
| **Solution/How** | Implementation | "Here's how it looks in HubSpot..." |
| **Deep Dive** | Detailed steps | Phase 1, Phase 2, Phase 3 breakdown |
| **Impact/Benefits** | Tangible outcomes | "Predictable revenue growth through unified data" |
| **Conclusion** | Key takeaways + next steps | "The throughline is simple: unify teams..." |

**⚠️ CRITICAL STRUCTURE RULE:**

**Articles MUST end with "Conclusion" section - NOT "Getting Started" or "How to Get Started"**

**Correct ending structure:**
- Last body section (implementation/impact/benefits)
- **Final section: "Conclusion"** containing:
  - Key takeaways (3-5 bullet points)
  - Summary of what reader learned
  - Brief actionable next steps (optional sub-bullets)
  - Closing wisdom statement

**Example conclusion pattern:**
```markdown
## Conclusion

Your path to [topic]:

• [Key point 1]
  - [Sub-detail]

• [Key point 2]
  - [Sub-detail]

• [Key point 3]
  - [Sub-detail]

Remember: [Final insight/wisdom]
```

**❌ DO NOT end articles with:**
- "Getting Started" as final section
- "How to Get Started" as final section
- "Next Steps" as standalone final section
- Implementation instructions as final section

**✅ ALWAYS end articles with:**
- "Conclusion" heading
- Summary of key learnings
- Takeaways reader can apply
- (Optional) brief next steps within conclusion

## Word Count Guidelines

**Target: 1,200-1,600 words**
- Minimum: 1,000 words
- Sweet spot: 1,200-1,400 words
- Maximum: 2,500 words
- Only exceed 2,000 for comprehensive guides

**Why this range:**
- Executives want depth without bloat
- SEO requires substance (1,000+ words)
- Respect reader's time (don't inflate)
- Quality over quantity

## Writing Style Guide

### 1. Tone & Style
- **Executive level, no bullshit** — Direct and to the point
- **Clear and concise** — Short sentences, no fluff
- **Neutral-positive** — State facts with solutions
- **Conversational, not corporate** — Plain words over jargon
- **Professional with approachability** — Confident without overhyping

### 2. Structure & Flow
- **Lead with the point** — Main idea first, always
- **Use prose primarily** — Bullets only for lists/checklists
- **Logical sequence** — Context → Goal → Actions → Outcomes

### 3. Clarity & Readability
- **One idea per sentence** — No layering
- **Specific over vague** — "Reduce lead response from 4 hours to 15 minutes" not "improve efficiency"
- **Plain language** — Everyday words
- **Paragraph length rules** — See detailed requirements below

**CRITICAL Paragraph Rules:**
- **1-sentence paragraphs:** Use for emphasis, transitions, impact statements (25-30% of total)
- **2-sentence paragraphs:** Core content for explanations and connections (45-50% of total)
- **3-sentence paragraphs:** Maximum depth for complex ideas (15-20% of total)
- **4+ sentence paragraphs:** NEVER ALLOWED (auto-reject)

**Distribution for 1,500-word article (~40-50 paragraphs):**
- 10-15 single-sentence paragraphs
- 20-25 two-sentence paragraphs
- 5-10 three-sentence paragraphs
- 0 paragraphs with 4+ sentences

### 4. Formatting Principles

**Use italics for:**
- Key term emphasis: _revenue operations_, _go-to-market_
- Parenthetical clarifications: (_Customer Satisfaction Score_)
- First mention of concepts

**Use bold sparingly for:**
- Subheadings within sections
- Key takeaways that must stand out
- List items (when using bullets)

**Never:**
- Bold entire sentences
- Bold multiple consecutive words (unless proper heading)
- Use excessive exclamation marks
- Over-format with too much bold

### 5. Citations and Links

**Always use this format:** ([_Source Name_](URL))

**Examples:**
- "According to research ([_HubSpot AI Trends 2024_](https://example.com))"
- "Studies show ([_Gartner RevOps Report_](https://example.com))"

**Requirements:**
- Source name in italics
- Clickable link
- Credible sources only
- Verify links work

### 6. Prose vs. Bullets

**Use prose when:**
- Explaining concepts
- Describing processes
- Building arguments
- Telling stories

**Example (prose):**
"The framework consists of four elements. Process defines how revenue is generated across teams. People run those processes with clear roles. Technology provides the tools. Data enables forecasting and insights."

**Use bullets when:**
- Listing discrete items
- Checklists
- Quick reference points
- Features or benefits

**Example (bullets):**
How to prioritize:
- Start with Customer Agent for ticket queues
- Use Prospecting Agent for SDR research
- Deploy Data Agent for property hygiene

## Writing for Non-Native English Speakers

### Core Principle: Clarity Over Cleverness

All content must be accessible to non-native English speakers through simple language, clear structure, and readability best practices.

### Target Readability Metrics

**Required standards (validated by scripts):**
- **Flesch Reading Ease:** 60-70 (Easy - 9th-10th grade level)
- **Flesch-Kincaid Grade Level:** 8-10 (Middle school reading level)
- **Average Sentence Length:** 15-20 words
- **Complex Words:** <15% (3+ syllables)
- **Passive Voice:** <10%
- **Long Sentences:** <20% over 25 words

### Language Simplification Guidelines

**Use simple words:**

| Avoid | Use Instead |
|-------|-------------|
| utilize | use |
| facilitate | help |
| implement | set up, start |
| optimize | improve |
| leverage | use |
| comprehensive | complete, full |
| methodology | method, way |

**Active voice always:**
- ❌ "Tickets are handled by the AI agent"
- ✅ "The AI agent handles tickets"

**Break complex ideas into steps:**
- Use numbered lists for processes
- One concept per sentence
- Short, clear progression

**Avoid idioms and cultural references:**
- ❌ "It's not rocket science"
- ✅ "This is straightforward"
- ❌ "Get your ducks in a row"
- ✅ "Organize your approach"

**Sentence structure patterns:**
1. **Simple (preferred):** Subject + Verb + Object
   - "The agent handles tickets."
2. **Compound (use sparingly):** Two ideas + connector
   - "The agent handles tickets, and humans focus on complex issues."
3. **Complex (minimal use, <20 words):** Main idea + supporting detail
   - "When confidence drops below 70%, the system routes to humans."

### Test Every Sentence

**Ask:** "Can a 15-year-old understand this?"
- If NO → Simplify
- Read aloud → If you run out of breath → Too long

## Formatting Variety Requirements

### The Problem: Monotonous Blocks

Users complain about "fat paragraphs, hard to understand, not scannable." Variety creates scannability.

### Required Visual Elements

**Minimum requirements per article:**
- **Bullet sections:** 8-12 throughout (not just one section)
- **Visual placeholders:** 2-4 minimum
  - `[Screenshot: description]`
  - `[Diagram: workflow]`
  - `[Table: comparison]`
- **Tables:** 1-2 for data comparisons
- **Bold headers:** 8-12 for hierarchy within sections
- **Sub-bullets:** 3-5 instances of nested lists

### Paragraph Variety Pattern

Mix short, medium, and detailed paragraphs:

**Visual pattern (good):**
```
█           (1 sentence - punch)
████████    (2 sentences - explain)
█           (1 sentence - transition)
████████████ (3 sentences - depth)
██████      (Bullets section)
█           (1 sentence - conclusion)
```

**Visual pattern (bad):**
```
████████████████
████████████████
████████████████
████████████████
```

### The Scroll Test

**Before finalizing any post:**
1. Open `examples/example-1-health-score.md`
2. Open your draft
3. Scroll through BOTH side-by-side
4. Ask: "Do they LOOK similar?"

**Must match:**
- Bullet density (many sections)
- White space (breathing room)
- Paragraph variety (1, 2, 3 sentence mix)
- Visual elements (placeholders, tables)
- Scannability (skim in 30 seconds)

**If doesn't match:** Reject and revise.

### Common Formatting Patterns

**Pattern A: Punch → Explain → Bullets**
```markdown
Customer health scoring predicts churn before it happens.

It combines signals from product usage, engagement, and feedback into one score. Teams use this to prioritize actions.

**The triggers:**
- Red score → 48-hour save plan
- Yellow score → Check-in within week
- Green score → Expansion outreach
```

**Pattern B: Explain → Punch → Explain**
```markdown
HubSpot's AI agent handles customer inquiries 24/7 across multiple channels. It maintains context when customers switch platforms.

This creates seamless experiences.

The agent learns from every interaction, improving accuracy over time. When confidence drops, it routes to humans with full history.
```

**Pattern C: Bullets → Punch → Deep Dive**
```markdown
**Key benefits:**
- 50% faster resolution
- 24/7 availability
- Consistent quality
- Reduced agent burnout

This transforms support operations.

Teams shift from reactive firefighting to proactive customer success. Agents handle complex issues while AI manages volume. The result: higher satisfaction and lower costs simultaneously.
```

### What to Avoid

**❌ Fat paragraphs (4+ sentences):**
```markdown
Customer health scoring is important for SaaS companies. It helps you understand which customers are happy and which are at risk. You can use this information to take action before customers churn. This ultimately helps you improve retention and grow revenue.
```

**✅ Variety with bullets:**
```markdown
Customer health scoring predicts churn risk.

**What it does:**
- Tracks product usage
- Monitors engagement
- Collects feedback
- Flags at-risk accounts

This helps you act before customers leave.
```

## Content to Avoid

- Feature-focused writing: "How to use HubSpot workflows"
- Fluff phrases: "unlock potential," "leverage synergies," "game-changer," "dive in"
- Excessive exclamation marks
- Vague adjectives: "engaged customers" → "customers who logged in 3+ times last week"
- Corporate jargon
- TL;DR sections
- Over-formatted text (too much bold)
- Missing citations for claims
- Vague outcomes without numbers

## Visual Content Requirements

### Graphics and Diagrams
- Process flows: Show step-by-step
- Architecture diagrams: System connections
- Before/after comparisons: Transformation
- ROI visualizations: Make impact tangible

### Screenshots
- Annotated: Highlight key areas
- Sequential: Step-by-step process
- Current: Latest HubSpot UI
- Marked with: [Screenshot: description]

## Writing Patterns

### Strong Opening Pattern
```
[Hook sentence with keyword]

[Amplifying context with citation/statistic]

[Brief problem or context setup - 2-3 sentences]
```

### What-Why-How Pattern
```
What: [The thing/concept/approach]

Why it matters: [Business impact]

How to implement: [Specific approach]
```

### Claim-Support-Takeaway Pattern
```
[Bold claim]

[Evidence: data, research, example]

[Practical takeaway for reader]
```

## Quality Checklist

**Core Structure:**
- [ ] Opens with ONE strong hook sentence
- [ ] NO TL;DR section
- [ ] Word count: 1,200-1,600
- [ ] **Ends with "Conclusion" section** (NOT "Getting Started")
- [ ] Conclusion includes key takeaways and learnings

**Paragraph & Formatting:**
- [ ] Paragraph variety: Mix of 1, 2, 3 sentence paragraphs
- [ ] NO fat paragraphs (4+ sentences = auto-reject)
- [ ] 8-12 bullet sections throughout
- [ ] 2-4 visual placeholders
- [ ] 1-2 tables for comparisons
- [ ] 8-12 bold headers for hierarchy

**Readability (Non-Native Speakers):**
- [ ] Flesch Reading Ease: 60-70
- [ ] Average sentence length: 15-20 words
- [ ] Simple vocabulary (avoid "utilize," "leverage," etc.)
- [ ] Active voice (not passive)
- [ ] No idioms or cultural references

**Content Quality:**
- [ ] No fluff phrases
- [ ] Every sentence adds value
- [ ] Specific numbers ("3+ times" not "engaged")
- [ ] No vague adjectives without specifics
- [ ] Proper citations with links
- [ ] Strategic italics (not excessive bold)
- [ ] Real examples and screenshots marked

**Validation (MANDATORY):**
- [ ] Run `formatting-validator.py` after drafting (MUST PASS)
- [ ] Run `readability-scorer.py` after drafting (MUST PASS)
- [ ] Run `seo-validation-helper.py` after drafting (MUST PASS)
- [ ] Run `style-enforcer.py` before delivery (MUST PASS)

## Examples from Real Posts

### Perfect Opening (RevOps Framework)
"The revenue operations (RevOps) framework helps your company be more efficient by aligning processes, people, technology, and data."

**Why it works:**
- Keyword embedded naturally
- Complete value proposition
- One sentence
- No preamble

### Perfect Second Sentence (AI Agents)
"This joins the 66% of marketers ([_HubSpot AI Trends for Marketers_](https://offers.hubspot.com/ai-marketing)) using AI to scale operations while concentrating on strategic revenue growth."

**Why it works:**
- Specific statistic (66%)
- Proper citation format
- Validates the trend
- Builds credibility

### Perfect Context Block (RevOps Framework)
"It consists of four elements:
- Process (revenue generation)
- People running _those processes_
- Technology (_tools used in your processes_)
- Data (_data you gather in your business_)"

**Why it works:**
- Clear structure
- Concise explanations
- Strategic italics
- No fluff

## Common Mistakes

1. **No hook sentence** - Starting with question or long setup
2. **Including TL;DR** - Outdated structure
3. **Too long** - Exceeding 1,600 words without justification
4. **Wrong ending** - Ending with "Getting Started" instead of "Conclusion"
5. **No conclusion section** - Missing final takeaways and learnings
6. **Fat paragraphs** - Using 4+ sentence paragraphs (auto-reject)
7. **All bullets** - Using bullets for everything instead of prose
8. **Too few bullets** - Only 2-3 bullet sections instead of 8-12
9. **No visual variety** - Missing placeholders, tables, bold headers
10. **Missing citations** - Claims without linked sources
11. **Over-bolding** - Bold everywhere instead of strategic italics
12. **Vague metrics** - "Improve efficiency" instead of "Reduce from 4 hours to 15 minutes"
13. **Feature focus** - Writing about HubSpot features instead of business outcomes
14. **Complex language** - Using "utilize" instead of "use" (non-native speakers struggle)
15. **Passive voice** - "Tickets are handled" instead of "Agent handles tickets"
16. **No validation** - Skipping the mandatory validation scripts

