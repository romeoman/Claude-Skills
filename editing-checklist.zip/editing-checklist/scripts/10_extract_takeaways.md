# Script 10: Extract Takeaways

## Purpose
Ensure every section has clear implications and the article has a strong main takeaway.

## When to Use
- After Script 09 (Structural Strategy)
- Before final packaging/publication
- When article provides information without actionability

## Time Expectation
4-5 minutes for a 1,500-word article

---

## Instructions

⚠️ **Check EVERY section** - Does it have a clear takeaway?

**Reader question:** "So what? Why should I care? What do I do now?"

**Expected findings:** 5-8 missing or weak takeaways minimum

**Rule:** No information without implication. No data without meaning.

---

## Critical Patterns to Find

### Missing Micro-Takeaways (Section Level)
- Section explains a feature but doesn't state the benefit
- Data presented without "what this means for you"
- Example → Example → Example [Missing: What's the pattern/lesson?]
- Need: After each section, clear implication for reader

### Weak Main Takeaway (Article Level)
- Conclusion just restates what was said
- No clear call to action or next step
- "In conclusion..." without synthesis
- Need: Tie back to opening promise, provide clear action

### Vague Takeaways
- "This is important" → WHY? HOW?
- "Consider using this" → BE MORE SPECIFIC
- "It might help" → WEAK! Make it confident
- Need: Specific, actionable, confident takeaways

---

## Proper Takeaway Structure

1. **Data/Info:** "96% of pros use AI"
2. **Meaning:** "AI is now the norm, not the exception"
3. **Action:** "If you're not using it, you're falling behind"

---

## What is a Takeaway?

Takeaways help readers understand what to do next.

If your content is good, by the end, readers are dying to know:
- "How can I implement this in my life?"
- "What should I do next/How do I get started?"
- "What's the key lesson I'm walking away with?"

When you make readers guess what to do next, you miss a chance to help them put your teaching into action.

---

## The Big Why Questions

To make sure you hit the "big takeaway" on the nose, return to your "big why" questions:

- Why does this piece of content exist?
- Why does my ideal reader need this piece of content?
- Why will they be interested in it?
- What will they hope to achieve from it?

The answer to these questions is your content angle.

When reviewing your draft, keep that angle top of mind, and if you've strayed from it or didn't drive it home, fix that during editing.

---

## Section-Level Takeaways

For smaller takeaways throughout, stop at the end of every section and ask:

- Have I included takeaways readers can emulate?
- Have I included strategic CTAs, both subtle and obvious, that motivate readers to complete an action?

---

## Review Steps

1. Review your instructions
2. Review your definitions
3. Analyze the user's content to understand the "Big Why" and associated questions
4. If the content is long and complex enough, determine where micro-takeaways might be useful
5. Review the end of the content to see if a main takeaway is adequately attained. You may need to suggest a higher level takeaway (a zoom out), moving something more toward the end of the content, or adding something new entirely
6. Determine if you've tried hard enough. If you haven't, please try harder.
7. Output your insightful analysis in the Output Format

---

## Output Format

```
1 - [Takeaway issue description]
Location: [section or paragraph number]
Issue: [what takeaway is missing or weak]
Suggestion: [specific, actionable takeaway written in writer's voice/style]

2 - [Takeaway issue description]
Location: [section or paragraph number]
Issue: [what's missing]
Suggestion: [concrete takeaway]

[Continue same pattern...]
```

---

## Success Criteria

- [ ] Checked ALL major sections for takeaways
- [ ] Identified missing micro-takeaways (section level)
- [ ] Evaluated main takeaway (article level) against "Big Why"
- [ ] Found minimum 5-8 missing or weak takeaways
- [ ] Suggestions are specific, actionable, and confident (not vague)
- [ ] Takeaways match writer's voice and style
