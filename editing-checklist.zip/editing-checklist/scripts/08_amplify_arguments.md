# Script 08: Amplify Arguments

## Purpose
Strengthen claims with evidence and takeaways using the Claim → Support → Takeaway framework.

## When to Use
- After Script 06 (Sentence Rhythm)
- When article makes claims without evidence
- Before checking structural strategy

## Time Expectation
5-6 minutes for a 1,500-word article

---

## Instructions

⚠️ **CRITICAL: Check EVERY claim** - Does it have support? Does it have a takeaway?

**Structure:** Claim → Support (evidence/data) → Takeaway (so what?)

**Rule:** No claim without evidence. No evidence without meaning.

---

## The Framework: Claim → Support → Takeaway

### 1. Make a Claim
State your assertion clearly.

### 2. Support it with Evidence
Provide data, case study, research, expert quote, or concrete example.

### 3. End with a Takeaway
Connect evidence to reader benefit—the "so what?"

---

## Example

**Weak (Claim only):**
"AI agents save time."

**Strong (Claim → Support → Takeaway):**
**Claim:** "AI agents save time."
**Support:** "Teams save 10-15 hours weekly on average."
**Takeaway:** "That's time redirected to strategy instead of execution."

---

## Critical Patterns to Find

### Unsupported Claims
- Bold claim with no data/evidence
- "This is the best approach" → WHERE'S THE PROOF?
- Need: Statistic, case study, research, or expert quote

### Evidence Without Takeaway
- "96% of pros use AI" → SO WHAT? WHY DOES IT MATTER?
- Need: Connect evidence to reader benefit

### Weak Structure
- Claim → Claim → Claim (no support)
- Evidence → Evidence → Evidence (no framing)
- Need: Claim → Support → Takeaway pattern

---

## Full Example

**Claim:** "Regular exercise enhances mental well-being."
**Support:** "Studies show regular physical activity boosts mood and reduces symptoms of depression and anxiety."
**Takeaway:** "To maintain mental health, incorporate daily exercise into your routine."

**Another Example:**

"Put your phone on airplane mode during deep work."

**Without support, readers wonder:**
- Is this actually true?
- Does it make that big of a difference?
- Are there stats to back this up?

**With complete argument:**
"Put your phone on airplane mode during deep work. It takes 23 minutes to refocus after a distraction. You'll get more done faster by eliminating notifications."

**Now readers KNOW:**
- Airplane mode actually helps people stay focused
- It takes 23 minutes to refocus—avoiding distractions makes a huge difference
- There are stats to back this up

---

## Output Format

```
1 - [Argument issue description]
Location: [line number or paragraph number]
Issue: [what's missing - claim without support, support without takeaway, etc.]
Suggestion: [how to add missing element (support or takeaway) written in writer's voice/style]
```

---

## Success Criteria

- [ ] Checked ALL claims for supporting evidence
- [ ] Checked ALL evidence for practical takeaways
- [ ] Found minimum 6-10 argument improvements
- [ ] Suggestions match writer's style and voice
- [ ] Added specific data/examples where claims were unsupported
- [ ] Added "so what?" takeaways where evidence lacked meaning
