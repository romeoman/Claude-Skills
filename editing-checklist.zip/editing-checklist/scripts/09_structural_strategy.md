# Script 09: Structural Strategy (What → Why → How)

## Purpose
Ensure logical flow using the What → Why → How pattern at both macro and micro levels.

## When to Use
- After Script 08 (Amplify Arguments)
- When article jumps between topics without clear transitions
- Before extracting takeaways

## Time Expectation
5-7 minutes for a 1,500-word article

---

## Instructions

⚠️ **Check overall flow** - Does the article follow logical progression?

**Expected findings:** 5-8 structural improvements minimum

**Focus:** Transitions, logical flow, missing "why" or "how" sections

---

## The What-Why-How Framework

Too often, writers make a key statement and move on without answering:
- Why it matters
- How it can help the reader

This leaves readers with questions: "Hmm. I wonder why this matters." And, "Wait, so how do I actually do it?"

When readers have nagging questions, they stop reading your content and find answers elsewhere.

---

## The Pattern

### **What:** The thing/concept/approach
### **Why:** Why it matters (business impact)
### **How:** How to implement (specific approach)

---

## Example 1

**What:** "By understanding its place in the market, ConvertKit strategically differentiates on messaging."

Ok, but why does this differentiation matter?

**What + Why:** "By understanding its place in the market, ConvertKit strategically differentiates on messaging. It's laser-focused on attracting creators eager to 'connect with their audience and earn a living online' rather than everybody interested in email marketing. This specificity resonates deeply with their target audience, to the point where they're known as 'the creator's email platform' amongst the crowd."

COOL. So, how exactly do they position themselves so it's clear to their audience?

**What + Why + How:** "By understanding its place in the market, ConvertKit strategically differentiates on messaging. It's laser-focused on attracting creators eager to 'connect with their audience and earn a living online' rather than everybody interested in email marketing. This specificity resonates deeply with their target audience, to the point where they're known as 'the creator's email platform' amongst the crowd. Their homepage features a widely known creator directly below the fold and boldly states, 'Your favorite creators use ConvertKit to connect with their audience and earn a living online.'"

---

## Example 2

**What:** "Don't waste time on unqualified leads."

Ok, but why?

**What + Why:** "Don't waste time on unqualified leads. They blunt your pipeline, waste resources, and lead to missed opportunities."

COOL. How can I avoid this mistake?

**What + Why + How:** "Don't waste time on unqualified leads. They blunt your pipeline, waste resources, and lead to missed opportunities. Create consistent rules for flagging leads and prioritize an action for each one. For example, if you've contacted a lead three times with no response, archive them. Only pursue leads that actively engage with your outreach."

---

## Critical Patterns to Find

### Missing "Why" (Context)
- Jumps from What → How without explaining importance
- "Here's X" (What) → "Do this" (How) [Missing: Why does X matter?]
- Need: What → Why it matters → How to implement

### Missing "How" (Actionability)
- Explains What and Why but no implementation
- "X is important because Y" [Missing: How do I actually do X?]
- Need: Context → Importance → Action steps

### Weak Transitions
- Abrupt topic shifts
- No bridge between sections
- Stats appearing without context
- Need: Smooth connectors that maintain flow

### Structural Flow Issues
- Introduction doesn't set up body
- Body sections don't connect logically
- Conclusion doesn't tie back to opening
- Need: Cohesive narrative arc

---

## Flexible Order

You don't always have to answer What, Why, How in that order.

Sometimes, it pays to dig deeper into the why before you show the how.

You can even show readers what "not to do" before you show them what "to do."

By contrasting what doesn't work next to what does, the mistake becomes crystal clear. It's a powerful way to teach and learn, and helps readers get your point.

---

## Output Format

```
1 - [Structural issue description]
Location: [section or paragraph number]
Issue: [what's missing - Why or How, weak transition, flow break]
Suggestion: [how to add missing element or improve flow, written in writer's voice/style]
```

---

## Success Criteria

- [ ] Checked article for What → Why → How pattern
- [ ] Identified missing "Why" sections (importance not explained)
- [ ] Identified missing "How" sections (implementation not provided)
- [ ] Found weak transitions between sections
- [ ] Suggested improvements for logical flow
- [ ] Found minimum 5-8 structural improvements
