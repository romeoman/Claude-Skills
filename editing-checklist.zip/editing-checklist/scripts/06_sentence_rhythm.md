# Script 06: Sentence Rhythm & Variety

## Purpose
Create rhythm and flow through sentence structure variety (Gary Provost principle: "Don't just write words, write music").

## When to Use
- After Script 05 (Tense Consistency)
- When article feels monotonous or choppy
- Before amplifying arguments

## Time Expectation
5-7 minutes for a 1,500-word article

---

## Instructions

Pay attention to:
- Clauses (independent/dependent)
- Whether sentences are compound and/or complex
- Comma placement and rhythm
- Sentence length variety

### The Goal: Write Music, Not Just Words

**Example of poor rhythm (all same length):**
"AI agents help teams. They save time. They improve efficiency. They boost productivity."

**Example of good rhythm (varied length):**
"AI agents help teams. They save 15 hours weekly by automating research, personalizing outreach, and managing workflows—freeing reps to focus on strategy instead of execution."

---

## Sentence Length Guidelines

**Mix three types:**
1. **Short (5-10 words):** Punchy, emphatic, clear
2. **Medium (15-20 words):** Standard, explanatory, balanced
3. **Long (25-30 words):** Complex ideas, detailed explanations, occasional use

**Example of variety:**
"Social media is time-consuming. (Short) Managers spend 3-5 hours daily creating, scheduling, and tracking posts across platforms. (Medium) The Breeze Social Media Agent halves that time by generating on-brand content, optimizing post timing, and analyzing performance—all inside your existing HubSpot workflows, so your team redirects those hours to campaign strategy, audience research, and relationship building instead of tactical execution. (Long)"

---

## What to Check

1. **Monotonous length:** Are 5+ sentences in a row similar length?
2. **Too many complex sentences:** Are readers getting lost in nested clauses?
3. **Too many short sentences:** Does it sound choppy or juvenile?
4. **Rhythm breaks:** Do transitions between sentences feel abrupt?

---

## Output Format

```
1 - [Rhythm issue description]
Location: [paragraph number]
Issue: [what's wrong with current rhythm/variety]
Suggestion: [how to improve flow - may include combining, splitting, or restructuring sentences]
```

---

## Success Criteria

- [ ] Identified sections with monotonous sentence length
- [ ] Found opportunities to combine short choppy sentences
- [ ] Found opportunities to break up overly complex sentences
- [ ] Created variety: short + medium + occasional long sentences
- [ ] Improved overall reading rhythm and flow
