# Script 05: Tense Consistency

## Purpose
Enforce consistent tense usage throughout the article, favoring simple present tense.

## When to Use
- After Script 04 (Parallelism Check)
- When article has mixed tenses without clear reason
- Before sentence rhythm check

## Time Expectation
3-5 minutes for a 1,500-word article

---

## Instructions

Use consistent and impactful tenses. Often the simple tense (e.g. "write") is stronger than any other tense (e.g. "writing").

**Favor simple present tense unless context requires otherwise.**

### Common Tense Issues

1. **Gerund form when simple is stronger:**
   - ❌ "AI agents are helping teams save time"
   - ✅ "AI agents help teams save time"

2. **Future tense when present is stronger:**
   - ❌ "This will improve your workflow"
   - ✅ "This improves your workflow"

3. **Continuous tense when simple is stronger:**
   - ❌ "The agent is monitoring accounts"
   - ✅ "The agent monitors accounts"

4. **Unnecessary tense shifts:**
   - ❌ "The agent monitors accounts. It was tracking website visits. It will analyze company news."
   - ✅ "The agent monitors accounts. It tracks website visits. It analyzes company news."

---

## Output Format

```
1 - [Tense issue description]
Location: [line number or paragraph number]
Issue: [current tense and why it's weaker]
Suggestion: [simple present tense alternative]
```

---

## Success Criteria

- [ ] Checked entire article for tense consistency
- [ ] Identified all unnecessary tense shifts
- [ ] Converted weak tenses to simple present where appropriate
- [ ] Maintained necessary tense variations (historical context, future predictions)
