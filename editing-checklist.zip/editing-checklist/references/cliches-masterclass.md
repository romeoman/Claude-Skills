# Clichés Masterclass: Word-by-Word Replacement Guide

This guide demonstrates granular cliché editing with detailed explanations for every change, showing how to replace overused phrases with specific, fresh language.

---

## The Cliché Elimination Mindset

**Core principle:** Every cliché is a missed opportunity to be specific, interesting, or accurate. Clichés make your writing sound generic and unoriginal. They're verbal shortcuts that reduce impact.

**Goal:** Replace vague, overused phrases with precise, meaningful language that respects your reader's intelligence.

---

## Section 1: Titles and Meta Descriptions

### Example 1: SEO Meta Description - Multiple Cliché Fixes

**Original:** "Discover how HubSpot's Prospecting Agent automates research and personalized outreach. Learn setup options, features, pricing, and verified results from sales teams."

**Analysis and fixes:**

**Fix 1: Add "about" for grammar**
- **Before:** "Learn setup options, features, pricing"
- **After:** "Learn about setup options, features, pricing"
- **Reasoning:** This isn't a cliché fix, but a grammatical improvement. "Learn about" flows better than "Learn [noun]." The parallel structure with "Discover how" (verb) → "Learn about" (verb + preposition) is clearer.

**Fix 2: Remove "personalized" (redundant with "research")**
- **Before:** "automates research and personalized outreach"
- **After:** "automates research and outreach"
- **Reasoning:** If the agent automates research THEN does outreach based on that research, the outreach is inherently personalized. "Personalized" is redundant marketing speak. The automation wouldn't be valuable if outreach was generic.

**Fix 3: Remove "verified" (cliché trust signal)**
- **Before:** "and verified results from sales teams"
- **After:** "and results from sales teams"
- **Reasoning:** "Verified" is a marketing cliché trying to build credibility. But saying "verified" actually undermines trust—it suggests you expect readers to doubt you. Results from real sales teams are inherently credible. Let the source speak for itself.

**Final version:** "Discover how HubSpot's Prospecting Agent automates research and outreach. Learn about setup options, features, pricing, and results from sales teams."
- **Clichés removed:** 2 ("personalized" redundancy, "verified" trust signal)

---

## Section 2: Opening Paragraphs

### Example 2: Lead Paragraph - Business Cliché Replacement

**Original:** "Sales teams implementing the agent save 750+ hours weekly while accelerating deal velocity by 20% (Source: HubSpot). With 56% of B2B sales professionals now using AI daily, automation has shifted from competitive edge to baseline requirement (Source: LinkedIn)."

**Word-by-word analysis:**

**Fix 1: "implementing" → "using"**
- **Before:** "Sales teams implementing the agent"
- **After:** "Sales teams using the agent"
- **Reasoning:** "Implementing" suggests setup phase—a one-time event. But saving 750+ hours weekly is ongoing operation, not installation. "Using" is clearer and simpler. "Implementing" also sounds more formal and corporate than necessary.
- **Cliché type:** Unnecessarily formal business language

**Fix 2: "while accelerating" → "and accelerate"**
- **Before:** "save 750+ hours weekly while accelerating deal velocity"
- **After:** "save 750+ hours weekly and accelerate deal velocity"
- **Reasoning:** "While" creates a subordinate clause that weakens the second benefit. "And" gives both benefits equal weight. Also, "accelerating" (gerund) → "accelerate" (verb) is more direct and active.
- **Cliché type:** Weak construction (not cliché per se, but improves clarity)

**Fix 3: Remove "now"**
- **Before:** "56% of B2B sales professionals now using AI daily"
- **After:** "56% of B2B sales professionals using AI daily"
- **Reasoning:** "Now" is temporal filler. The statistic is current (it's from LinkedIn, a recent source). "Using" (present tense) already conveys current state. "Now" adds no information and sounds like marketing emphasis.
- **Cliché type:** Unnecessary time marker

**Fix 4: "competitive edge" → "competitive advantage"**
- **Before:** "from competitive edge to baseline requirement"
- **After:** "from a competitive advantage to a baseline requirement"
- **Reasoning:** "Competitive edge" is an overused business metaphor. The "edge" metaphor (sharp, cutting) has been used so much it's lost impact. "Competitive advantage" is clearer, more professional, and less cliché. Also added "a" for proper grammar—"advantage" needs an article.
- **Cliché type:** Overused business metaphor

**Final version:** "Sales teams using the agent save 750+ hours weekly and accelerate deal velocity by 20% (Source: HubSpot). With 56% of B2B sales professionals using AI daily, automation has shifted from a competitive advantage to a baseline requirement (Source: LinkedIn)."
- **Clichés removed:** 3 ("implementing," "now," "competitive edge")

---

### Example 3: Section Introduction - Misconception Wording

**Original:** "This guide explains what the agent does, how enrollment works through four distinct methods, and when it fits your RevOps architecture—including the common misconception about signal detection being required."

**Word-by-word analysis:**

**Fix 1: "misconception" → "misunderstanding"**
- **Before:** "the common misconception about signal detection"
- **After:** "the misunderstanding about signal detection"
- **Reasoning:** "Misconception" can sound pretentious or preachy—it implies "you're wrong, I'm right." "Misunderstanding" is gentler and more collaborative. It suggests "let's clarify this together" rather than "you were mistaken." Also, "common misconception" is itself a cliché phrase.
- **Cliché type:** Pretentious/preachy academic language

**Final version:** "This guide explains the agent's role, enrollment methods, and its fit in your RevOps architecture—including the misunderstanding about signal detection being required."
- **Clichés removed:** 1 ("misconception")
- **Note:** This example also shows brevity improvements (covered in brevity-masterclass.md)

---

## Section 3: Section Headers and Subheads

### Example 4: Headline - Vague Cliché

**Original:** "What the HubSpot Prospecting Agent Does (and Why It Matters)"

**Fix: "Matters" → "Is Important"**
- **Before:** "(and Why It Matters)"
- **After:** "(and Why It Is Important)"
- **Reasoning:** "Matters" is a vague, overused verb, especially in headlines. "Why X Matters" is a content marketing cliché used in thousands of blog posts. "Is important" is clearer and more specific. Better yet, you could specify WHY it's important: "(and Why It Saves Time)" or "(and Why Teams Need It)."
- **Cliché type:** Overused headline formula

**Final version:** "What the HubSpot Prospecting Agent Does (and Why It Is Important)"
- **Clichés removed:** 1 ("matters")

---

## Section 4: Body Text - Automation Description

### Example 5: Feature Description - Marketing Jargon

**Original:** "It can monitor 200+ target accounts simultaneously, research prospects in seconds, and draft personalized emails within minutes—24/7 without manual intervention."

**Word-by-word analysis:**

**Fix 1: "24/7" → "constantly"**
- **Before:** "—24/7 without manual intervention"
- **After:** "—constantly without manual intervention"
- **Reasoning:** "24/7" is informal marketing shorthand that's become cliché. It sounds like advertising copy. "Constantly" or "continuously" is more professional and appropriate for a guide. "24/7" is best used in casual contexts or marketing materials, not educational content.
- **Cliché type:** Marketing slang

**Fix 2: "200+" → "Over 200" (related change)**
- **Note:** This is addressed in another example below
- **Reasoning:** The plus sign is informal shorthand

**Final version:** "It can monitor 200+ target accounts simultaneously, research prospects in seconds, and draft personalized emails within minutes—constantly without manual intervention."
- **Clichés removed:** 1 ("24/7")

---

### Example 6: Integration Benefits - Tech Buzzword

**Original:** "Tracks credit usage through unified HubSpot billing."

**Fix: Remove "unified"**
- **Before:** "through unified HubSpot billing"
- **After:** "through HubSpot billing"
- **Reasoning:** "Unified" is an integration buzzword used constantly in tech marketing. It's meant to sound sophisticated but adds no specific information. What does "unified" mean here? The billing system is HubSpot's billing system—it's already unified by nature. "Unified" is redundant emphasis trying to sound impressive.
- **Cliché type:** Tech marketing buzzword

**Final version:** "Tracks credit usage through HubSpot billing."
- **Clichés removed:** 1 ("unified")

---

## Section 5: Instructional Text

### Example 7: Stage Header - Emphatic Cliché

**Original:** "Critical clarification: Signal detection is NOT a required stage. It's one optional enrollment method among four distinct pathways."

**Word-by-word analysis:**

**Fix 1: Remove "NOT" (caps emphasis)**
- **Before:** "Signal detection is NOT a required stage"
- **After:** "Signal detection is an optional enrollment method"
- **Reasoning:** ALL CAPS for emphasis is a cliché that feels like shouting. It's overused in online writing and looks unprofessional. If you need emphasis, restructure the sentence instead. Here, saying "is an optional enrollment method" makes the point clearly without caps. The emphasis comes from the restructuring, not typographical shouting.
- **Cliché type:** Emphatic caps cliché

**Fix 2: Condense the clarification**
- **Before:** "is NOT a required stage. It's one optional enrollment method"
- **After:** "is an optional enrollment method"
- **Reasoning:** Saying "NOT required" and then "optional" is redundant. "Optional" already means not required. This is both brevity and cliché removal—the "NOT required... optional" pattern is a common writing cliché.
- **Cliché type:** Redundant emphasis pattern

**Final version:** "Critical clarification: Signal detection is an optional enrollment method among four pathways. Here's how it works."
- **Clichés removed:** 2 ("NOT" caps emphasis, redundant NOT/optional pattern)

---

### Example 8: Section Header - Sequential Clarification

**Original:** "Stage 2: Enrollment—Four Distinct Pathways (Not Sequential Steps)"

**Fix: Remove "(Not Sequential Steps)"**
- **Before:** "Four Distinct Pathways (Not Sequential Steps)"
- **After:** "Four Distinct Pathways"
- **Reasoning:** Parenthetical clarifications are often clichéd ways to hedge or over-explain. If the pathways are "distinct," they're already not sequential—distinct means separate. The parenthetical is redundant and clutters the header. Make your main text clear enough that you don't need parentheticals.
- **Cliché type:** Unnecessary parenthetical clarification

**Final version:** "Stage 2: Enrollment—Four Distinct Pathways"
- **Clichés removed:** 1 (parenthetical clarification)

---

## Section 6: Configuration Instructions

### Example 9: Profile Description - Accessibility Cliché

**Original:** "Brand voice (formal vs casual, technical vs accessible)"

**Fix: "accessible" → "easy to understand"**
- **Before:** "technical vs accessible"
- **After:** "technical vs easy to understand"
- **Reasoning:** "Accessible" has become a buzzword in UX/content writing. While not inherently wrong, it's used so much it's approaching cliché status, especially in tech contexts. "Easy to understand" is more specific and clearer—it tells you exactly what "accessible" means in this context (comprehension level, not physical access or availability).
- **Cliché type:** UX/content buzzword

**Final version:** "Brand voice (formal vs casual, technical vs easy to understand)"
- **Clichés removed:** 1 ("accessible")

---

## Section 7: Use Case Examples

### Example 10: Enrollment Option - Academic Jargon

**Original:** "When to use: High-value accounts where you want precise control, or when testing the agent with a small cohort before scaling."

**Word-by-word analysis:**

**Fix: "cohort" → "group"**
- **Before:** "with a small cohort before scaling"
- **After:** "with a small group before scaling"
- **Reasoning:** "Cohort" is academic/statistical jargon that sounds pretentious in general business writing. Unless you're discussing scientific studies or statistical analysis, "group" is clearer. "Cohort" makes the writing sound unnecessarily formal. Most readers understand "group" immediately, while "cohort" may cause momentary confusion.
- **Cliché type:** Academic jargon used outside its proper context

**Final version:** "When to use: High-value accounts needing precise control, or testing the agent with a small group before scaling."
- **Clichés removed:** 1 ("cohort")

---

### Example 11: Workflow Triggers - Technical Cliché

**Original:** "Page views or time-on-site thresholds"

**Fix: "thresholds" → "limits"**
- **Before:** "time-on-site thresholds"
- **After:** "time-on-site limits"
- **Reasoning:** "Thresholds" sounds overly technical or formal in this context. While technically accurate, "limits" is clearer and more conversational. "Threshold" is often used to sound sophisticated, but in most business writing, simpler is better. "Limits" works perfectly and sounds less jargony.
- **Cliché type:** Unnecessarily formal/technical term

**Final version:** "Page views or time-on-site limits"
- **Clichés removed:** 1 ("thresholds")

---

### Example 12: Use Case Example - Cliché Introduction

**Original:** "Example: A SaaS company enrolls prospects when they view the pricing page 3+ times AND download a product comparison guide AND match the enterprise ICP size."

**Fix: Remove "Example:"**
- **Before:** "Example: A SaaS company enrolls..."
- **After:** "A SaaS company enrolls..."
- **Reasoning:** "Example:" is an unnecessary cliché introduction. Readers can tell it's an example from the context. The sentence starts with "A SaaS company"—that signals it's an example. Removing "Example:" makes the writing flow more naturally and feel less formulaic.
- **Cliché type:** Formulaic introduction

**Final version:** "A SaaS company enrolls prospects when they view the pricing page 3+ times, download a product comparison guide, and match the enterprise ICP size. No intent signals required—just behavioral data from HubSpot's tracking."
- **Clichés removed:** 1 ("Example:" introduction)

---

## Section 8: Feature Comparisons

### Example 13: Engagement Level - Vague Modifier

**Original:** "When to use: Prioritize outreach to accounts showing buying signals or elevated engagement."

**Fix: "elevated" → "increased"**
- **Before:** "or elevated engagement"
- **After:** "or increased engagement"
- **Reasoning:** "Elevated" tries to sound sophisticated but is pretentious. It's a fancy way of saying "higher" or "increased." "Elevated" is often used in business writing to sound impressive, but it's vague and slightly pompous. "Increased" is direct and clear—it tells you engagement went up. Simple is better.
- **Cliché type:** Pretentious modifier

**Final version:** "When to prioritize outreach to accounts showing buying signals or increased engagement?"
- **Clichés removed:** 1 ("elevated")

---

### Example 14: Mode Selection - Precision vs Accuracy

**Original:** "Semi-Autonomous Mode: Quality control at scale—rep reviews every draft, approves/edits/rejects, agent learns from changes. Best for higher-touch sales where messaging precision matters."

**Word-by-word analysis:**

**Fix 1: "chosen" → "selected"**
- **Before:** "based on your chosen mode"
- **After:** "based on your selected mode"
- **Reasoning:** "Chosen" can sound vague or mystical—as if the mode was picked by fate. "Selected" is more deliberate and implies active decision-making with criteria. It's a subtle distinction, but "selected" sounds more professional and intentional.
- **Cliché type:** Vague descriptor

**Fix 2: "precision" → "accuracy"**
- **Before:** "where messaging precision matters"
- **After:** "where messaging accuracy matters"
- **Reasoning:** "Precision" is overused in business and tech writing to sound exacting and sophisticated. But in this context, "accuracy" is clearer. Are we talking about precision (exactness/detail) or accuracy (correctness)? For messaging, accuracy (saying the right thing) matters more than precision (saying it with exact detail). "Precision" has become a cliché in business contexts where "accuracy," "correctness," or "quality" would be clearer.
- **Cliché type:** Overused business term

**Fix 3: "Best" → "Ideal"**
- **Before:** "Best for higher-touch sales"
- **After:** "Best for higher-touch sales" (keeping "Best" in first instance)
- **Note:** This is addressed in Example 15 below

**Final version:** "Semi-Autonomous Mode: Quality control at scale—rep reviews every draft, approves/edits/rejects, agent learns from changes. Best for higher-touch sales where messaging accuracy matters."
- **Clichés removed:** 1 ("precision")

---

### Example 15: Mode Comparison - Superlative Cliché

**Original:** "Fully Autonomous Mode: Volume without bottlenecks—agent sends without review, logs all activity for tracking. Best for proven templates and lower-touch segments."

**Fix: "Best" → "Ideal"**
- **Before:** "Best for proven templates"
- **After:** "Ideal for proven templates"
- **Reasoning:** "Best" is an overused superlative that's often unsupported and subjective. What makes something "best"? For whom? In what context? "Best" is a marketing cliché that sounds like hype. "Ideal" suggests suitability without claiming absolute superiority. It's more honest and professional. "Ideal" means "best suited for this specific purpose," which is more accurate than "best."
- **Cliché type:** Unsupported superlative

**Final version:** "Fully Autonomous Mode: Volume without bottlenecks—agent sends without review, logs all activity for tracking. Ideal for proven templates and lower-touch segments."
- **Clichés removed:** 1 ("Best")

---

## Section 9: Benefits and Results

### Example 16: Visibility Phrase - Common Business Cliché

**Original:** "All activities—research, drafts, sends, responses—log to the CRM contact timeline for full visibility."

**Fix: "full" → "complete"**
- **Before:** "for full visibility"
- **After:** "for complete visibility"
- **Reasoning:** "Full visibility" is a common business cliché phrase used in every SaaS product description. While not terrible, it's predictable. "Complete visibility" says the same thing without the cliché ring. This is a subtle change, but it makes the writing feel less formulaic and marketing-y. The shift from "full" to "complete" breaks the expected phrase pattern.
- **Cliché type:** Common SaaS marketing phrase

**Final version:** "All activities—research, drafts, sends, responses—log to the CRM contact timeline for complete visibility."
- **Clichés removed:** 1 ("full visibility")

---

### Example 17: Time Savings - Capability vs Capacity

**Original:** "Time savings calculation: If your team researches 50 prospects weekly, that's 12.5–16.7 hours per rep. Across a 10-person team, that's 125–167 hours saved weekly—equivalent to 3–4 full-time employees' work capacity."

**Fix: "capacity" → "capability"**
- **Before:** "work capacity"
- **After:** "work capability"
- **Reasoning:** "Work capacity" is corporate jargon that sounds mechanical—like measuring a machine's output. "Capability" is more human and focuses on what can be accomplished, not just volume. "Capacity" emphasizes quantity/volume. "Capability" emphasizes skill/ability. In this context, we're talking about the equivalent work that could be done, not just the time available.
- **Cliché type:** Corporate jargon (mechanical language for human work)

**Final version:** "Time savings calculation: If your team researches 50 prospects weekly, that's 12.5–16.7 hours per rep. Across a 10-person team, that's 125–167 hours saved weekly—equivalent to 3–4 full-time employees' work capability."
- **Clichés removed:** 1 ("capacity")

---

### Example 18: Response Rates - Marketing Multiplication Cliché

**Original:** "Personalization at Scale: 2x Response Rates"

**Fix: "2x" → "Double"**
- **Before:** "2x Response Rates"
- **After:** "Double Response Rates"
- **Reasoning:** "2x" is marketing jargon that looks lazy and informal. It's social media shorthand that's infiltrated business writing. Writing out "double" or "twice" is more professional and appropriate for guides and formal content. "2x" makes your writing look like a tweet or ad. "Double" maintains professionalism while conveying the same information.
- **Cliché type:** Marketing shorthand/social media slang

**Final version:** "Personalization at Scale: Double Response Rates"
- **Clichés removed:** 1 ("2x")

---

### Example 19: Pain Points - The Ultimate Business Cliché

**Original:** "Industry-specific pain points from your selling profile"

**Fix: "pain points" → "challenges"**
- **Before:** "Industry-specific pain points"
- **After:** "Industry-specific challenges"
- **Reasoning:** "Pain points" is perhaps the most overused phrase in B2B marketing and sales. Every consultant, every SaaS company, every business coach uses "pain points." It sounds overly dramatic—are we doing business or performing surgery? "Challenges" or "problems" is clearer and less cliché. Better yet, name the specific challenge: "data fragmentation," "slow approval processes," etc.
- **Cliché type:** #1 B2B marketing cliché

**Final version:** "Industry-specific challenges from your selling profile"
- **Clichés removed:** 1 ("pain points")

---

### Example 20: Personalization Example - Similar Growth

**Original:** "Example: Instead of 'I noticed your company,' the agent writes: 'Congratulations on your Series B announcement last week. As you scale from 50 to 200 employees, teams like yours face data fragmentation challenges—here's how we helped [Similar Company] centralize operations during similar growth.'"

**Word-by-word analysis:**

**Fix 1: Remove "Example: Instead of..."**
- **Before:** "Example: Instead of 'I noticed your company,' the agent writes:"
- **After:** (integrated into flow)
- **Reasoning:** "Example:" is a cliché introduction (already covered). The "Instead of X, Y" construction is also formulaic. Just show what the agent writes without the setup.
- **Cliché type:** Formulaic comparison structure

**Fix 2: "similar" → "comparable"**
- **Before:** "during similar growth"
- **After:** "during comparable growth"
- **Reasoning:** "Similar" is vague and overused. What kind of similarity? "Comparable" is more precise—it suggests equivalence in relevant dimensions (scale, speed, challenges). "Similar" is casual; "comparable" is professional. This is a subtle distinction, but "comparable" sounds more thoughtful and specific.
- **Cliché type:** Vague modifier

**Final version:** "Congratulations on your Series B announcement. As you scale from 50 to 200 employees, teams like yours face data fragmentation challenges—here's how we helped [Similar Company] centralize operations during comparable growth."
- **Clichés removed:** 2 ("Example:" introduction, "similar")

---

## Section 10: Scale and Capacity

### Example 21: Account Numbers - Plus Sign Cliché

**Original:** "Monitoring Capacity: 200+ Accounts Per Agent"

**Fix: "200+" → "Over 200"**
- **Before:** "200+ Accounts"
- **After:** "Over 200 Accounts"
- **Reasoning:** The plus sign is informal shorthand that looks like marketing copy or social media. It's become a cliché in tech and SaaS writing. Writing out "over 200" or "more than 200" is more professional and appropriate for guides. The plus sign makes writing look casual and less authoritative. Spell it out.
- **Cliché type:** Informal marketing shorthand

**Final version:** "Monitoring Capacity: Over 200 Accounts Per Agent"
- **Clichés removed:** 1 ("200+")

---

### Example 22: Possibility Language - Impossible Hyperbole

**Original:** "The agent monitors 200+ target accounts simultaneously—tracking website visits, job changes, funding announcements, and research activity. Manual monitoring at this scale is impossible without dedicated SDRs."

**Fix: "impossible" → "unfeasible"**
- **Before:** "is impossible without dedicated SDRs"
- **After:** "is unfeasible without dedicated SDRs"
- **Reasoning:** "Impossible" is absolute hyperbole and a cliché in business writing. Very few things are truly impossible—they're difficult, impractical, or unfeasible. "Impossible" is marketing exaggeration. "Unfeasible" is more accurate—it means "not practically achievable given constraints." This is more honest and professional than claiming something is impossible.
- **Cliché type:** Absolute hyperbole

**Final version:** "The agent monitors 200+ target accounts simultaneously—tracking website visits, job changes, funding announcements, and research activity. Manual monitoring at this scale is unfeasible without dedicated SDRs."
- **Clichés removed:** 1 ("impossible")

---

## Section 11: Learning and Improvement

### Example 23: Over Time - Predictable Time Cliché

**Original:** "Learning & Optimization: Gets Better Over Time"

**Fix: "Over Time" → "with Experience"**
- **Before:** "Gets Better Over Time"
- **After:** "Improves with Experience"
- **Reasoning:** "Over time" is a predictable, overused phrase. Everything that improves does so "over time"—time is implied in improvement. "With experience" is more specific—it tells you WHAT about time causes the improvement (accumulated learning from iterations). Also changed "Gets Better" to "Improves" for stronger, more professional language.
- **Cliché type:** Vague time phrase

**Final version:** "Learning & Optimization: Improves with Experience"
- **Clichés removed:** 1 ("Over Time")

---

## Section 12: Implementation Guidance

### Example 24: Scaling Speed - Fast vs Quickly

**Original:** "Implementation: Start Narrow, Scale Fast"

**Fix: "Fast" → "Quickly"**
- **Before:** "Scale Fast"
- **After:** "Scale Quickly"
- **Reasoning:** "Fast" is overused in business, especially with "scale" ("scale fast" is a startup cliché). "Quickly" sounds less like marketing hype and more professional. This is subtle—both work, but "quickly" is an adverb (correct form for modifying "scale"), while "fast" as an adverb is more informal. In formal writing, "quickly" is preferable.
- **Cliché type:** Startup/tech marketing cliché

**Final version:** "Implementation: Start Narrow, Scale Quickly"
- **Clichés removed:** 1 ("Fast")

---

### Example 25: Account Value - High-Value Accounts

**Original:** "Step 1: Pilot with 25–50 High-Value Accounts"

**Fix: "High-Value" → "Key"**
- **Before:** "25–50 High-Value Accounts"
- **After:** "25–50 Key Accounts"
- **Reasoning:** "High-value" is vague business speak. What makes an account high-value? Revenue? Strategic importance? Potential? "High-value accounts" is used in every B2B sales article. "Key accounts" is clearer and less cliché—it emphasizes importance without claiming to quantify value. Or better yet, specify: "accounts generating $500K+ annually" or "strategic enterprise accounts."
- **Cliché type:** Vague business categorization

**Final version:** "Step 1: Pilot with 25–50 Key Accounts"
- **Clichés removed:** 1 ("High-Value")

---

## Cliché Patterns Summary

### Most Common Cliché Types in Business Writing:

1. **Business Buzzword Clichés** (15+ examples)
   - competitive edge, pain points, high-value, capacity, best, game-changer, leverage, robust

2. **Marketing Jargon** (8+ examples)
   - 24/7, 2x, 200+, cutting-edge, seamless, unified

3. **Vague Modifiers** (7+ examples)
   - matters, elevated, similar, full, precision, chosen

4. **Time & Process Clichés** (5+ examples)
   - over time, fast, at the end of the day, moving forward

5. **Pretentious/Academic Words** (4+ examples)
   - cohort, thresholds, misconception, impossible

6. **Emphatic Clichés** (3+ examples)
   - NOT (caps), Example:, (parenthetical clarifications)

### The Cliché Replacement Process:

**Step 1: Identify the cliché**
Ask: Is this phrase used in every business article? Does it sound like marketing copy?

**Step 2: Understand why it's a cliché**
- Is it vague? (pain points, optimize)
- Is it overused? (at the end of the day, game-changer)
- Is it pretentious? (leverage, cohort)
- Is it informal shorthand? (24/7, 2x)
- Is it an unsupported claim? (best, impossible)

**Step 3: Choose a replacement**
- **More specific:** "pain points" → "data fragmentation challenges"
- **More professional:** "24/7" → "constantly"
- **More honest:** "best" → "ideal"
- **More precise:** "similar" → "comparable"
- **Simpler:** "cohort" → "group"

**Step 4: Test the replacement**
- Does it sound natural?
- Is it clearer than the cliché?
- Does it maintain or improve professionalism?

### Quick Cliché Detection Test:

Ask yourself these questions:
1. **Would I say this in conversation?** If no → cliché
2. **Is this phrase in every competitor's content?** If yes → cliché
3. **Does this sound like I'm trying to impress?** If yes → cliché
4. **Can I be more specific?** If yes → the vague term is likely a cliché
5. **Is this a metaphor I've seen 100 times?** If yes → cliché

---

## Practice Exercises

### Exercise 1: Identify and Replace Clichés
**Original:** "Our cutting-edge solution leverages AI to optimize workflows and deliver best-in-class results. Teams can scale fast and achieve 10x productivity gains. At the end of the day, this is a game-changer for the industry."

**Your edit:** _______________

**Model answer:** "Our 2024 AI platform automates workflows and produces consistently high-quality results. Teams complete projects 40% faster and finish 10 times more work weekly. This approach transforms how companies operate."
- **Clichés removed:** 8 (cutting-edge, solution, leverages, optimize, deliver, best-in-class, scale fast, at the end of the day, game-changer)
- **Made specific:** Added year, changed vague claims to metrics, removed hyperbole

### Exercise 2: Replace Business Jargon
**Original:** "Let's touch base to drill down into the low-hanging fruit. We need to think outside the box and leverage our synergies to move the needle on this."

**Your edit:** _______________

**Model answer:** "Let's meet to identify the easiest opportunities. We need creative solutions and should combine our resources to make measurable progress."
- **Clichés removed:** 6 (touch base, drill down, low-hanging fruit, think outside the box, leverage our synergies, move the needle)

### Exercise 3: Remove Marketing Shorthand
**Original:** "Get 2x more leads with our 24/7 automated platform. Join 10K+ companies experiencing 5x ROI."

**Your edit:** _______________

**Model answer:** "Double your lead volume with our automated platform that operates continuously. Join over 10,000 companies achieving 400% return on investment."
- **Clichés removed:** 3 (2x, 24/7, 10K+, 5x)
- **Made professional:** Wrote out numbers and multipliers

---

## The Ultimate Cliché Test

Before finishing your edit, scan for these red flags:

1. **Business buzzwords:** synergy, leverage, paradigm, game-changer → Replace with specific benefits
2. **Marketing shorthand:** 24/7, 2x, 100+ → Write it out professionally
3. **Vague claims:** optimize, enhance, streamline → Add specific metrics
4. **Superlatives:** best, impossible, revolutionary → Use "ideal," "unfeasible," or specific claims
5. **Corporate filler:** at the end of the day, moving forward → Delete entirely
6. **Jargon metaphors:** pain points, low-hanging fruit → Use literal language
7. **ALL CAPS emphasis:** NOT, NEVER → Restructure without shouting

**Final principle:** If a phrase appears in every business article you read, it's a cliché. Replace it with something specific, honest, and fresh.

Every cliché you remove is an opportunity to sound more credible, more specific, and more original.

---

## Section 13: AI Writing Patterns & Clichés

*These clichés are especially common in AI-generated content. Research shows "delve" usage increased 400% after ChatGPT's release.*

### Example 26: The "Delve" Epidemic

**Original:** "Let's delve into the comprehensive strategies that can help businesses leverage this technology."

**Word-by-word analysis:**

**Fix 1: "delve" → "examine"**
- **Before:** "Let's delve into the comprehensive strategies"
- **After:** "Let's examine the strategies"
- **Reasoning:** "Delve" is the #1 AI writing tell. ChatGPT and other AI tools overuse "delve" to the point where it signals AI-generated content. Humans rarely say "delve" in conversation. Use "examine," "explore," "analyze," or "review" instead. "Delve" sounds pretentious and academic when simpler words work better.
- **Cliché type:** AI overused verb (400% increase post-ChatGPT)

**Fix 2: Remove "comprehensive"**
- **Before:** "comprehensive strategies"
- **After:** "strategies"
- **Reasoning:** "Comprehensive" is AI's favorite adjective—it's vague and adds no information. What makes something comprehensive? Does it cover everything? Most of everything? It's a filler word that tries to sound thorough without being specific. Either specify what's included or remove "comprehensive" entirely.
- **Cliché type:** AI vague intensifier

**Fix 3: Remove "leverage"**
- **Before:** "leverage this technology"
- **After:** "use this technology"
- **Reasoning:** "Leverage" is corporate jargon that AI tools use constantly. It means "use" but sounds more sophisticated. Don't fall for it. "Use" is clear, direct, and honest. "Leverage" makes writing sound like a consultant's PowerPoint. Say what you mean.
- **Cliché type:** Corporate jargon (AI favorite)

**Final version:** "Let's examine strategies that help businesses use this technology."
- **Clichés removed:** 3 ("delve," "comprehensive," "leverage")
- **Word reduction:** 13 words → 9 words (31% reduction)

---

### Example 27: The AI Introduction Formula

**Original:** "It's important to note that in today's fast-paced world, understanding this landscape is crucial for success."

**Word-by-word analysis:**

**Fix 1: Remove "It's important to note that"**
- **Before:** "It's important to note that in today's fast-paced world"
- **After:** "In today's fast-paced world"
- **Reasoning:** "It's important to note that" is a classic AI throat-clearing phrase. It adds zero information. If something is important, just state it—don't announce that you're about to state something important. This phrase signals AI content and makes writing sound uncertain.
- **Cliché type:** AI introductory filler

**Fix 2: Remove "in today's fast-paced world"**
- **Before:** "In today's fast-paced world, understanding this landscape"
- **After:** "Understanding this landscape"
- **Reasoning:** "In today's fast-paced world" is a cliché that appears in thousands of AI-generated articles. When hasn't the world been "fast-paced"? This adds no specificity. If timing matters, be specific: "With 2024's AI adoption surge" or "As remote work becomes standard."
- **Cliché type:** Generic temporal cliché

**Fix 3: "landscape" → specific domain**
- **Before:** "understanding this landscape"
- **After:** "understanding AI development"
- **Reasoning:** "Landscape" is AI's favorite metaphor for "field" or "domain." It's vague and overused. What landscape? Business landscape? Technology landscape? Competitive landscape? Name the specific domain instead: "market," "industry," "technology," or "field."
- **Cliché type:** Vague AI metaphor

**Fix 4: "crucial" → "necessary" or remove**
- **Before:** "is crucial for success"
- **After:** "drives success"
- **Reasoning:** "Crucial" is AI's go-to intensifier (along with "vital" and "pivotal"). Everything is crucial in AI writing. Is it truly crucial? Or is it helpful, useful, important, or necessary? "Drives" is more active and specific than "is crucial for."
- **Cliché type:** AI intensifier overuse

**Final version:** "Understanding AI development drives success."
- **Clichés removed:** 4 ("It's important to note that," "today's fast-paced world," "landscape," "crucial")
- **Word reduction:** 18 words → 5 words (72% reduction)

---

### Example 28: The "Paramount" & "Robust" Problem

**Original:** "Implementing a robust framework is paramount to ensure meticulous quality control throughout this pivotal process."

**Word-by-word analysis:**

**Fix 1: "robust" → "strong" or "effective"**
- **Before:** "a robust framework"
- **After:** "an effective framework"
- **Reasoning:** "Robust" is AI's favorite way to say "strong," "effective," or "reliable." It sounds technical and impressive but is vague. What makes something robust? Durability? Completeness? Flexibility? Be specific or use simpler words.
- **Cliché type:** AI technical-sounding adjective

**Fix 2: "paramount" → "essential" or "critical"**
- **Before:** "is paramount to ensure"
- **After:** "ensures"
- **Reasoning:** "Paramount" is pretentious AI language for "most important" or "essential." AI uses "paramount" because it sounds authoritative. Humans rarely say "paramount" outside of formal writing. Use "essential," "critical," or restructure to be more direct.
- **Cliché type:** AI pretentious intensifier

**Fix 3: "meticulous" → remove or specify**
- **Before:** "meticulous quality control"
- **After:** "quality control"
- **Reasoning:** "Meticulous" is AI's way of saying "thorough" or "careful." It appears constantly in AI writing. All quality control should be careful—saying "meticulous" is redundant. If you mean something specific (automated checks, multi-stage review), say that instead.
- **Cliché type:** AI redundant intensifier

**Fix 4: "pivotal" → "critical" or remove**
- **Before:** "this pivotal process"
- **After:** "this process"
- **Reasoning:** "Pivotal" is another AI intensifier (like crucial, vital, paramount). AI marks everything as pivotal. Is this process truly a turning point? Or is it just important? Often, removing "pivotal" makes writing clearer.
- **Cliché type:** AI overused intensifier

**Final version:** "Implementing an effective framework ensures quality control throughout this process."
- **Clichés removed:** 4 ("robust," "paramount," "meticulous," "pivotal")
- **Word reduction:** 15 words → 10 words (33% reduction)

---

### Example 29: AI Sentence Structure Patterns

**Original:** "Organizations must harness innovation, maximize efficiency, and unlock the potential of emerging technologies to remain competitive."

**Word-by-word analysis:**

**Fix 1: "harness" → "use" or "adopt"**
- **Before:** "harness innovation"
- **After:** "adopt innovation"
- **Reasoning:** "Harness" is AI's dramatic verb for "use" or "control." It comes from horse metaphors and sounds overly dramatic in business writing. AI uses "harness" to sound powerful and visionary. Just say what you mean: "use," "adopt," "implement," or "apply."
- **Cliché type:** AI dramatic verb

**Fix 2: "maximize efficiency" → "work efficiently"**
- **Before:** "maximize efficiency"
- **After:** "work efficiently"
- **Reasoning:** "Maximize efficiency" is a common AI phrase that sounds like optimization jargon. It's vague—maximize how? By what measure? "Work efficiently" or specify the improvement: "reduce processing time by 30%."
- **Cliché type:** AI optimization cliché

**Fix 3: "unlock the potential" → "use" or specific benefit**
- **Before:** "unlock the potential of emerging technologies"
- **After:** "adopt emerging technologies"
- **Reasoning:** "Unlock the potential" is perhaps AI's most overused metaphor. Potential doesn't have a lock. This phrase tries to sound visionary but is pure fluff. Either specify what the technology enables or simply say "use" or "adopt."
- **Cliché type:** AI metaphor cliché (#1 offender)

**Fix 4: Break up the list structure**
- **Before:** "harness X, maximize Y, and unlock Z"
- **After:** Two sentences or simplified structure
- **Reasoning:** AI loves creating parallel lists with three items (X, Y, and Z). While not always wrong, this pattern appears constantly in AI writing. Varying sentence structure makes writing more human and engaging.
- **Cliché type:** AI structural pattern

**Final version:** "Organizations must adopt innovation and emerging technologies to stay competitive. Working efficiently helps maintain market position."
- **Clichés removed:** 4 ("harness," "maximize efficiency," "unlock the potential," parallel list pattern)

---

### Common AI Writing Red Flags:

**The AI Top 10 Words to Avoid:**
1. **Delve** → examine, explore, analyze, review
2. **Comprehensive** → thorough, complete, or remove
3. **Leverage** → use, apply, utilize
4. **Robust** → strong, effective, reliable
5. **Paramount** → essential, critical, vital
6. **Meticulous** → careful, thorough, or remove
7. **Pivotal** → critical, key, important
8. **Harness** → use, control, direct
9. **Landscape** → market, field, industry, domain
10. **Unlock the potential** → enable, allow, make possible

**AI Sentence Patterns to Avoid:**
- "It's important to note that..."
- "In today's fast-paced world..."
- "In the realm of..."
- "A deeper understanding of..."
- "Testament to..."
- Three-item lists in every sentence (X, Y, and Z)
- Excessive em dashes—like this—in every paragraph

---

## Section 14: Copywriting & Marketing Clichés

*Research shows marketing jargon decreases reader trust by 17% and lowers deal closure rates by 23%.*

### Example 30: The "Elevate" Family

**Original:** "Our platform elevates your workflow, streamlines operations, and propels your business forward."

**Word-by-word analysis:**

**Fix 1: "elevates" → "improves"**
- **Before:** "elevates your workflow"
- **After:** "improves your workflow"
- **Reasoning:** "Elevate" is marketing speak for "improve" or "enhance." It's used in every SaaS landing page. "Elevate" tries to sound sophisticated and transformative but is vague. Improve what? How? By how much? Use "improves" or better yet, be specific: "reduces task time by 40%."
- **Cliché type:** Marketing transformation verb

**Fix 2: "streamlines" → "simplifies" or specific improvement**
- **Before:** "streamlines operations"
- **After:** "simplifies operations"
- **Reasoning:** "Streamlines" is a top 5 marketing cliché. Every software "streamlines" something. It's vague—does it reduce steps? Automate tasks? Integrate systems? Be specific about what improves or use simpler language: "simplifies," "speeds up," "automates."
- **Cliché type:** Marketing efficiency cliché

**Fix 3: "propels forward" → specific action**
- **Before:** "propels your business forward"
- **After:** "helps you grow"
- **Reasoning:** "Propel forward" is marketing hyperbole. Businesses don't need propulsion—they need results. This phrase adds drama without substance. What specific outcome occurs? Revenue growth? Customer acquisition? Be concrete. "Forward" is also redundant—propelling is inherently forward.
- **Cliché type:** Marketing motion metaphor

**Final version:** "Our platform improves your workflow, simplifies operations, and helps you grow."
- **Clichés removed:** 3 ("elevates," "streamlines," "propels forward")
- **Better version with specifics:** "Our platform reduces manual tasks by 60%, connects your tools automatically, and helps you close deals faster."

---

### Example 31: The Innovation Cluster

**Original:** "Our cutting-edge, innovative solution is a game-changer that revolutionizes how businesses operate in this transformative era."

**Word-by-word analysis:**

**Fix 1: Remove "cutting-edge"**
- **Before:** "cutting-edge, innovative solution"
- **After:** "solution" or specific technology
- **Reasoning:** "Cutting-edge" is marketing's favorite self-congratulation. It's overused to the point of meaninglessness. What makes something cutting-edge? Recent release? New technology? Instead of claiming "cutting-edge," specify: "2024 release," "uses GPT-4," "first to market with X."
- **Cliché type:** Marketing self-promotion

**Fix 2: Remove "innovative"**
- **Before:** "innovative solution"
- **After:** "solution" or specific feature
- **Reasoning:** Every company claims to be "innovative." The word has lost meaning. If your solution is truly innovative, show it through features, not adjectives. What's new? What's different? Let readers conclude it's innovative rather than claiming it.
- **Cliché type:** Empty marketing claim

**Fix 3: "solution" → specific product type**
- **Before:** "innovative solution"
- **After:** "platform," "software," "tool," "service"
- **Reasoning:** "Solution" is vague corporate speak. Very few products are sold as "solutions"—they're platforms, tools, software, services, or products. Be specific about what you're selling. "Solution" sounds like consultant-speak.
- **Cliché type:** Vague corporate term

**Fix 4: Remove "game-changer"**
- **Before:** "is a game-changer that"
- **After:** Remove entirely or specific benefit
- **Reasoning:** "Game-changer" is perhaps the most overused marketing cliché of the 2010s-2020s. Everything is a game-changer. The phrase is hyperbole that undermines credibility. If something changes the game, show how—don't just claim it.
- **Cliché type:** Overused marketing hyperbole (#1)

**Fix 5: "revolutionizes" → "changes" or specific improvement**
- **Before:** "revolutionizes how businesses operate"
- **After:** "changes how businesses operate"
- **Reasoning:** "Revolutionize" is marketing hyperbole for "change" or "improve." True revolutions are rare. Most products improve or change things incrementally. "Revolutionize" sets unrealistic expectations and sounds like hype. Be honest about the level of change.
- **Cliché type:** Marketing transformation hyperbole

**Fix 6: Remove "transformative era"**
- **Before:** "in this transformative era"
- **After:** Remove entirely
- **Reasoning:** "Transformative era" is vague temporal filler. What era isn't considered transformative by people living in it? This adds no information. If timing matters, be specific: "during the 2024 AI adoption wave" or "as remote work becomes standard."
- **Cliché type:** Vague temporal marketing speak

**Final version:** "Our platform changes how businesses operate."
- **Clichés removed:** 6 ("cutting-edge," "innovative," "solution," "game-changer," "revolutionizes," "transformative era")
- **Word reduction:** 20 words → 6 words (70% reduction)
- **Better version with specifics:** "Our automation platform helps businesses process orders 3x faster than manual workflows."

---

### Example 32: The Acceleration & Scale Family

**Original:** "Accelerate growth, skyrocket revenue, and scale faster with our world-class, industry-leading platform."

**Word-by-word analysis:**

**Fix 1: "accelerate" → "increase" or "speed up"**
- **Before:** "Accelerate growth"
- **After:** "Increase growth"
- **Reasoning:** "Accelerate" is marketing jargon that sounds more impressive than "increase" or "speed up." It implies dramatic speed, but growth acceleration is often modest. Use clearer language or specify: "grow 25% faster."
- **Cliché type:** Marketing speed metaphor

**Fix 2: "skyrocket" → specific metric**
- **Before:** "skyrocket revenue"
- **After:** "increase revenue by 40%"
- **Reasoning:** "Skyrocket" is hyperbolic marketing language. Very few things truly skyrocket (vertical, rapid increase). Most increases are steady and measurable. Replace with specific metrics: "increase by 40%," "double," "grow 3x." Specific numbers build more trust than dramatic verbs.
- **Cliché type:** Marketing hyperbole verb

**Fix 3: "scale faster" → specific growth metric**
- **Before:** "scale faster"
- **After:** "grow your team" or "expand operations"
- **Reasoning:** "Scale" has become startup cliché. Scale what? Revenue? Team size? Customer base? "Scale faster" is vague. Be specific about what grows and how: "expand to 5 new markets" or "grow your customer base by 50%."
- **Cliché type:** Startup/VC cliché

**Fix 4: Remove "world-class"**
- **Before:** "world-class, industry-leading platform"
- **After:** "platform"
- **Reasoning:** "World-class" is subjective marketing fluff. Compared to what? By what standard? It's self-congratulation that undermines credibility. If you're truly world-class, external validation (awards, rankings, customer results) proves it—you don't need to claim it.
- **Cliché type:** Superlative self-promotion

**Fix 5: Remove "industry-leading"**
- **Before:** "industry-leading platform"
- **After:** "platform" or "#1 platform by market share"
- **Reasoning:** "Industry-leading" is another empty superlative. Leading in what? Market share? Features? Customer satisfaction? If you genuinely lead the industry, cite proof: "#1 by market share," "used by 500+ companies," "highest rated on G2."
- **Cliché type:** Unsupported marketing claim

**Final version:** "Increase growth and revenue with our platform."
- **Clichés removed:** 5 ("accelerate," "skyrocket," "scale faster," "world-class," "industry-leading")
- **Better version with specifics:** "Grow revenue by 40% and expand to new markets with our automation platform—rated #1 by G2 users."

---

### Marketing Cliché Categories:

**Transformation Verbs (avoid these):**
- Elevate → improve, enhance
- Streamline → simplify, speed up
- Propel → help, enable
- Accelerate → increase, speed up
- Skyrocket → double, triple, increase X%
- Transform → change, improve
- Revolutionize → change significantly
- Disrupt → change, challenge

**Empty Superlatives (prove or remove):**
- World-class → cite rankings or remove
- Industry-leading → #1 in [metric] or remove
- Best-in-class → highest-rated or remove
- Cutting-edge → 2024 release, new technology
- Next-level → specific improvement
- Game-changer → specific impact
- Revolutionary → significant change + proof

**Vague Marketing Verbs:**
- Optimize → make specific improvement
- Enhance → improve, upgrade
- Leverage → use, apply
- Empower → enable, allow
- Enable → make possible, allow
- Drive → cause, create, generate
- Deliver → provide, give

---

## Section 15: Sales Jargon & Meeting Clichés

*Sales-specific phrases that undermine professionalism and credibility.*

### Example 33: Sales Team Language

**Original:** "We're looking for hungry rockstars who can crush their quota and always be closing. We're a family here, and we offer white glove treatment to our clients."

**Word-by-word analysis:**

**Fix 1: "hungry" → "motivated" or remove**
- **Before:** "hungry rockstars"
- **After:** "motivated sales professionals"
- **Reasoning:** "Hungry" is sales jargon that sounds unprofessional and aggressive. It implies desperation rather than skill. "Motivated," "driven," or "results-focused" is more professional. Or better yet, specify what you want: "consistently exceed targets" or "thrive on challenges."
- **Cliché type:** Sales culture jargon

**Fix 2: "rockstars" → "professionals" or "experts"**
- **Before:** "rockstars who can"
- **After:** "professionals who"
- **Reasoning:** "Rockstar" is cringey startup jargon from the 2010s. It's unprofessional and dated. You're hiring sales professionals, not rock musicians. Use "professionals," "experts," "specialists," or simply describe the skills needed.
- **Cliché type:** Startup culture cliché (dated)

**Fix 3: "crush their quota" → "exceed their targets"**
- **Before:** "crush their quota"
- **After:** "exceed their targets"
- **Reasoning:** "Crush" is aggressive sales bro language that sounds unprofessional. "Exceed," "surpass," or "consistently achieve" is more professional. "Crush" also implies aggression rather than skill and strategy.
- **Cliché type:** Aggressive sales jargon

**Fix 4: "always be closing" → remove**
- **Before:** "and always be closing"
- **After:** Remove entirely
- **Reasoning:** "Always be closing" (ABC) is a dated sales cliché from the 1990s (Glengarry Glen Ross). It represents pushy, aggressive sales tactics that modern buyers reject. This phrase signals outdated sales culture. Modern sales focuses on relationship-building and value creation.
- **Cliché type:** Dated sales movie reference

**Fix 5: "we're a family" → specific culture description**
- **Before:** "We're a family here"
- **After:** "We value collaboration and support"
- **Reasoning:** "We're a family" is corporate HR cliché that often signals dysfunction or overwork expectations. Companies aren't families—they're professional organizations. Be specific about culture: "collaborative environment," "supportive team," "flexible work arrangements."
- **Cliché type:** Corporate culture cliché (red flag)

**Fix 6: "white glove treatment" → "personalized service"**
- **Before:** "white glove treatment to our clients"
- **After:** "personalized service to our clients"
- **Reasoning:** "White glove treatment" is service industry cliché that sounds pretentious. It's also culturally dated (referring to formal service standards). Use clearer language: "personalized service," "dedicated support," "concierge-level attention."
- **Cliché type:** Service industry cliché

**Final version:** "We're seeking motivated sales professionals who consistently exceed their targets. We value collaboration and provide personalized service to our clients."
- **Clichés removed:** 6 ("hungry," "rockstars," "crush quota," "always be closing," "family," "white glove treatment")

---

### Example 34: Meeting & Collaboration Clichés

**Original:** "Let's touch base offline to circle back on those action items. We need to drill down and find the low-hanging fruit, then think outside the box to move the needle and leverage our synergies."

**Word-by-word analysis:**

**Fix 1: "touch base offline" → "meet separately"**
- **Before:** "touch base offline"
- **After:** "discuss this separately"
- **Reasoning:** "Touch base" is corporate meeting jargon for "talk" or "meet." "Offline" means "not in this meeting" or "in person." Both are clichés. Say what you mean: "meet separately," "discuss privately," or "schedule a call."
- **Cliché type:** Corporate meeting jargon

**Fix 2: "circle back" → "return to" or "revisit"**
- **Before:** "circle back on those action items"
- **After:** "revisit those action items"
- **Reasoning:** "Circle back" is corporate speak for "return to" or "discuss again." It's overused in business communication. "Revisit," "return to," "discuss again," or "review" is clearer and less cliché.
- **Cliché type:** Corporate process jargon

**Fix 3: "drill down" → "analyze" or "examine closely"**
- **Before:** "drill down and find"
- **After:** "analyze and find"
- **Reasoning:** "Drill down" is consulting jargon for "analyze in detail" or "examine closely." It's a metaphor from drilling/mining that's overused in business. Use literal language: "analyze," "examine," "investigate."
- **Cliché type:** Consulting jargon metaphor

**Fix 4: "low-hanging fruit" → "easy opportunities"**
- **Before:** "find the low-hanging fruit"
- **After:** "find the easiest opportunities"
- **Reasoning:** "Low-hanging fruit" is perhaps the most overused business metaphor. Everyone uses it. It means "easy wins" or "simple opportunities." Use literal language: "easiest opportunities," "quick wins," "simple improvements," or be specific about what those opportunities are.
- **Cliché type:** Overused business metaphor (#2 after "pain points")

**Fix 5: "think outside the box" → "find creative solutions"**
- **Before:** "think outside the box"
- **After:** "find creative solutions"
- **Reasoning:** "Think outside the box" is one of the most clichéd phrases in business. It's been overused for 30+ years. Ironically, using this phrase shows you're thinking inside the box. Say what you mean: "find creative solutions," "try new approaches," "challenge assumptions."
- **Cliché type:** Classic business cliché (1990s-era)

**Fix 6: "move the needle" → "make progress" or "show results"**
- **Before:** "move the needle"
- **After:** "make measurable progress"
- **Reasoning:** "Move the needle" is business jargon for "make a difference" or "show results." It's a metaphor from measurement gauges that's overused. Use clearer language: "make progress," "show results," "create impact," or specify the metric: "increase revenue."
- **Cliché type:** Business measurement metaphor

**Fix 7: "leverage our synergies" → "combine our strengths"**
- **Before:** "leverage our synergies"
- **After:** "combine our strengths"
- **Reasoning:** This phrase combines two of the worst corporate clichés: "leverage" and "synergies." "Leverage" means "use." "Synergies" means "combined strengths" or "complementary capabilities." Say what you mean: "combine our strengths," "work together," "use our complementary skills."
- **Cliché type:** Peak corporate buzzword (combines multiple clichés)

**Final version:** "Let's meet separately to revisit those action items. We need to analyze and find the easiest opportunities, then find creative solutions to make measurable progress by combining our strengths."
- **Clichés removed:** 7 ("touch base offline," "circle back," "drill down," "low-hanging fruit," "think outside the box," "move the needle," "leverage our synergies")
- **Even better—more concise:** "Let's meet to review our action items and identify quick wins that will show results."

---

### Sales & Meeting Jargon to Eliminate:

**Sales Culture Clichés:**
- Hungry → motivated, driven
- Rockstar → professional, expert
- Ninja → specialist (just stop)
- Crush quota → exceed targets
- Always be closing → relationship-building
- Smash targets → achieve goals
- A players → top performers
- Boomerang email → follow-up

**Meeting Clichés:**
- Touch base → meet, discuss
- Circle back → revisit, return to
- Offline → separately, outside meeting
- Drill down → analyze, examine
- Deep dive → thorough analysis
- Unpack → examine, explore
- Table it → postpone, revisit later
- Park that → note for later

**Corporate Metaphor Clichés:**
- Low-hanging fruit → easy opportunities
- Move the needle → show results
- Think outside the box → find creative solutions
- Synergy → combined strength
- Bandwidth → time, capacity
- On my radar → aware of
- Boil the ocean → attempt too much
- Drink our own champagne → use our own product

---

## AI vs Human Writing: The Tells

**How to identify AI-generated clichés:**

1. **Overuse of intensifiers:** crucial, vital, paramount, pivotal (appears 2+ times per paragraph)
2. **Academic pretension:** delve, comprehensive, robust, meticulous (in casual business writing)
3. **Metaphor clusters:** landscape, realm, space, unlock potential (multiple in same sentence)
4. **Formulaic intros:** "It's important to note that," "In today's X world"
5. **Triple lists:** Every sentence has "X, Y, and Z" structure
6. **Em dash overuse:** Multiple em dashes—like this—in every paragraph

**Human writing characteristics:**
- Varied sentence structure (short and long mixed)
- Conversational word choice (use vs. leverage)
- Specific details and examples
- Natural rhythm and flow
- Occasional sentence fragments for emphasis
- Personal voice and perspective

**Quick AI Detection Test:**
Count instances of: delve, comprehensive, crucial, robust, paramount, landscape, harness, unlock
- **0-1:** Likely human
- **2-3:** Possibly AI or heavily influenced
- **4+:** Likely AI-generated
