# Brevity Masterclass: Word-by-Word Editing

This guide demonstrates granular brevity editing with detailed explanations for every change, modeling the precision needed for world-class copy editing.

---

## The Brevity Mindset

**Core principle:** Question every single word. If removing a word doesn't change the meaning, remove it. If you can say something in fewer words without losing clarity, do it.

**Target:** 20-40% word reduction in most professional content while preserving (or enhancing) clarity.

---

## Section 1: Titles and Headlines

### Example 1: SEO Title Editing

**Original:** "HubSpot Prospecting Agent: Setup, Features & Real Results"

**Edit Options:**

**Option A: Remove "Real"**
- **Edited:** "HubSpot Prospecting Agent: Setup, Features & Results"
- **Reasoning:** "Real" is implied. All results should be real. The word adds skepticism rather than credibility. Removing it makes the title cleaner without losing meaning.
- **Word count:** 7 → 6 (14% reduction)

**Option B: Condense "Setup"**
- **Edited:** "HubSpot Prospecting Agent: Guide, Features & Results"
- **Reasoning:** "Setup" is narrow. "Guide" encompasses setup plus more, making the content promise broader without adding words.
- **Word count:** 7 → 6 (14% reduction)

**Option C: Maximum brevity**
- **Edited:** "HubSpot Prospecting Agent: Complete Guide"
- **Reasoning:** "Complete Guide" implies setup, features, and results. This is the briefest version but loses some specificity about what's covered.
- **Word count:** 7 → 4 (43% reduction)

**Best choice:** Option A. It balances brevity with specificity.

---

### Example 2: Meta Description Editing

**Original:** "Discover how HubSpot's Prospecting Agent automates research and personalized outreach. Learn setup options, features, pricing, and verified results from sales teams."

**Edit 1: Remove "personalized"**
- **Before:** "automates research and personalized outreach"
- **After:** "automates research and outreach"
- **Reasoning:** "Automates research and outreach" already implies the outreach is targeted. The automation wouldn't work if outreach was generic. "Personalized" is redundant when discussing automated research-based outreach.
- **Word saved:** 1

**Edit 2: Remove "verified"**
- **Before:** "and verified results from sales teams"
- **After:** "and results from sales teams"
- **Reasoning:** Results from real sales teams are inherently more credible than claims. "Verified" adds a word without adding trust. If anything, saying "verified" makes readers wonder why you need to convince them.
- **Word saved:** 1

**Final edited version:** "Discover how HubSpot's Prospecting Agent automates research and outreach. Learn setup options, features, pricing, and results from sales teams."
- **Word count:** 27 → 25 (7% reduction)
- **Character count:** 170 → 156 (8% reduction)

---

## Section 2: Opening Sentences and Paragraphs

### Example 3: Lead Paragraph Tightening

**Original:** "HubSpot's Prospecting Agent cuts prospect research from 15–20 minutes to under 1 minute—up to 95% time savings—while doubling response rates through AI-powered personalization."

**Word-by-word analysis:**

**Edit 1: "up to"**
- **Before:** "—up to 95% time savings—"
- **After:** "—95% faster—"
- **Reasoning:** "Up to" hedges. If the tool cuts time from 15-20 minutes to under 1 minute, that IS 95% faster. "Up to" suggests variability that contradicts the specific range given. Also, "95% faster" is more concise than "95% time savings."
- **Words saved:** 2

**Edit 2: "AI-powered"**
- **Before:** "through AI-powered personalization"
- **After:** "through AI personalization"
- **Reasoning:** "Powered" is redundant. AI personalization is inherently AI-powered. The phrase is like saying "electrically-powered electricity."
- **Words saved:** 1

**Edit 3: "while doubling" vs "and doubles"**
- **Before:** "while doubling response rates"
- **After:** "and doubles response rates"
- **Reasoning:** "While" creates a subordinate clause that weakens the claim. "And" makes both benefits equal in importance. Also, "doubling" (gerund) → "doubles" (present tense verb) is more direct and active.
- **Words saved:** 0 (same count, but stronger)

**Final edited version:** "HubSpot's Prospecting Agent cuts prospect research from 15–20 minutes to under 1 minute—95% faster—and doubles response rates through AI personalization."
- **Word count:** 26 → 23 (12% reduction)

---

### Example 4: Supporting Paragraph Compression

**Original:** "Sales teams implementing the agent save 750+ hours weekly while accelerating deal velocity by 20% (Source: HubSpot). With 56% of B2B sales professionals now using AI daily, automation has shifted from competitive edge to baseline requirement (Source: LinkedIn)."

**Word-by-word analysis:**

**Edit 1: "implementing" vs "using"**
- **Before:** "Sales teams implementing the agent"
- **After:** "Sales teams using the agent"
- **Reasoning:** "Implementing" implies the setup phase. "Using" implies ongoing operation and is simpler. Since we're talking about saving 750+ hours weekly, this is clearly ongoing use, not one-time implementation.
- **Words saved:** 0 (same count, but clearer)

**Edit 2: "while accelerating" vs "and accelerate"**
- **Before:** "save 750+ hours weekly while accelerating deal velocity"
- **After:** "save 750+ hours weekly and accelerate deal velocity"
- **Reasoning:** "While" suggests simultaneity as a secondary consideration. "And" gives equal weight to both benefits. More importantly, "accelerating" (gerund) → "accelerate" (verb) is more direct. Both changes strengthen the claim without adding words.
- **Words saved:** 0 (same count, but stronger)

**Edit 3: Remove "now"**
- **Before:** "56% of B2B sales professionals now using AI daily"
- **After:** "56% of B2B sales professionals using AI daily"
- **Reasoning:** The statistic is from a current source (LinkedIn). "Using" (present tense) already conveys current state. "Now" is redundant timing.
- **Words saved:** 1

**Final edited version:** "Sales teams using the agent save 750+ hours weekly and accelerate deal velocity by 20% (Source: HubSpot). With 56% of B2B sales professionals using AI daily, automation has shifted from competitive edge to baseline requirement (Source: LinkedIn)."
- **Word count:** 41 → 39 (5% reduction)

---

## Section 3: Transition Sentences

### Example 5: Section Transition Tightening

**Original:** "This guide explains what the agent does, how enrollment works through four distinct methods, and when it fits your RevOps architecture—including the common misconception about signal detection being required."

**Word-by-word analysis:**

**Edit 1: Remove "what"**
- **Before:** "explains what the agent does"
- **After:** "explains the agent's role"
- **Reasoning:** "What the agent does" is verbose. "The agent's role" captures the same meaning in fewer words by turning a clause into a possessive phrase.
- **Words saved:** 1

**Edit 2: Condense "how enrollment works through four distinct methods"**
- **Before:** "how enrollment works through four distinct methods"
- **After:** "enrollment methods"
- **Reasoning:** This is aggressive compression. "Four distinct methods" is valuable specificity, but "enrollment works through" is verbose setup. Middle option: "four enrollment methods" saves words while keeping the number.
- **Words saved:** 3 (aggressive) or 2 (balanced)

**Edit 3: "when it fits" vs "its fit in"**
- **Before:** "when it fits your RevOps architecture"
- **After:** "its fit in your RevOps architecture"
- **Reasoning:** "When it fits" uses 3 words. "Its fit in" uses 3 words but reads more concisely. Alternative: "fit for your RevOps" uses only 4 words total. The noun phrase "fit" is tighter than the clause "when it fits."
- **Words saved:** 0-1 depending on exact phrasing

**Edit 4: Remove "common"**
- **Before:** "the common misconception about signal detection"
- **After:** "the misconception about signal detection"
- **Reasoning:** If you're addressing a misconception in a guide, it's implied that it's common enough to merit addressing. "Common" adds judgment without adding information.
- **Words saved:** 1

**Final edited version:** "This guide explains the agent's role, enrollment methods, and its fit in your RevOps architecture—including the misconception about signal detection being required."
- **Word count:** 27 → 22 (19% reduction)

**Balanced version (keeps "four"):** "This guide explains the agent's role, four enrollment methods, and its fit in your RevOps architecture—including the misconception about signal detection being required."
- **Word count:** 27 → 23 (15% reduction)

---

## Section 4: Definition and Description Sentences

### Example 6: Product Definition Tightening

**Original:** "The Prospecting Agent is a specialized AI application built on HubSpot's Breeze AI platform. It automates three core functions: researching prospect accounts, personalizing outreach messages, and managing send workflows."

**Word-by-word analysis:**

**Edit 1: Remove "built"**
- **Before:** "is a specialized AI application built on HubSpot's Breeze AI platform"
- **After:** "is a specialized AI application on HubSpot's Breeze AI platform"
- **Reasoning:** "Built" adds no information. The application IS on the platform. Whether it was "built," "developed," or "created" on it doesn't matter to users. The relationship (on the platform) is what matters.
- **Words saved:** 1

**Final edited version:** "The Prospecting Agent is a specialized AI application on HubSpot's Breeze AI platform. It automates three core functions: researching prospect accounts, personalizing outreach messages, and managing send workflows."
- **Word count:** 32 → 31 (3% reduction)

---

### Example 7: Feature Description Compression

**Original:** "Important distinction: The Prospecting Agent is ONE application powered by Breeze AI. Breeze AI powers multiple agents, not just prospecting. Breeze AI is HubSpot's foundational AI infrastructure that also powers other agents (Customer Agent, Data Agent, etc)."

**Word-by-word analysis:**

**Edit 1: Combine related ideas**
- **Before:** "The Prospecting Agent is ONE application powered by Breeze AI. Breeze AI powers multiple agents, not just prospecting."
- **After:** "The Prospecting Agent is ONE application powered by Breeze AI, which powers multiple agents."
- **Reasoning:** Two sentences repeat "Breeze AI" and "powers." Combining with "which" eliminates repetition and connects the ideas more smoothly. The phrase "not just prospecting" is implied by "multiple agents."
- **Words saved:** 4

**Edit 2: Remove "not just prospecting"**
- **Before:** "Breeze AI powers multiple agents, not just prospecting."
- **After:** (already removed in Edit 1)
- **Reasoning:** "Multiple agents" already implies there are agents beyond prospecting. "Not just prospecting" is redundant emphasis.
- **Words saved:** 2

**Edit 3: Simplify the third sentence**
- **Before:** "Breeze AI is HubSpot's foundational AI infrastructure that also powers other agents"
- **After:** "Breeze AI is HubSpot's foundational AI infrastructure that powers other agents"
- **Reasoning:** "Also" is redundant. We just said it powers multiple agents, so of course it "also" powers other ones. Delete "also."
- **Words saved:** 1

**Final edited version:** "Important distinction: The Prospecting Agent is ONE application powered by Breeze AI, which powers multiple agents. Breeze AI is HubSpot's foundational AI infrastructure that powers other agents (Customer Agent, Data Agent, etc)."
- **Word count:** 43 → 33 (23% reduction)

---

## Section 5: Instructional Text

### Example 8: Step Description Tightening

**Original:** "Critical clarification: Signal detection is NOT a required stage. It's one optional enrollment method among four distinct pathways. Here's how it works."

**Word-by-word analysis:**

**Edit 1: Remove "distinct"**
- **Before:** "among four distinct pathways"
- **After:** "among four pathways"
- **Reasoning:** "Four pathways" already implies they are distinct (otherwise they'd be the same pathway). "Distinct" is redundant emphasis. The number 4 provides the distinctness.
- **Words saved:** 1

**Final edited version:** "Critical clarification: Signal detection is NOT a required stage. It's one optional enrollment method among four pathways. Here's how it works."
- **Word count:** 23 → 22 (4% reduction)

---

### Example 9: Use Case Description Compression

**Original:** "This is where the workflow misconception happens. You can enroll prospects into agent monitoring through ANY of these methods—they're not sequential steps, they're alternative pathways:"

**Word-by-word analysis:**

**Edit 1: Condense the clarification**
- **Before:** "they're not sequential steps, they're alternative pathways"
- **After:** "they're alternative pathways"
- **Reasoning:** "Alternative pathways" already means they're not sequential. If they were sequential, they'd be steps in a single pathway. The contrast "not X, they're Y" is redundant when Y inherently means not-X.
- **Words saved:** 3

**Final edited version:** "This is where the workflow misconception happens. You can enroll prospects into agent monitoring through ANY of these methods—they're alternative pathways:"
- **Word count:** 25 → 22 (12% reduction)

---

### Example 10: Scenario Description Tightening

**Original:** "When to use: High-value accounts where you want precise control, or when testing the agent with a small cohort before scaling."

**Word-by-word analysis:**

**Edit 1: "where you want" vs "needing"**
- **Before:** "High-value accounts where you want precise control"
- **After:** "High-value accounts needing precise control"
- **Reasoning:** "Where you want" is 3 words. "Needing" is 1 word. The meaning is the same: these accounts require careful handling. "Needing" is tighter and implies necessity rather than preference.
- **Words saved:** 2

**Edit 2: Remove "when"**
- **Before:** "or when testing the agent with a small cohort"
- **After:** "or testing the agent with a small cohort"
- **Reasoning:** The "When to use:" header already establishes we're discussing timing. The second "when" is redundant. "Or testing" continues the list smoothly without needing another time marker.
- **Words saved:** 1

**Final edited version:** "When to use: High-value accounts needing precise control, or testing the agent with a small cohort before scaling."
- **Word count:** 21 → 18 (14% reduction)

---

## Section 6: List Descriptions

### Example 11: List Item Compression

**Original:** "Create segments (HubSpot's term for dynamic lists) with criteria like industry, company size, lifecycle stage, or technology stack. Contacts automatically enroll when they meet segment criteria. Target broad ICP-fit audiences without requiring specific behavioral signals. Example: "All companies in manufacturing with 100–500 employees in DACH region."

**Word-by-word analysis:**

**Edit 1: "with criteria like" vs "based on"**
- **Before:** "Create segments (HubSpot's term for dynamic lists) with criteria like"
- **After:** "Create segments (HubSpot's term for dynamic lists) based on"
- **Reasoning:** "With criteria like" is 3 words. "Based on" is 2 words. Both convey that you're defining segments using these factors. "Based on" is more direct.
- **Words saved:** 1

**Edit 2: "requiring" vs "needing"**
- **Before:** "without requiring specific behavioral signals"
- **After:** "without needing specific behavioral signals"
- **Reasoning:** "Requiring" and "needing" are functionally identical here, but "needing" is more conversational and matches the tone better. Same syllable count but "needing" feels less formal.
- **Words saved:** 0 (style improvement)

**Edit 3: "meet segment criteria" simplification**
- **Before:** "when they meet segment criteria"
- **After:** "when they meet criteria"
- **Reasoning:** We just said "segment criteria" in the previous sentence. "Segment" is implied context. Alternatively, use "when they qualify" to tighten further.
- **Words saved:** 1

**Edit 4: Remove "companies in" from example**
- **Before:** "All companies in manufacturing with 100–500 employees"
- **After:** "All manufacturing companies with 100–500 employees"
- **Reasoning:** "Companies in manufacturing" is wordier than "manufacturing companies." The adjective form is tighter.
- **Words saved:** 1

**Edit 5: Add "companies" for clarity**
- **Before:** "All manufacturing with 100–500 employees"
- **After:** "All manufacturing companies with 100–500 employees"
- **Reasoning:** After removing "companies in," we need to keep "companies" somewhere for grammatical sense. But we've reorganized for efficiency: "manufacturing companies" is 2 words vs "companies in manufacturing" which is 3 words.
- **Net words saved:** 1 (from original)

**Final edited version:** "Create segments (HubSpot's term for dynamic lists) based on industry, company size, lifecycle stage, or technology stack. Contacts automatically enroll when they meet criteria. Target broad ICP-fit audiences without needing specific behavioral signals. Example: "All manufacturing companies with 100–500 employees in DACH region."
- **Word count:** 51 → 48 (6% reduction)

---

## Section 7: Complex Technical Descriptions

### Example 12: Multi-Sentence Concept Compression

**Original:** "The agent is part of Breeze's broader AI ecosystem, creating a unified intelligence layer across your revenue operations. For context on how this fits into HubSpot's complete AI strategy, see our guide to HubSpot AI Agents."

**Word-by-word analysis:**

**Edit 1: Remove "how this fits into"**
- **Before:** "For context on how this fits into HubSpot's complete AI strategy"
- **After:** "For context on HubSpot's AI strategy"
- **Reasoning:** "How this fits into" is transitional fluff. We're providing context on the strategy—that inherently explains how things fit. The reader understands the connection without explicit signposting.
- **Words saved:** 3

**Edit 2: Remove "complete"**
- **Before:** "HubSpot's complete AI strategy"
- **After:** "HubSpot's AI strategy"
- **Reasoning:** Is there an incomplete AI strategy? "Complete" doesn't add information. The strategy is the strategy, whether we call it complete or not.
- **Words saved:** 1

**Edit 3: Condense the link phrase**
- **Before:** "see our guide to HubSpot AI Agents"
- **After:** "see our HubSpot AI Agents guide"
- **Reasoning:** "Guide to X" can often become "X guide." This is more noun-focused and saves a word. Also creates a cleaner parallel structure with the proper noun.
- **Words saved:** 1

**Edit 4: Alternative ultra-compressed version**
- **After (compressed):** "see our HubSpot AI guide"
- **Reasoning:** If we're really aggressive, "HubSpot AI guide" assumes readers will understand this covers the agents since we've been discussing agents. But this might lose specificity.
- **Words saved:** 2 (total)

**Final edited version (balanced):** "The agent is part of Breeze's broader AI ecosystem, creating a unified intelligence layer across your revenue operations. For context on HubSpot's AI strategy, see our HubSpot AI Agents guide."
- **Word count:** 36 → 31 (14% reduction)

---

## The Pattern: Brevity Editing Process

### Step 1: Read the full sentence/paragraph
Understand the complete meaning before cutting.

### Step 2: Identify word categories
- **Filler words:** really, very, quite (DELETE)
- **Redundant modifiers:** past history, absolutely essential (DELETE modifier)
- **Verbose phrases:** "in order to," "due to the fact that" (REPLACE)
- **Weak verbs:** "make a decision," "conduct an analysis" (STRENGTHEN)
- **Unnecessary prepositions:** "companies in manufacturing" (REORGANIZE)

### Step 3: Test each cut
Remove the word. Does the sentence still mean the same thing? If yes, delete. If no, keep.

### Step 4: Reorganize for efficiency
Sometimes you can't just delete—you need to rephrase. "Companies in manufacturing" → "manufacturing companies" saves a word through reorganization, not deletion.

### Step 5: Verify clarity
Read the edited version aloud. Is it clear? Natural? If it sounds choppy or confusing, you've cut too much.

---

## Brevity Targets by Content Type

### Blog Posts
- **Target reduction:** 20-30%
- **Priority cuts:** Filler words, throat-clearing, redundancies
- **Preserve:** Voice, personality, rhythm

### Business Emails
- **Target reduction:** 30-40%
- **Priority cuts:** Preambles, hedging, excessive politeness
- **Preserve:** Professionalism, clarity, action items

### Marketing Copy
- **Target reduction:** 30-50%
- **Priority cuts:** Clichés, vague claims, features without benefits
- **Preserve:** Persuasiveness, specificity, calls to action

### Technical Documentation
- **Target reduction:** 20-30%
- **Priority cuts:** Passive voice, wordy phrases, over-explanation
- **Preserve:** Precision, accuracy, necessary detail

### Social Media
- **Target reduction:** 40-60%
- **Priority cuts:** Everything unnecessary, multiple ideas
- **Preserve:** Core message, hook, call to action

---

## Common Brevity Mistakes to Avoid

### Mistake 1: Cutting too much
**Bad:** "The agent researches prospects and sends emails."
**Problem:** Lost all the compelling specificity about 95% time savings, AI personalization, etc.
**Fix:** "The agent cuts research time 95% and personalizes emails using AI."

### Mistake 2: Making it too formal
**Before:** "We'll touch base next week to circle back on this."
**Bad edit:** "We will convene subsequently to revisit this matter."
**Good edit:** "We'll discuss this next week."
**Problem:** The bad edit is shorter but stuffier. Brevity should increase clarity, not formality.

### Mistake 3: Losing necessary context
**Before:** "Sales teams implementing the agent save 750+ hours weekly (Source: HubSpot)."
**Bad edit:** "Sales teams save time (Source: HubSpot)."
**Good edit:** "Sales teams save 750+ hours weekly (Source: HubSpot)."
**Problem:** "Save time" is vague. The specific number is valuable. Don't cut the evidence.

### Mistake 4: Breaking parallel structure
**Before:** "The agent researches accounts, personalizes messages, and manages workflows."
**Bad edit:** "The agent researches accounts, message personalization, and manages workflows."
**Problem:** Mixing verb forms (researches, personalization, manages) breaks parallel structure.
**Good edit:** "The agent researches accounts, personalizes messages, and manages workflows." (keep original)

---

## Practice: Edit These Examples

### Exercise 1
**Original:** "It is important to note that in order to successfully implement this feature, you will need to ensure that all of the necessary prerequisites are properly configured."

**Your edit:** _______________

**Model answer:** "To implement this feature, configure all prerequisites."
- **Words:** 26 → 7 (73% reduction)
- **Changes:** Removed throat-clearing ("It is important to note that"), simplified "in order to" → "to", removed "successfully" (redundant with "implement"), removed "you will need to ensure" (implied by the instruction), removed "properly" (redundant with "configure"), removed "necessary" (redundant with "prerequisites")

### Exercise 2
**Original:** "Our platform provides the ability to seamlessly integrate with multiple different systems, which enables teams to work much more efficiently."

**Your edit:** _______________

**Model answer:** "Our platform integrates with multiple systems, enabling teams to work 40% faster."
- **Words:** 22 → 13 (41% reduction)
- **Changes:** "Provides the ability to" → (delete), "seamlessly integrate" → "integrates", "multiple different" → "multiple" (different is redundant), "which enables" → "enabling" (more concise), "much more efficiently" → "40% faster" (specific metric instead of vague claim)

### Exercise 3
**Original:** "At this point in time, we are currently in the process of conducting a comprehensive review of all the various systems and tools that are being used by the team."

**Your edit:** _______________

**Model answer:** "We're reviewing all team systems and tools."
- **Words:** 32 → 7 (78% reduction)
- **Changes:** "At this point in time" → (delete), "currently in the process of" → (delete, present progressive tense handles this), "conducting a comprehensive review" → "reviewing", "all the various" → "all", "systems and tools that are being used by" → "team systems and tools"

---

## The Ultimate Brevity Test

Before you finish editing, ask yourself:

1. **Can I delete this word without changing meaning?** → Delete it
2. **Can I say this in fewer words?** → Rewrite it
3. **Is this word specific and necessary?** → Keep it
4. **Would I say this out loud?** → If no, simplify it
5. **Is this word doing work?** → If no, delete it

Remember: **Brevity is not about being short. It's about being clear without wasting words.**

Every word you make the reader read should give them information, clarity, or emotional impact. If it doesn't do one of those three things, delete it.

---

**Final principle:** The best writing uses the fewest words to convey the most meaning with the greatest clarity.
