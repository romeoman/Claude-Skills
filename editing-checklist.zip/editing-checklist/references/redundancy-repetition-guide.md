# Redundancy & Repetition Without Amplification: The Complete Guide

## Core Principle: Don't Tell Twice—Amplify Once

Every sentence should move your argument forward. Repetition that doesn't add new information wastes the reader's trust and attention.

**Research Foundation:** Studies show that redundant content decreases reader engagement by 40% and creates the perception that the writer lacks substance. When readers encounter the same information restated without amplification, they disengage.

---

## What Is Redundancy?

**Primary Definition:** Redundancy is writing the same idea twice without adding new value, depth, or perspective.

**The Key Test:** If you can delete a sentence or paragraph without losing information, it's redundant.

---

## The Technical Terms: Understanding 6 Types of Repetition Sin

### 1. Redundancy (The Primary Term)
**Definition:** Restating the same idea without adding new value.

**Example:**
❌ "The agent saves 750 hours weekly. This time savings of 750 hours per week is significant."
✅ "The agent saves 750 hours weekly—equivalent to 3-4 full-time employees' work capability."

**Why the first is redundant:** You've told readers about 750 hours. Restating "750 hours per week" adds zero new information. The improved version amplifies by showing what that time means in terms readers understand (FTE capacity).

---

### 2. Circular Reasoning / Circular Argument
**Definition:** Proving a point by restating it rather than supporting it with new evidence.

**Example:**
❌ "Manual monitoring at this scale would take significant time because manually monitoring 200 accounts requires a lot of time investment."

✅ "Manual monitoring at this scale would take 40–50 hours weekly per SDR—unfeasible for most teams."

**Why circular:** The premise (takes significant time) is the same as the conclusion (requires time investment). No new proof offered.

**Why better:** The improved version adds specific evidence (40-50 hours per SDR) and context (unfeasible for teams).

---

### 3. Repetition Without Amplification
**Definition:** Repeating the core insight without amplifying it with new data, context, or perspective.

**The Amplification Test:** Ask yourself:
- Does this restatement add new evidence?
- Does it provide new context?
- Does it show a new perspective?
- Does it quantify the benefit differently?

If NO to all → Delete

**Example:**
❌ **Intro:** "The agent saves 95% of research time."
**Feature section:** "Research time drops from 15-20 minutes to under 1 minute—95% faster."

**Why redundant:** Same math, same claim. Second appearance adds nothing new.

✅ **Better approach:**
**Intro:** "The agent saves 95% of research time."
**Feature section:** "Research time drops from 15-20 minutes to under 1 minute. For a 10-person sales team researching 50 prospects weekly, this saves 125-167 hours—equivalent to 3-4 FTEs."

**Why better:** Adds new information—scales the benefit to show team-level impact and FTE equivalency.

---

### 4. Echoing
**Definition:** A softer term for when a paragraph "echoes" what was already said without earning its place on the page.

**Example:**
❌ **Opening:** "Sales teams save 750+ hours weekly."
**Later paragraph:** "The time savings of 750 hours per week allows sales teams to focus on higher-value activities."

**Why it's echoing:** You've already told readers about 750 hours. The second mention doesn't add evidence or amplify the claim—it just rephrases what focusing on higher-value activities means (which readers already inferred).

✅ **Better approach—amplify with specifics:**
**Opening:** "Sales teams save 750+ hours weekly."
**Later paragraph:** "With 750 hours freed weekly, teams can conduct 40% more discovery calls, leading to a 23% increase in qualified pipeline."

**Why better:** Adds new proof (40% more calls, 23% pipeline increase) showing what "higher-value activities" actually produces.

---

### 5. Telling Twice (Copywriting/Screenwriting Term)
**Definition:** The phrase "don't tell me twice" applies when you tell the reader information in one section, then tell them again in the same or nearby section without moving forward.

**The Trust Violation:** When you repeat without amplifying, you violate the reader's trust that each new paragraph will advance their understanding.

**Example:**
❌ **Section A:** "The agent monitors 200+ accounts."
**Section B (same article):** "With the ability to track over 200 accounts simultaneously, the agent provides comprehensive coverage."

**Why it's telling twice:** Same capability (200+ accounts), same vague benefit (coverage). No new information.

✅ **Better approach:**
**Section A:** "The agent monitors over 200 accounts."
**Section B:** "Monitoring 200 accounts manually would require 40-50 hours weekly per SDR. The agent handles this continuously without fatigue, at a fraction of the cost."

**Why better:** Section B amplifies by showing the manual alternative, quantifying the time, and adding cost context.

---

### 6. Semantic Repetition / Repetitive Anchor Numbers (Technical Writing Term)
**Definition:** The unnecessary reuse of the same specific data point, statistic, or quantitative anchor across a document without adding new value or context.

**Related Issues:**
- **Lazy stat deployment:** Using the same number to prop up multiple claims instead of varying your evidence
- **Numeral clustering:** When quantitative anchors (percentages, counts, metrics) repeat too closely, creating visual and cognitive noise
- **Evidence fatigue:** Leaning on the same data point to support multiple arguments suggests shallow research or weak argumentation
- **Anchor drift:** A statistic appearing so often it becomes assumed "truth" rather than supporting evidence—readers sense manipulation

**Why it's problematic:**
When readers encounter the same number repeatedly, they:
1. Stop trusting the specificity (feels like padding)
2. Sense shallow research (only one stat available)
3. Question the argumentation (same number carrying multiple claims)
4. Experience evidence fatigue (statistic loses impact through overuse)

**Example:**
❌ **Opening:** "The agent monitors 200+ accounts."
**Feature Section:** "With 200+ accounts monitored simultaneously, you get comprehensive coverage."
**Benefits Section:** "Tracking 200+ accounts ensures no opportunity is missed."
**Use Case:** "For teams managing 200+ target accounts, the agent provides..."

**Why it's semantic repetition:** The "200+ accounts" anchor appears 4 times without adding new information. By the third mention, readers stop caring about the number—it feels like filler.

✅ **Better approach—deploy the anchor once with full context:**
**Monitoring Capacity Section:** "The agent monitors over 200 target accounts simultaneously—tracking website visits, job changes, and funding announcements. Manual monitoring at this scale is unfeasible without dedicated SDRs."

**Other sections use conceptual language:**
- "Enterprise-scale monitoring"
- "Continuous account tracking"
- "At pace manual teams can't sustain"
- "Across your entire target account list"

**Why better:** You deploy the quantitative anchor once where it matters most, then use descriptive language that references the capability without repeating the number.

**Audit Framework:**
When reviewing content, ask:
- [ ] Do I use the same metric/number more than twice in the document?
- [ ] If yes, is each use essential—or can I cut, vary, or consolidate?
- [ ] Can I support the claim with different evidence instead?
- [ ] Have I "anchored" this number in one place with full context, then referenced conceptually elsewhere?

**Rule:** Deploy your strongest quantitative anchors once with full context. Everywhere else, use conceptual language or vary your evidence. Each statistic should carry ONE major claim, not multiple.

---

## The Amplification Framework: How to Repeat WITHOUT Being Redundant

When you need to mention a concept again, use one of these amplification strategies:

### Strategy 1: Add New Evidence
**Pattern:** Claim → Specific data or case study

❌ Redundant: "The agent saves time. This time savings is significant."
✅ Amplified: "The agent saves time. Customer X reduced research hours by 750 weekly after implementation."

---

### Strategy 2: Change the Scale or Unit
**Pattern:** Individual benefit → Team benefit → Company benefit

❌ Redundant: "Research drops from 20 minutes to 1 minute per prospect."
✅ Amplified: "Research drops from 20 minutes to 1 minute per prospect. For 50 prospects weekly, that's 15.8 hours saved per rep—or 158 hours across a 10-person team."

---

### Strategy 3: Show the Alternative or Comparison
**Pattern:** Your solution → Manual alternative cost

❌ Redundant: "The agent monitors 200 accounts constantly."
✅ Amplified: "The agent monitors 200 accounts constantly. Manual monitoring at this scale would require 40-50 hours weekly per SDR—unfeasible for most teams."

---

### Strategy 4: Add Contextual Depth
**Pattern:** What it does → Why it matters in specific contexts

❌ Redundant: "The agent personalizes emails, which improves response rates."
✅ Amplified: "The agent personalizes emails. For enterprise deals with 6-8 stakeholders, personalized outreach increases response rates 34% and accelerates deal cycles by 18 days."

---

### Strategy 5: Show the "So What" (Second-Order Effects)
**Pattern:** Primary benefit → Downstream impact

❌ Redundant: "Teams save 750 hours weekly, freeing up significant time."
✅ Amplified: "Teams save 750 hours weekly. This freed capacity enables 40% more discovery calls, increasing qualified pipeline by 23%."

---

### Strategy 6: Connect to Different Audience Needs
**Pattern:** General benefit → Specific persona application

❌ Redundant: "The agent saves research time for everyone."
✅ Amplified: "The agent saves research time. For SDRs, this means hitting quota faster. For AEs, it means spending more time on deal strategy instead of data gathering."

---

## The 6 Deadly Redundancy Patterns to Eliminate

### Pattern 1: Restate-the-Math Redundancy

❌ **Example:**
"The agent cuts research from 20 minutes to 1 minute—95% faster. This 95% time reduction is significant."

**Problem:** You calculated 95% once. Restating "95% reduction" adds nothing.

✅ **Fix:** Use second mention to amplify with context
"The agent cuts research from 20 minutes to 1 minute—95% faster. At this pace, a single rep can research 240 prospects per week vs. 12 manually."

---

### Pattern 2: Benefit-Restatement Redundancy

❌ **Example:**
"The agent frees reps from manual work so they can focus on selling. This allows sales teams to spend more time on revenue-generating activities."

**Problem:** "Focus on selling" = "revenue-generating activities." Same idea, different words.

✅ **Fix:** First mention = benefit, second = quantified outcome
"The agent frees reps from manual work so they can focus on selling. Teams report 30% more time spent in discovery calls and demos."

---

### Pattern 3: Capability-Echo Redundancy

❌ **Example:**
**Intro:** "The agent monitors 200+ accounts."
**Features:** "With its ability to track over 200 target accounts, the agent provides comprehensive coverage."

**Problem:** Same capability (200 accounts), vague outcome (coverage).

✅ **Fix:** Second mention shows WHY capacity matters
**Intro:** "The agent monitors over 200 accounts."
**Features:** "At 200 accounts, manual monitoring would require dedicated SDRs working 40+ hours weekly on research alone. The agent eliminates this cost."

---

### Pattern 4: Conclusion-Premise Circle

❌ **Example:**
"This feature is important because it provides value. The value it provides makes it important for users."

**Problem:** Circular reasoning—conclusion restates premise. No actual proof.

✅ **Fix:** Replace premise with evidence
"This feature increases conversion by 28%. Customer data shows users who enable it close deals 18 days faster on average."

---

### Pattern 5: Intro-Conclusion Redundancy

❌ **Example:**
**Intro:** "The agent saves significant research time."
**Conclusion:** "In conclusion, the agent's time-saving capabilities are significant."

**Problem:** Conclusion adds no new synthesis or insight—just echoes the intro.

✅ **Fix:** Conclusion synthesizes or shows next step
**Intro:** "The agent saves significant research time."
**Conclusion:** "With 750 hours saved weekly, teams can shift from reactive outreach to strategic account planning—the competitive advantage modern sales requires."

---

### Pattern 6: Semantic Repetition / Anchor Number Overuse

❌ **Example:**
**Opening:** "The agent monitors 200+ accounts."
**Feature Section:** "With 200+ accounts monitored simultaneously, you get comprehensive coverage."
**Benefits Section:** "Tracking 200+ accounts ensures no opportunity is missed."
**Use Case Example:** "For teams managing 200+ target accounts, the agent provides continuous monitoring."

**Problem:** The "200+ accounts" statistic appears 4 times without adding new information. By the third mention, the number loses impact and feels like padding. Readers sense:
- Shallow research (only one stat available)
- Weak argumentation (same number carrying multiple claims)
- Evidence fatigue (statistic overused)

✅ **Fix:** Deploy quantitative anchor ONCE with full context, then use conceptual language

**Monitoring Capacity Section (anchor deployment):**
"The agent monitors over 200 target accounts simultaneously—tracking website visits, job changes, and funding announcements. Manual monitoring at this scale is unfeasible without dedicated SDRs."

**Other sections use conceptual references:**
- Opening: "Enterprise-scale account monitoring"
- Feature Section: "Continuous tracking at pace manual teams can't sustain"
- Benefits Section: "Across your entire target account list, no opportunity is missed"
- Use Case: "For teams managing large account portfolios, the agent provides..."

**Why better:** You establish the quantitative anchor once where it matters most (with context showing why 200 matters), then reference the capability conceptually elsewhere. Each mention adds value instead of repeating the same number.

**Detection:** Search your document for repeated numbers (200, 95%, 750, etc.). If the same statistic appears 3+ times, consolidate to ONE authoritative mention with full context, then vary language elsewhere.

---

## When Repetition IS Acceptable: The 3 Exceptions

### Exception 1: Structural Repetition (Thesis-Body-Conclusion)

In long-form content, repeating your thesis in the intro, elaborating in the body, and restating in the conclusion is structural—not redundant.

**Why acceptable:** Each mention serves a different rhetorical function:
- **Intro:** Frames the problem and solution
- **Body:** Proves with evidence
- **Conclusion:** Synthesizes implications

**Key difference:** Each restatement adds new context or implication.

---

### Exception 2: Emphasis Through Intentional Repetition (Rhetorical Device)

Repeating for rhetorical effect—like Martin Luther King's "I have a dream"—is powerful when deliberate.

**When it works:**
- Creates rhythm
- Builds emotional resonance
- Signals importance through structure

**When it fails:**
- In analytical/technical writing (comes across as melodramatic)
- When the repeated phrase doesn't carry weight

---

### Exception 3: Cross-Reference to Earlier Content (With New Application)

Referring back to earlier points is fine when you're building on them.

✅ **Example:**
**Section 1:** "The agent saves 750 hours weekly."
**Section 5:** "As noted earlier, 750 hours saved weekly enables teams to double discovery call volume. When combined with AI personalization, this produces 34% higher conversion rates."

**Why acceptable:** You're not restating—you're connecting previous info to a new insight (discovery volume + personalization = conversion lift).

---

## The Redundancy Audit: Questions to Ask Every Paragraph

Before publishing, audit each paragraph with these questions:

### 1. Information Test
- [ ] Does this paragraph tell me something I didn't know from previous paragraphs?
- [ ] If I delete this, do I lose information?

**If NO to both → Delete or amplify**

---

### 2. Amplification Test
- [ ] Does this paragraph add new evidence to a previous claim?
- [ ] Does it show a new angle, scale, or context?
- [ ] Does it reveal second-order effects?

**If NO to all → You're echoing, not amplifying**

---

### 3. Proof Test
- [ ] Am I proving a claim or just restating it?
- [ ] Have I offered data, examples, or logic?
- [ ] Could a skeptical reader say "You just told me the same thing twice"?

**If you're restating → Add evidence or delete**

---

### 4. Math Test
- [ ] Have I already done this calculation earlier?
- [ ] Am I just converting units without adding insight?

**If redundant math → Use second mention to show implications**

---

### 5. "So What" Test
- [ ] Does this paragraph answer a new "So what?" question?
- [ ] Or does it just reword an earlier "So what?"

**If same "So what" → Delete**

---

### 6. Semantic Repetition Test (Anchor Numbers)
- [ ] Do I use the same statistic/number more than twice in the document?
- [ ] If yes, is each use essential—or can I consolidate?
- [ ] Have I deployed this anchor with full context in ONE place?
- [ ] Can other mentions use conceptual language instead?

**If repeated 3+ times → Deploy once with context, vary elsewhere**

---

## Real-World Example: Redundancy Analysis

### ❌ Redundant Version:

**Intro:**
"The agent cuts prospect research from 15-20 minutes to under 1 minute—95% time savings."

**Feature Section:**
"Research time drops from 15-20 minutes to 1 minute per prospect—95% faster. This time savings is significant for sales teams."

**Practical Impact Section:**
"The 95% reduction in research time allows reps to focus on higher-value activities instead of manual data gathering."

### Problems Identified:

1. **Math repetition:** "95%" appears 3 times without new context
2. **Capability echo:** "15-20 min → 1 min" stated twice
3. **Vague benefits:** "Significant" and "higher-value activities" add no specifics
4. **Circular reasoning:** "Time savings is significant" proves nothing—just restates the claim

---

### ✅ Amplified Version:

**Intro:**
"The agent cuts prospect research from 15-20 minutes to under 1 minute—95% time savings."

**Feature Section:**
"Research time drops from 15-20 minutes to 1 minute per prospect. For a rep researching 50 prospects weekly, this saves 15.8 hours—nearly two full workdays."

**Practical Impact Section:**
"With 15.8 hours freed per rep weekly, teams can conduct 40% more discovery calls. Customer data shows this leads to 23% more qualified pipeline and 20% faster deal velocity."

### What Changed:

1. **New scale:** Individual time → weekly time → workday equivalency
2. **New evidence:** 40% more calls, 23% pipeline, 20% velocity (all new data)
3. **Amplification chain:** Time saved → capacity increase → pipeline impact → deal speed
4. **Each paragraph earns its place:** Intro (benefit), Features (scale), Impact (outcomes)

---

## Summary: The Redundancy Elimination Rules

### Rule 1: Information Requirement
Every paragraph must tell readers something they don't already know.

### Rule 2: Amplification Requirement
If you mention a concept twice, the second mention must amplify with:
- New evidence
- Different scale/unit
- Alternative comparison
- Contextual depth
- Second-order effects
- Different audience application

### Rule 3: Proof Requirement
Don't restate claims—prove them with data, examples, or logic.

### Rule 4: Math Once Rule
Calculate metrics once. Second mentions show implications, not recalculations.

### Rule 5: Trust Preservation Rule
Readers trust you to move forward. Repeating without amplifying breaks that trust.

### Rule 6: Anchor Number Deployment Rule
Deploy quantitative anchors (statistics, metrics, numbers) ONCE with full context. Elsewhere, use conceptual language or vary evidence. Each statistic carries ONE major claim, not multiple.

---

## Quick Reference: Before You Publish

Ask yourself for every section:

1. **Did I tell them this already?** → If yes, what NEW thing am I adding?
2. **Am I restating or amplifying?** → Amplification adds evidence/context/scale
3. **Would a skeptical reader say "You just repeated yourself"?** → If yes, delete or amplify
4. **Can I delete this without losing information?** → If yes, delete
5. **Does this move the argument forward?** → If no, it's redundant
6. **Do I repeat the same statistic/number 3+ times?** → Deploy once with context, vary elsewhere

**Remember:** Repetition that doesn't amplify wastes the reader's trust. Every sentence should earn its place by advancing understanding—not by echoing what came before. Numbers lose impact through overuse—deploy your strongest anchors strategically.
