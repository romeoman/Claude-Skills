# Writing Guidelines

## Core Writing Principle

### **We don't write about HubSpot features—we write about how RevOps supports GTM leaders using HubSpot as the enabler.**

**Every article must answer:**
1. What is the big GTM or business problem?
2. How does this solve a business/GTM problem?
3. What impact does this create?
4. What's the transformation story?

Rule of Thumb:
❌ Bad = feature-focused, tutorial
✅ Good = outcome-focused, transformation

**Content Principles**
- Always lead with **business outcome**, not technical feature
- Use **HubSpot screenshots, workflows, and templates** (make it tangible)
- Provide **downloadable frameworks** where possible

## Critical Opening Structure

### THE HOOK SENTENCE (Mandatory)

**Every article must start with ONE sentence that:**
- Naturally embeds the target keyword
- States the transformation or key value
- Is complete and standalone
- Sets executive tone immediately

**Perfect examples:**

✅ "The revenue operations (RevOps) framework helps your company be more efficient by aligning processes, people, technology, and data."
- Keyword: ✓ (revenue operations framework)
- Complete thought: ✓
- Value clear: ✓  
- No preamble: ✓

✅ "HubSpot launches 22 built-in agents that automate marketing, sales, and service workflows."
- Keyword: ✓ (HubSpot AI agents)
- Immediate news: ✓
- Clear benefit: ✓
- Direct: ✓

### Second Sentence: Amplify with Specificity

Add context using:
- Research/statistics with citations
- Trend data
- Specific numbers

**Format for citations:** ([_Source Name_](URL))

**Example:**
"This joins the 66% of marketers ([_HubSpot AI Trends for Marketers_](https://offers.hubspot.com/ai-marketing)) using AI to scale operations while concentrating on strategic revenue growth."

**Elements:**
- Statistic: ✓ (66%)
- Citation: ✓ (linked source)
- Context: ✓ (trend validation)
- Italics emphasis: ✓

### NO TL;DR Sections

**Do NOT include:**
- TL;DR bullets at the beginning
- Summary sections before content
- Table of Contents (unless article >3000 words)

**Why:** Executive readers want to dive in. The hook sentence does the summary work.

## Article Framework

| Section | Purpose | Example from RevOps Framework Post |
|---------|---------|-------------------------------------|
| **Opening Hook** | Keyword + value | "The revenue operations (RevOps) framework helps your company be more efficient by aligning processes, people, technology, and data." |
| **Context Block** | Explain the 'what' | "It consists of four elements: Process, People, Technology, Data" |
| **Why It Matters** | Business impact | "Connected processes... accurate data... informed forecasts" |
| **Solution/How** | Implementation | "Here's how it looks in HubSpot..." |
| **Deep Dive** | Detailed steps | Phase 1, Phase 2, Phase 3 breakdown |
| **Impact/Benefits** | Tangible outcomes | "Predictable revenue growth through unified data" |
| **Case Study** | Social proof | Real metrics and results |
| **Next Steps** | Call to action | "Assess your current state... Build 90-day plan" |
| **Conclusion** | Key takeaways | "The throughline is simple: unify teams..." |

## Word Count Guidelines

**Target: 1,200-1,600 words**
- Minimum: 1,000 words
- Sweet spot: 1,200-1,400 words
- Maximum: 2,500 words
- Only exceed 2,000 for comprehensive guides

**Why this range:**
- Executives want depth without bloat
- SEO requires substance (1,000+ words)
- Respect reader's time (don't inflate)
- Quality over quantity

## Writing Style Guide

### 1. Tone & Style
- **Executive level, no bullshit** — Direct and to the point
- **Clear and concise** — Short sentences, no fluff
- **Neutral-positive** — State facts with solutions
- **Conversational, not corporate** — Plain words over jargon
- **Professional with approachability** — Confident without overhyping

### 2. Structure & Flow
- **Lead with the point** — Main idea first, always
- **Use prose primarily** — Bullets only for lists/checklists
- **Logical sequence** — Context → Goal → Actions → Outcomes

### 3. Clarity & Readability
- **One idea per sentence** — No layering
- **Specific over vague** — "Reduce lead response from 4 hours to 15 minutes" not "improve efficiency"
- **Plain language** — Everyday words
- **Short paragraphs** — 2-3 sentences maximum

### 4. Formatting Principles

**Use italics for:**
- Key term emphasis: _revenue operations_, _go-to-market_
- Parenthetical clarifications: (_Customer Satisfaction Score_)
- First mention of concepts

**Use bold sparingly for:**
- Subheadings within sections
- Key takeaways that must stand out
- List items (when using bullets)

**Never:**
- Bold entire sentences
- Bold multiple consecutive words (unless proper heading)
- Use excessive exclamation marks
- Over-format with too much bold

### 5. Citations and Links

**Always use this format:** ([_Source Name_](URL))

**Examples:**
- "According to research ([_HubSpot AI Trends 2024_](https://example.com))"
- "Studies show ([_Gartner RevOps Report_](https://example.com))"

**Requirements:**
- Source name in italics
- Clickable link
- Credible sources only
- Verify links work

### 6. Prose vs. Bullets

**Use prose when:**
- Explaining concepts
- Describing processes
- Building arguments
- Telling stories

**Example (prose):**
"The framework consists of four elements. Process defines how revenue is generated across teams. People run those processes with clear roles. Technology provides the tools. Data enables forecasting and insights."

**Use bullets when:**
- Listing discrete items
- Checklists
- Quick reference points
- Features or benefits

**Example (bullets):**
How to prioritize:
- Start with Customer Agent for ticket queues
- Use Prospecting Agent for SDR research
- Deploy Data Agent for property hygiene

## Content to Avoid

- Feature-focused writing: "How to use HubSpot workflows"
- Fluff phrases: "unlock potential," "leverage synergies," "game-changer," "dive in"
- Excessive exclamation marks
- Vague adjectives: "engaged customers" → "customers who logged in 3+ times last week"
- Corporate jargon
- TL;DR sections
- Over-formatted text (too much bold)
- Missing citations for claims
- Vague outcomes without numbers

## Visual Content Requirements

### Graphics and Diagrams
- Process flows: Show step-by-step
- Architecture diagrams: System connections
- Before/after comparisons: Transformation
- ROI visualizations: Make impact tangible

### Screenshots
- Annotated: Highlight key areas
- Sequential: Step-by-step process
- Current: Latest HubSpot UI
- Marked with: [Screenshot: description]

## Writing Patterns

### Strong Opening Pattern
```
[Hook sentence with keyword]

[Amplifying context with citation/statistic]

[Brief problem or context setup - 2-3 sentences]
```

### What-Why-How Pattern
```
What: [The thing/concept/approach]

Why it matters: [Business impact]

How to implement: [Specific approach]
```

### Claim-Support-Takeaway Pattern
```
[Bold claim]

[Evidence: data, research, example]

[Practical takeaway for reader]
```

## Quality Checklist

- [ ] Opens with ONE strong hook sentence
- [ ] NO TL;DR section
- [ ] Word count: 1,200-1,600
- [ ] Paragraphs are short (2-3 sentences)
- [ ] No fluff phrases
- [ ] Every sentence adds value
- [ ] Specific numbers used ("3+ times" not "engaged")
- [ ] No vague adjectives without specifics
- [ ] Proper citations with links
- [ ] Strategic italics (not excessive bold)
- [ ] Bullets used only for lists/checklists
- [ ] Prose used for explanations
- [ ] Real examples and screenshots marked
- [ ] Closing ties to business ROI

## Examples from Real Posts

### Perfect Opening (RevOps Framework)
"The revenue operations (RevOps) framework helps your company be more efficient by aligning processes, people, technology, and data."

**Why it works:**
- Keyword embedded naturally
- Complete value proposition
- One sentence
- No preamble

### Perfect Second Sentence (AI Agents)
"This joins the 66% of marketers ([_HubSpot AI Trends for Marketers_](https://offers.hubspot.com/ai-marketing)) using AI to scale operations while concentrating on strategic revenue growth."

**Why it works:**
- Specific statistic (66%)
- Proper citation format
- Validates the trend
- Builds credibility

### Perfect Context Block (RevOps Framework)
"It consists of four elements:
- Process (revenue generation)
- People running _those processes_
- Technology (_tools used in your processes_)
- Data (_data you gather in your business_)"

**Why it works:**
- Clear structure
- Concise explanations
- Strategic italics
- No fluff

## Common Mistakes

1. **No hook sentence** - Starting with question or long setup
2. **Including TL;DR** - Outdated structure
3. **Too long** - Exceeding 1,600 words without justification
4. **All bullets** - Using bullets for everything instead of prose
5. **Missing citations** - Claims without linked sources
6. **Over-bolding** - Bold everywhere instead of strategic italics
7. **Vague metrics** - "Improve efficiency" instead of "Reduce from 4 hours to 15 minutes"
8. **Feature focus** - Writing about HubSpot features instead of business outcomes

