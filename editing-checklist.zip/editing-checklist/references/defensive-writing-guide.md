# Defensive Writing & Content Deletion Guide

## Core Principle: Confidence Over Uncertainty

Defensive writing signals insecurity and undermines your authority. It plants doubt in readers' minds before they even evaluate your claims. Strong writing states facts directly, backs them with evidence, and trusts readers to evaluate the information.

**Research Foundation:** Studies show that processing fluency—how easily readers can understand content—is directly linked to judgments of truth, confidence, and credibility. Complex, defensive language decreases perceived credibility by 17% and lowers conversion rates by 23%.

---

## Part 1: Identifying Defensive Writing

### 1.1: Defensive Parentheticals and Clarifications

**What they are:** Phrases in parentheses or set off by dashes that preemptively defend against criticism no one has made yet.

**Why they're defensive:** They suggest you're anticipating objections, which makes readers skeptical.

**Examples:**

❌ "Critical clarification: Signal detection is an optional enrollment method among four pathways."
✅ "Signal detection is one of four enrollment methods."
**Why:** The phrase "Critical clarification" plants the idea that readers might be confused. Just state the fact.

❌ "Important distinction: The Prospecting Agent is ONE application powered by Breeze AI."
✅ "The Prospecting Agent is one application within Breeze AI."
**Why:** "Important distinction" is defensive. If it's important, the content will show that.

❌ "It's a powerful but optional combination."
✅ Delete entirely or: "These signals work together when both are present."
**Why:** "Powerful but optional" hedges in both directions. Either recommend it or don't.

**Pattern to watch for:**
- "Critical clarification:"
- "Important distinction:"
- "Important note:"
- "(NOT part of)"
- "However, note that..."
- "It should be noted that..."

**Fix:** Delete the defensive preamble. State the fact directly.

---

### 1.2: Reassurance Statements (Handholding)

**What they are:** Statements that reassure readers about things they weren't worried about.

**Why they're defensive:** Creating problems to solve them makes readers question whether the original claim was true.

**Examples:**

❌ "The agent functions without these, but they enhance capabilities."
✅ Delete entirely or fold into the main claim.
**Why:** If something functions fine, why mention what it doesn't need? This creates doubt.

❌ "This is powerful but optional."
✅ "This increases conversion by 40% for accounts showing buying signals."
**Why:** State what it does, not whether readers must use it. They'll decide that.

❌ "Don't worry—this won't affect your existing setup."
✅ "Your existing setup remains unchanged."
**Why:** "Don't worry" plants worry. State facts without emotional framing.

**Pattern to watch for:**
- "Don't worry..."
- "You don't need to..."
- "This won't affect..."
- "Optional but powerful..."
- "Not required but recommended..."

**Fix:** Either delete or state the fact without the reassurance frame.

---

### 1.3: Preemptive Apologizing

**What they are:** Phrases that apologize for complexity or length before readers encounter it.

**Why they're defensive:** If content is too complex or long, fix it. Don't warn readers about poor writing.

**Examples:**

❌ "This might sound complicated, but..."
✅ Just explain it clearly.
**Why:** If it sounds complicated, simplify it. Don't warn readers.

❌ "I know this is a lot, but bear with me..."
✅ Delete and break content into digestible sections.
**Why:** Fix the structure instead of apologizing for it.

❌ "Without getting too technical..."
✅ Just explain at the right level.
**Why:** If readers need technical details, provide them. If not, don't.

**Pattern to watch for:**
- "This might sound..."
- "I know this is..."
- "Without getting too..."
- "To put it simply..."
- "In other words..." (after clear explanation)

**Fix:** Delete the apology. Make the content clear instead.

---

### 1.4: Uncertainty Phrases That Undermine Claims

**What they are:** Qualifiers that weaken statements without adding accuracy.

**Why they're defensive:** They signal you're not confident in your own claims.

**Examples:**

❌ "With 56% of B2B sales professionals using AI daily, automation has shifted from competitive advantage to baseline requirement."
✅ Delete entirely—doesn't support your specific claim.
**Why:** This is defensive padding. It's a vague market stat that doesn't prove your product matters.

❌ "You might want to consider implementing this approach."
✅ "Implement this approach to reduce processing time by 40%."
**Why:** "Might want to consider" is triple hedging. State the recommendation.

❌ "This could potentially help improve results in some cases."
✅ "This reduces processing time by 30%." (with citation)
**Why:** "Could potentially" + "improve" + "in some cases" = zero confidence.

**Pattern to watch for:**
- "could potentially"
- "might possibly"
- "seems like"
- "appears to be"
- "sort of"
- "kind of"
- "in some cases"

**Fix:** Either back the claim with data or delete it.

---

### 1.5: False Authority Markers

**What they are:** Phrases that try to sound authoritative but actually signal uncertainty.

**Why they're defensive:** Real authority doesn't announce itself—it demonstrates through evidence.

**Examples:**

❌ "As you can see..."
✅ Delete—if readers can see it, you don't need to tell them.
**Why:** This is handholding that assumes readers aren't paying attention.

❌ "It's clear that..."
✅ Delete—if it's clear, the content will show that.
**Why:** Announcing clarity suggests it might not be clear.

❌ "Obviously..."
✅ Delete—if something is obvious, stating it is redundant.
**Why:** "Obviously" often precedes non-obvious claims, signaling defensiveness.

**Pattern to watch for:**
- "Clearly..."
- "Obviously..."
- "As you can see..."
- "It goes without saying..."
- "As everyone knows..."

**Fix:** Delete these phrases. Let evidence speak for itself.

---

## Part 2: When to Delete Content Entirely

### 2.1: Weak Connections to Core Claims

**Delete when:** A statement doesn't directly support your main argument.

**Example:**
❌ "With 56% of B2B sales professionals using AI daily, automation has shifted from competitive advantage to baseline requirement."

**Why delete:**
- Doesn't connect to the specific product benefit (750 hours saved, 20% deal velocity)
- Generic market stat that doesn't prove this tool matters
- Weak logic: "Many people use AI" ≠ "You need this specific tool"

**Decision framework:**
- Does this statement prove my main claim?
- Could I remove this without changing the argument?
- Is this statement stronger than no statement?
- If unclear → Delete

---

### 2.2: Redundant Explanations

**Delete when:** You're saying the same thing twice with different words.

**Example:**
❌ "It automates three core functions: researching prospect accounts, personalizing outreach messages, and managing send workflows. It automates prospect research, personalizes outreach messages, and manages send workflows—freeing reps from manual work so they focus on selling."

**Why delete:**
- First sentence lists functions
- Second sentence repeats the same functions
- Only the benefit ("freeing reps") is new

**Keep this:**
✅ "It automates prospect research, personalizes outreach messages, and manages send workflows—freeing reps from manual work so they focus on selling."

**Decision framework:**
- Am I restating something I just said?
- Does the restatement add new information?
- Could a reader understand with just one version?
- If redundant → Delete the weaker version

---

### 2.3: Sentences That Create Confusion

**Delete when:** A statement introduces complexity without adding clarity.

**Example:**
❌ "It can monitor 200+ target accounts simultaneously, research prospects in seconds, and draft personalized emails within minutes—constantly without manual intervention."

**Why delete from opening:**
- "200+ accounts" is a spec detail, not a benefit
- Raises questions: "Do I have 200 targets?" "Why 200?"
- Buried benefit: time savings already stated better elsewhere

**Where to keep it:**
✅ In dedicated "Monitoring Capacity" section with context:
"The agent monitors over 200 target accounts simultaneously. Manual monitoring at this scale is unfeasible—an SDR would spend 40-50 hours weekly on research alone."

**Decision framework:**
- Does this raise more questions than it answers?
- Is this detail more valuable with context?
- Does removing this improve clarity?
- If confusing → Move or delete

---

### 2.4: Vague Market Context Without Proof

**Delete when:** You're using market trends to justify your product without showing connection.

**Example:**
❌ "In today's fast-paced business environment, companies need to adapt quickly to remain competitive in an ever-changing landscape."

**Why delete:**
- Generic statement that could apply to any product
- No specific connection to your solution
- Reads like AI-generated throat-clearing

**Decision framework:**
- Is this specific to my product/situation?
- Would this statement be true for competitors too?
- Am I using this to sound authoritative?
- If generic → Delete

---

### 2.5: Defensive Disclaimers That Undermine Trust

**Delete when:** You're creating doubt to preemptively address objections.

**Example:**
❌ "Important clarification: Buyer Intent is a separate HubSpot feature under Marketing Hub—NOT part of the Prospecting Agent."

**Why delete:**
- "Important clarification" signals confusion exists
- All-caps "NOT" feels like you're correcting readers
- Creates cognitive load: "Wait, so what IS part of it?"

**Better approach:**
✅ Integrate naturally: "Buyer Intent (a Marketing Hub feature) tracks visitor and research signals that trigger Prospecting Agent workflows."

**Decision framework:**
- Am I correcting a problem I created?
- Does this clarification introduce confusion?
- Could I restructure to avoid needing this?
- If defensive → Restructure or delete

---

### 2.6: Spec-Sheet Details Without Context

**Delete when:** You're listing features without showing why they matter.

**Example:**
❌ "Breeze AI powers 22 specialized agents."

**Why delete (or contextualize):**
- Number without meaning: "Why 22?" "What agents?"
- Doesn't connect to user benefit
- Sounds like marketing padding

**Better approach:**
✅ "Breeze AI powers multiple specialized agents—including the Prospecting Agent—that share the same data layer."

**Decision framework:**
- Does this number/spec matter to readers?
- Can I connect this to a benefit?
- Am I including this to sound impressive?
- If meaningless → Delete or contextualize

---

### 2.7: Flow-Interrupting Sales Pitches in Educational Content

**Delete when:** A paragraph interrupts the natural flow of explanation to insert a promotional statement that repeats information already covered.

**Why delete:**
- **Interrupts flow** — Breaks the logical progression of your explanation
- **Point already made** — The section immediately before or after says the same thing
- **No new information** — Doesn't add value beyond what's already there
- **Feels like a sales pitch** — In educational/implementation guides, promotional language stands out as jarring

**Example:**
You're explaining "Personalization at Scale" with examples. Then this appears:

❌ "As you scale, data fragmentation between tools slows prospecting. The agent eliminates manual research steps by centralizing prospect intelligence in your CRM."

**Why delete:**
- You're already in the section explaining how the agent works
- The next section covers this exact benefit
- It breaks the teaching flow with promotional language
- Readers are learning implementation—they've already bought in

**Better approach:**
✅ Let your educational content flow naturally. The benefits become clear through demonstration, not interruption.

**Decision framework:**
- Does this interrupt the natural flow of explanation?
- Is this point already made elsewhere in the section?
- Am I shifting from teaching to selling mid-explanation?
- Would readers understand better if I removed this?
- If interrupting → Delete

---

## Part 3: Writing With Confidence

### 3.1: Direct Statements Over Hedging

**Pattern:**
❌ Weak: "This could potentially help you save time."
✅ Strong: "This saves 15 hours per week."

❌ Weak: "You might want to consider implementing this."
✅ Strong: "Implement this to reduce errors by 40%."

❌ Weak: "It seems that this approach may be effective."
✅ Strong: "This approach increases conversions by 23%."

**Rule:** If you have evidence, state it directly. If you don't have evidence, don't make the claim.

---

### 3.2: Specific Benefits Over Vague Claims

**Pattern:**
❌ Vague: "This is a powerful solution."
✅ Specific: "This reduces processing time from 3 days to 4 hours."

❌ Vague: "This provides significant improvements."
✅ Specific: "This cuts prospect research from 20 minutes to under 1 minute."

❌ Vague: "This offers high value for your business."
✅ Specific: "This saves $120K annually by eliminating manual data entry."

**Rule:** Replace adjectives with metrics. Replace "powerful" with proof.

---

### 3.3: Active Recommendations Over Passive Suggestions

**Pattern:**
❌ Passive: "It might be worth considering this approach."
✅ Active: "Use this approach for accounts over $50K."

❌ Passive: "You could potentially test this feature."
✅ Active: "Test this feature with 25-50 key accounts first."

❌ Passive: "This may be suitable for larger teams."
✅ Active: "This works best for teams of 10+ reps."

**Rule:** Make clear recommendations. Trust readers to decide if it fits them.

---

### 3.4: Evidence Over Reassurance

**Pattern:**
❌ Reassurance: "Don't worry—this won't disrupt your workflow."
✅ Evidence: "Implementation takes 2 hours and runs alongside existing systems."

❌ Reassurance: "This is easier than it sounds."
✅ Evidence: "90% of teams complete setup in under 1 hour."

❌ Reassurance: "You don't need technical skills for this."
✅ Evidence: "Configure without coding using the visual workflow builder."

**Rule:** Show, don't reassure. Evidence builds trust; reassurance plants doubt.

---

## Part 4: Editing Checklist for Defensive Writing

When reviewing content, ask:

### Detection Questions:
- [ ] Does this phrase announce itself as important? ("Critical clarification:")
- [ ] Am I reassuring readers about something they weren't worried about?
- [ ] Am I apologizing for complexity instead of fixing it?
- [ ] Do I have phrases like "could potentially" or "might possibly"?
- [ ] Am I using "Obviously" or "Clearly" to assert authority?
- [ ] Does this statement create confusion instead of resolving it?
- [ ] Am I stating market trends without connecting to my specific claim?
- [ ] Am I listing features without showing benefits?
- [ ] Would removing this sentence improve clarity?

### Deletion Questions:
- [ ] Does this directly support my main argument?
- [ ] Am I saying the same thing twice?
- [ ] Does this raise questions it doesn't answer?
- [ ] Is this generic enough to apply to any product?
- [ ] Am I creating doubt to address it?
- [ ] Is this a spec without context?
- [ ] Could I prove this claim with data instead of hedging?
- [ ] Does this interrupt the flow of my explanation?
- [ ] Am I inserting a sales pitch in the middle of teaching?

### Improvement Questions:
- [ ] Can I replace hedging with evidence?
- [ ] Can I replace vague claims with specific metrics?
- [ ] Can I make a recommendation instead of a suggestion?
- [ ] Can I show proof instead of offering reassurance?
- [ ] Can I delete the defensive frame and state the fact directly?

---

## Part 5: Before and After Examples

### Example 1: Market Context Deletion

❌ **Before:**
"With 56% of B2B sales professionals using AI daily, automation has shifted from competitive advantage to baseline requirement. (Source: LinkedIn)"

✅ **After:**
Delete entirely. This doesn't prove the Prospecting Agent is necessary—it just states that AI is popular.

**Why:** The stat is too generic. It doesn't connect to the specific benefits (750 hours saved, 20% deal velocity lift) you already proved.

---

### Example 2: Defensive Clarification Deletion

❌ **Before:**
"Important distinction: The Prospecting Agent is ONE application powered by Breeze AI, which powers multiple agents."

✅ **After:**
"The Prospecting Agent is one application within Breeze AI, which powers multiple specialized agents."

**Why:** "Important distinction" is defensive. "ONE" in caps feels like you're correcting readers. Just state the architecture clearly.

---

### Example 3: Redundancy Elimination

❌ **Before:**
"It automates three core functions: researching prospect accounts, personalizing outreach messages, and managing send workflows.

It automates prospect research, personalizes outreach messages, and manages send workflows—freeing reps from manual work so they focus on selling."

✅ **After:**
"It automates prospect research, personalizes outreach messages, and manages send workflows—freeing reps from manual work so they focus on selling."

**Why:** You don't need to list the functions twice. The second version adds the benefit (freeing reps) while covering the same functions more concisely.

---

### Example 4: Reassurance Deletion

❌ **Before:**
"It's a powerful but optional combination."

✅ **After:**
Delete entirely, or replace with evidence:
"When both signals trigger simultaneously, conversion rates increase 34%."

**Why:** "Powerful but optional" hedges. Either show the power with data or don't make the claim.

---

### Example 5: Spec Detail Contextualization

❌ **Before (in opening):**
"It can monitor 200+ target accounts simultaneously, research prospects in seconds, and draft personalized emails within minutes—constantly without manual intervention."

✅ **After (moved to dedicated section):**
"The agent monitors over 200 target accounts simultaneously—tracking website visits, job changes, and funding announcements. Manual monitoring at this scale is unfeasible without dedicated SDRs."

**Why:** The "200+ accounts" spec needs context. In the opening, it raises questions. In a dedicated section with the manual alternative, it proves value.

---

## Summary: The Confidence Test

Before publishing any content, apply this test:

**Does this statement:**
1. Plant doubt? → Delete or rewrite
2. Create confusion? → Simplify or delete
3. Defend against criticism no one made? → Delete
4. Hedge when you have evidence? → Add evidence, remove hedge
5. Reassure when you should prove? → Show proof, remove reassurance
6. State something twice? → Keep the stronger version
7. Feel like you're arguing with the reader? → Reframe as collaboration
8. Interrupt the flow to make a sales pitch? → Delete—let teaching speak for itself

**Remember:** Confidence comes from clarity + evidence, not from telling readers how clear or confident you are. In educational content, benefits emerge through demonstration—not promotional interruptions.
