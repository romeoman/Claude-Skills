# Advanced Editing Examples and Edge Cases

This reference provides detailed examples for complex editing scenarios.

## Advanced Grammar & Punctuation

### Comma Usage Patterns

**Serial comma (Oxford comma):**
- Use: "We offer strategy, execution, and reporting"
- Avoid ambiguity: "I'd like to thank my parents, Oprah Winfrey, and God" vs "I'd like to thank my parents, Oprah Winfrey and God"

**Comma splices:**
- ❌ "The report is ready, it needs approval"
- ✅ "The report is ready. It needs approval" OR "The report is ready; it needs approval"

**Introductory elements:**
- "However, the results surprised us"
- "In 2024, sales increased 40%"
- "After analyzing the data, we found three insights"

### Apostrophe Mastery

**Possessive rules:**
- Singular: "The company's revenue" (even if company ends in 's')
- Plural: "The companies' revenue" (multiple companies)
- Its vs it's: "The company lost its focus" vs "It's time to act"

**Contractions:**
- don't, can't, won't, shouldn't, you're, they're, we're
- Avoid in formal reports; use in blogs and emails

### Em Dash, En Dash, Hyphen

**Em dash (—):** For emphasis or breaks in thought
- "The results—surprising to everyone—changed our strategy"
- "Three metrics matter—engagement, conversion, and retention"

**En dash (–):** For ranges
- "Q1–Q4 revenue"
- "Pages 10–25"
- "2020–2024 growth"

**Hyphen (-):** For compound modifiers
- "full-time employee"
- "long-term strategy"
- "data-driven decision"

---

## Advanced Brevity Techniques

### Common Wordy Phrases and Fixes

**Business writing inflation:**
- "conduct an analysis of" → "analyze"
- "make a decision about" → "decide"
- "give consideration to" → "consider"
- "is in agreement with" → "agrees with"
- "has the ability to" → "can"
- "during the time that" → "while"
- "in spite of the fact that" → "although"
- "until such time as" → "until"

**Academic verbosity:**
- "a number of" → "several" or specific number
- "a majority of" → "most"
- "with regard to" → "about"
- "in the area of" → "in"
- "on the part of" → "by"

**Weak verb constructions:**
- "make an assessment" → "assess"
- "provide assistance" → "assist"
- "perform an investigation" → "investigate"
- "reach a conclusion" → "conclude"

### Redundancy Patterns

**Common redundancies:**
- "absolutely essential" → "essential"
- "advance planning" → "planning"
- "basic fundamentals" → "fundamentals"
- "completely eliminate" → "eliminate"
- "end result" → "result"
- "future plans" → "plans"
- "past history" → "history"
- "revert back" → "revert"
- "surrounding circumstances" → "circumstances"
- "unexpected surprise" → "surprise"

---

## Advanced Cliché Detection

### Industry-Specific Jargon

**Tech/SaaS:**
- "best-in-class solution" → Specify what makes it best
- "seamless integration" → "integrates with X, Y, Z in under 5 minutes"
- "next-generation platform" → Specify the new capabilities
- "360-degree view" → "consolidated dashboard showing X, Y, Z"

**Marketing:**
- "engage with customers" → "send personalized emails to 10k+ subscribers"
- "drive awareness" → "reach 50k decision-makers via LinkedIn"
- "thought leadership" → "publish research cited by industry analysts"

**Sales:**
- "close more deals" → "increase win rate from 15% to 28%"
- "build relationships" → "conduct 20+ discovery calls monthly"
- "qualify leads" → "identify prospects with $50k+ budgets"

### Detecting AI-Generated Text Patterns

**Common AI phrases to replace:**
- "delve into" → "examine", "explore", "analyze"
- "In today's fast-paced world" → Start with specific insight
- "It's no secret that" → State the fact directly
- "Unlock the potential" → Specific benefit
- "game-changing" → Specific improvement metric
- "cutting-edge" → Specific new capability

---

## Advanced Readability Strategies

### Sentence Rhythm Patterns

**Vary sentence length intentionally:**
```
Short sentence for impact. (5 words)
Follow with a medium sentence that explains the concept. (10 words)
Then add a longer sentence that provides context, details, and supporting information to help readers fully understand the idea. (20 words)
Conclude with another short punch. (6 words)
```

### Complex Idea Breakdown

**Before (convoluted):**
"The implementation of the revenue operations framework, which involves the strategic alignment of processes, people, technology, and data across marketing, sales, and customer success departments, enables organizations to achieve predictable revenue growth through the elimination of silos and the establishment of unified goals and metrics."

**After (clear):**
"The revenue operations framework aligns four elements: processes, people, technology, and data. This alignment breaks down silos between marketing, sales, and customer success. The result: predictable revenue growth through unified goals and metrics."

**Technique used:**
1. Break one 60-word sentence into three sentences
2. Lead with the main concept
3. Explain the mechanism
4. State the outcome

---

## Advanced Active Voice Techniques

### Passive Voice Exceptions

**When passive is better:**

1. **Unknown actor:**
   - ✅ "The database was hacked overnight"
   - (We don't know who did it)

2. **Focus on action, not actor:**
   - ✅ "The policy was updated last month"
   - (The policy matters more than who updated it)

3. **Diplomatic phrasing:**
   - ✅ "Mistakes were made in the Q4 forecast"
   - (Softer than "You made mistakes")

4. **Scientific/technical writing:**
   - ✅ "The sample was heated to 100°C"
   - (Standard in scientific method)

### Complex Active Voice Conversions

**Multi-clause sentences:**
- ❌ "The strategy that was developed by the consulting team was implemented by the operations department and has been monitored by leadership"
- ✅ "The consulting team developed the strategy. The operations department implemented it. Leadership monitors progress."

**Buried verbs (nominalizations):**
- ❌ "We conducted an evaluation of the implementation"
- ✅ "We evaluated the implementation"
- ❌ "The committee made a decision to approve"
- ✅ "The committee decided to approve"

---

## Advanced Confidence Building

### Replace Hedging with Evidence

**Weak (hedged):**
"It seems that this approach might potentially help teams work somewhat more efficiently."

**Strong (confident with evidence):**
"This approach increased team efficiency by 34% across 12 companies (Source: McKinsey Q2 2024 Study)."

### Certainty Levels

**Use appropriate certainty:**
- **Proven facts:** "This reduces costs by 40%"
- **Strong evidence:** "Research shows this improves outcomes"
- **Reasonable prediction:** "This approach should work for most teams"
- **Uncertain:** "This may help in some cases"

### Command vs. Suggestion

**Weak suggestions:**
- "You might want to consider trying this approach"
- "It could be helpful if you maybe looked at this data"

**Strong commands:**
- "Try this approach"
- "Review this data"
- "Implement these changes"

---

## Advanced Repetition Prevention

### Elegant Variation

**Instead of repeating "company":**
- company → organization → business → firm → enterprise → entity
- (But don't get too fancy—clarity > variety)

**Instead of repeating "improve":**
- improve → enhance → strengthen → boost → increase → optimize
- (Choose based on context)

### Synonym Selection Guide

**Match intensity:**
- small → tiny → minuscule (increasing intensity)
- big → large → enormous (increasing intensity)

**Match formality:**
- Casual: help, fix, show
- Formal: assist, repair, demonstrate

### Pronoun Usage

**Avoid repetition with pronouns:**
- ❌ "HubSpot offers tools. HubSpot's tools include automation. HubSpot also provides analytics."
- ✅ "HubSpot offers tools including automation. It also provides analytics."

---

## Content Type Specific Guidelines

### Blog Post Editing

**Opening paragraphs:**
- Hook sentence: Must grab attention
- Context: 2-3 sentences maximum
- No TL;DR sections

**Structure:**
- Short paragraphs (2-3 sentences)
- Frequent subheadings
- Mix of short and medium sentences
- Conversational tone acceptable

**Citations format:**
- Always: ([_Source Name_](URL))
- Example: "66% of marketers use AI ([_HubSpot Study_](https://example.com))"

### Email Editing

**Structure:**
- Subject line: 6 words or fewer
- Opening: State purpose in first sentence
- Body: 3-5 short paragraphs maximum
- Closing: Clear call to action

**Tone:**
- Professional but warm
- Use first names
- Action-oriented language
- Brief pleasantries acceptable

### Social Media Editing

**Platform-specific:**
- **LinkedIn:** Professional, thought leadership, 1-3 paragraphs
- **Twitter/X:** Under 280 characters, punchy, one main idea
- **Instagram:** Visual-first, shorter captions, hashtags optional
- **Facebook:** Conversational, 2-4 paragraphs, story-driven

**Universal rules:**
- One key message
- Strong hook
- Clear call to action
- No jargon

### Report/Document Editing

**Structure:**
- Executive summary: 1 page maximum
- Clear section headers
- Data tables and charts
- Citations for all claims

**Tone:**
- More formal language
- Passive voice acceptable for methods
- Third person perspective
- Objective, data-driven

---

## Edge Cases and Special Situations

### Industry Terminology

**When to keep jargon:**
- Technical documentation for experts
- Industry-standard terms (e.g., "RevOps" in B2B SaaS)
- Proper nouns and trademarked terms

**When to explain jargon:**
- First use in general audience content
- Non-expert readers
- Ambiguous acronyms

### Stylistic Choices vs. Errors

**Intentional fragments (keep):**
- "Revenue up 40%. Costs down 20%. Profit doubled."
- "Simple. Effective. Proven."

**Unintentional fragments (fix):**
- "Because the team worked hard." → Add independent clause

**Stylistic repetition (keep):**
- "We don't give up. We don't quit. We don't surrender."
- (Intentional rhetoric)

**Unintentional repetition (fix):**
- "The team worked hard. The team delivered results."
- → "The team worked hard and delivered results."

### Voice and Tone Preservation

**Maintain writer's style:**
- Humorous → Keep wit and jokes
- Academic → Allow complex vocabulary if appropriate
- Casual → Keep conversational tone
- Corporate → Professional distance acceptable

**Red flags indicating over-editing:**
- Every sentence sounds the same
- All personality removed
- Sounds like AI wrote it
- Too formal for context
- Too casual for context

---

## Multi-Pass Editing Strategy

### First Pass: Big Picture
- Structure and flow
- Major redundancies
- Section organization
- Paragraph breaks

### Second Pass: Sentence Level
- Active voice
- Brevity
- Clarity
- Readability

### Third Pass: Word Level
- Grammar and spelling
- Punctuation
- Word choice
- Repetition

### Final Pass: Quality Check
- Read aloud
- Check formatting
- Verify links/citations
- Confirm tone matches intent

---

## Editing Metrics to Track

**Quantitative improvements:**
- Word count reduction (aim for 20-40% cut)
- Passive voice percentage (aim for <10%)
- Average sentence length (aim for 15-20 words)
- Reading grade level (aim for 8th-10th grade)

**Qualitative improvements:**
- Natural voice preserved? (Yes/No)
- Appropriate for format? (Yes/No)
- Clear call to action? (Yes/No)
- Specific vs vague language? (Rate 1-10)

---

## Common Error Patterns by Writer Type

### Non-Native English Speakers
- Article usage (a/an/the)
- Preposition confusion
- Tense consistency
- Idiomatic expressions

### Academic Writers
- Overly complex sentences
- Passive voice overuse
- Jargon heavy
- Lack of contractions

### Marketing Writers
- Cliché overuse
- Hyperbole
- Vague benefit claims
- Missing specificity

### Technical Writers
- Assuming too much knowledge
- Jargon without explanation
- Overly detailed
- Boring tone

---

## Final Quality Indicators

**Good editing preserves:**
- Writer's unique voice
- Intended tone
- Key personality quirks
- Stylistic choices

**Good editing removes:**
- All errors
- Unnecessary words
- Confusing passages
- Weak language

**Good editing adds:**
- Clarity
- Impact
- Professionalism
- Readability

**Signs of over-editing:**
- Sounds robotic
- Lost personality
- Too perfect/sterile
- Changed meaning
