# Paragraph Structure, Content Density & Linear Writing: The Complete Guide

## Core Principle: One Idea Per Paragraph, Maximum Clarity

Long, dense paragraphs create cognitive overload and intimidate readers. Strong writing breaks complex information into lean, linear units that readers can scan, understand, and remember.

**Research Foundation:** Cognitive load theory shows that paragraphs exceeding 5-7 sentences dramatically increase cognitive burden. Readers scan rather than read continuously—dense "walls of text" cause readers to skip content entirely.

---

## Part 1: The Problem—Walls of Text and Cognitive Overload

### 1.1: Technical Terms for Problematic Paragraph Structure

**Wall of Text**
- **Definition:** Dense paragraphs with too many sentences and ideas bundled together without breaks, white space, or organizational hierarchy
- **Impact:** Creates visual intimidation and cognitive overload
- **Detection:** Paragraphs exceeding 7-8 sentences or 150+ words

**Verbosity**
- **Definition:** Using significantly more words than necessary to communicate an idea
- **Related terms:** Loquacity, garrulousness, prolixity, grandiloquence
- **Opposite:** Brevity, conciseness, succinctness, economy of language

**Purple Prose**
- **Definition:** Overly ornate prose with excessive adjectives, adverbs, and metaphors
- **Problem:** Disrupts narrative flow by drawing attention to the writing instead of the message
- **Detection:** When style overwhelms substance

**Cognitive Load Theory**
Three types of cognitive demands on readers:
1. **Intrinsic load:** Inherent complexity of the content
2. **Extraneous load:** How information is presented (long paragraphs increase this)
3. **Germane load:** Mental effort to process and retain information

**Key finding:** Long, dense paragraphs increase extraneous cognitive load by presenting information in a manner that does not align with how readers efficiently process and retain information.

---

### 1.2: Why Long Paragraphs Fail

**Readers experience problems when paragraphs are too long:**

1. **Visual intimidation** — Dense blocks of text signal "this will be hard work"
2. **Scanning difficulty** — No visual breaks make it hard to find specific information
3. **Memory overload** — Too many ideas bundled together exceed working memory capacity
4. **Lost focus** — Readers lose track of the main point amid supporting details
5. **Skip behavior** — Intimidated readers skip entire sections

**Research shows:**
- Optimal paragraph length: 3-5 sentences for most contexts
- Maximum before cognitive overload: 7-8 sentences
- Sentence length sweet spot: 15-20 words
- Readers prefer white space and visual breaks every 75-100 words

---

## Part 2: The Solution—Chunking and Lean Content Structure

### 2.1: Chunking (The Primary Technique)

**Definition:** Breaking content into small, distinct units of information rather than presenting an undifferentiated mass of atomic items.

**Based on George A. Miller's 1956 research:** Humans have limited capacity for processing information at once. By chunking content into meaningful, visually distinct units, writers make scanning easier and improve comprehension and memory.

**How to chunk effectively:**

1. **One idea per paragraph** — Each paragraph develops exactly one complete thought
2. **Visual breaks** — Use white space to separate chunks
3. **Hierarchical organization** — Use headings to signal what each chunk contains
4. **Logical sequence** — Each chunk builds on the previous one

**Example:**

❌ **Before (Wall of Text):**
"The Prospecting Agent automates research by querying multiple data sources and synthesizing findings into actionable insights. It monitors target accounts continuously, tracking website visits, job changes, funding announcements, and competitive activity. The agent also drafts personalized outreach messages based on prospect behavior and firmographic data, learning from rep edits to improve future drafts. All activities are automatically logged to contact timelines, creating a complete record of engagement without manual data entry."

✅ **After (Chunked):**
**Research Automation:**
The Prospecting Agent queries multiple data sources and synthesizes findings into actionable insights.

**Continuous Monitoring:**
It tracks website visits, job changes, funding announcements, and competitive activity across target accounts.

**Personalized Outreach:**
The agent drafts personalized messages based on prospect behavior and firmographic data, learning from rep edits to improve future drafts.

**Automatic Logging:**
All activities are logged to contact timelines automatically, creating complete engagement records without manual data entry.

**Why better:** Each chunk addresses one capability with clear heading, making it scannable and reducing cognitive load.

---

### 2.2: Progressive Disclosure

**Definition:** A user experience technique that defers advanced features and information to secondary or tertiary levels.

**Application to writing:**
- **Primary level:** Essential information all readers need
- **Secondary level:** Details for readers who need more depth
- **Tertiary level:** Advanced or technical information for specialists

**How to implement:**
1. Lead with the most important information (BLUF)
2. Use expandable sections or "Read more" links for details
3. Provide clear navigation to advanced content
4. Don't bury essential information in details

---

### 2.3: The One-Sentence-Per-Idea Test

**Ask yourself:**
- Does this sentence introduce a new idea?
- If yes → Consider starting a new paragraph
- Does this sentence support the paragraph's topic sentence?
- If no → Move it to a different paragraph or delete

**Common problem:** Paragraphs that bundle multiple ideas

❌ **Multiple ideas in one paragraph:**
"The agent saves 750 hours weekly. It also increases deal velocity by 20%. Response rates improve 34% with personalized outreach. Teams report 40% more discovery calls. The agent monitors 200+ accounts simultaneously."

✅ **Separated by idea:**
**Time Savings:**
The agent saves 750 hours weekly—equivalent to 3-4 full-time employees' work capacity.

**Deal Velocity:**
Deal velocity increases 20% when the agent automates research and outreach timing.

**Response Rates:**
Personalized outreach driven by prospect behavior increases response rates 34%.

---

## Part 3: Linear Writing and BLUF (Bottom Line Up Front)

### 3.1: Linear Writing Structure

**Definition:** Presenting information in logical sequence from beginning to end, guiding readers systematically through content.

**Key principle:** Details move from what the reader knows to what the reader does not know.

**Three levels of linear organization:**
1. **Macro level:** Where does the overall document begin?
2. **Paragraph level:** What's the logical progression of ideas?
3. **Sentence level:** Does each sentence flow from the previous one?

**Linear writing benefits:**
- Readers can follow the progression naturally
- Information arrives when readers need it
- Each piece builds on what came before
- No confusion about relationships between ideas

---

### 3.2: BLUF—Bottom Line Up Front

**Definition:** Beginning a message with its key information—the "bottom line"—providing readers with the most important information first.

**Origin:** U.S. military communication standard developed because "the greatest weakness in ineffective writing is that it doesn't quickly transmit a focused message."

**BLUF differs from traditional writing:** Conclusions precede supporting material rather than following arguments and considerations.

**BLUF operates at multiple levels:**
- Full documents
- Individual sections
- Paragraphs (topic sentences)
- Individual sentences

**Why BLUF works:**
- Readers can immediately determine relevance
- Key information isn't buried
- Readers understand context before encountering details
- Reduces cognitive load by providing framework first

**Example:**

❌ **Traditional structure (conclusion last):**
"The agent queries Breeze Intelligence for firmographic data, analyzes recent company news, reviews prior CRM interactions, and identifies key stakeholders. Based on this research, it generates personalized outreach messages tailored to the prospect's role and company situation. This comprehensive research process reduces manual work from 15-20 minutes per prospect to under 1 minute."

✅ **BLUF structure (conclusion first):**
"The agent reduces research time from 15-20 minutes to under 1 minute per prospect. It queries Breeze Intelligence for firmographic data, analyzes company news, reviews CRM interactions, and generates personalized outreach based on findings."

**Why better:** Readers immediately understand the value (time savings), then receive supporting details explaining how it works.

---

### 3.3: The Inverted Pyramid

**Definition:** Placing the most fundamental facts in the lead paragraph, with non-essential information in following paragraphs arranged by importance.

**Origin:** Telegraph technology—journalists transmitted vital information first in case transmission was lost.

**Modern application:**
- Most important information → First paragraph
- Supporting details → Second paragraph
- Background context → Third paragraph
- Additional details → Remaining paragraphs

**Why it works for readers:**
- Busy readers get essential information immediately
- Readers can stop at any point and have core facts
- Editors can cut from bottom without losing critical content

---

## Part 4: Lean Writing—Maximum Information, Minimum Complexity

### 4.1: What Is Lean Writing?

**Definition:** Producing documents with all necessary information but in a form that is easy to access, read, and understand.

**Core paradox:** How to provide comprehensive information while remaining readable and accessible?

**Solution:** Strategic use of:
- Headings and subheadings
- Tables of contents
- Cross-referencing
- Hierarchical organization
- Visual breaks

**Key insight:** Readers don't read sequentially—they search for specific information. Documents must be organized so readers can quickly locate what they need.

---

### 4.2: The Conciseness Principle

**From Strunk & White:** "Vigorous writing is concise. A sentence should contain no unnecessary words, a paragraph no unnecessary sentences, for the same reason that a drawing should have no unnecessary lines and a machine no unnecessary parts."

**Critical distinction:** Conciseness doesn't mean:
- Making all sentences short
- Avoiding all detail
- Treating subjects only in outline

**Conciseness DOES mean:**
- Every word must contribute meaningfully
- Eliminate weak or unnecessary words
- Replace vague phrases with specific alternatives
- Make every word "tell"

**Economy of Language:** Careful management of words without sacrificing meaning or clarity.

---

### 4.3: Smart Brevity Framework

**Definition:** Distilling complex ideas into impactful communication by keeping writing efficient without sacrificing meaning.

**Principles:**
1. Start with the main point (BLUF)
2. Use short, clear sentences
3. Break complex ideas into digestible chunks
4. Eliminate filler words and phrases
5. Use active voice
6. Front-load sentences with key information

**Application:** First drafts are often longer because they include unnecessary words. Final drafts achieve economy of words through deliberate revision.

---

## Part 5: Paragraph Length Standards by Context

### 5.1: General Writing Guidelines

**Target paragraph length:**
- **Optimal:** 3-5 sentences
- **Maximum:** 7-8 sentences before cognitive overload
- **Word count:** Aim for 75-100 words per paragraph

**Page density:**
- For single-spaced pages: At least 3-4 paragraphs per page
- Avoid "walls of text" that intimidate readers

---

### 5.2: Context-Specific Guidelines

**Blog Posts & Web Content:**
- Shorter paragraphs (2-4 sentences)
- More white space for scanning
- Frequent subheadings every 200-300 words

**Business Writing:**
- 3-5 sentences per paragraph
- Clear topic sentences using BLUF
- Supporting details in logical order

**Technical Documentation:**
- One procedure or concept per paragraph
- Numbered steps when appropriate
- Heavy use of chunking and headings

**Academic Writing:**
- 4-6 sentences per paragraph
- More development of ideas allowed
- Still maintain one idea per paragraph

**Email & Professional Communication:**
- 2-3 sentences maximum per paragraph
- Extreme BLUF—key information in first sentence
- Heavy use of bullet points and white space

---

## Part 6: The Paragraph Structure Checklist

Before publishing, audit each paragraph:

### Length Test
- [ ] Does this paragraph exceed 7-8 sentences?
- [ ] Does it exceed 100-150 words?
- [ ] Does it look intimidating on the page?

**If YES to any → Break into multiple paragraphs**

---

### Unity Test
- [ ] Does this paragraph develop exactly one idea?
- [ ] Does every sentence support the topic sentence?
- [ ] Could I summarize this paragraph in one sentence?

**If NO to any → Separate ideas into different paragraphs**

---

### Chunking Test
- [ ] Is the main idea immediately clear from the first sentence?
- [ ] Are supporting details arranged in logical order?
- [ ] Does this paragraph connect smoothly to the next one?

**If NO to any → Revise for clarity and flow**

---

### BLUF Test
- [ ] Does the topic sentence state the main point?
- [ ] Or does the main point come at the end?
- [ ] Would moving the conclusion to the beginning improve clarity?

**If main point comes last → Front-load with BLUF structure**

---

### Visual Density Test
- [ ] Does this page have adequate white space?
- [ ] Are there visual breaks every 100-150 words?
- [ ] Can readers scan and find information easily?

**If NO to any → Add paragraph breaks and headings**

---

## Part 7: Before and After Examples

### Example 1: Wall of Text → Chunked Structure

❌ **Before (12 sentences, 210 words, multiple ideas):**
"The Prospecting Agent is a specialized AI application on HubSpot's Breeze AI platform that automates prospect research, personalizes outreach messages, and manages send workflows—freeing reps from manual work so they focus on selling. It can monitor 200+ target accounts simultaneously, research prospects in seconds, and draft personalized emails within minutes—constantly without manual intervention. The agent queries Breeze Intelligence for firmographic data, analyzes recent company news, reviews prior CRM interactions, and identifies key stakeholders before generating contextually relevant outreach messages. Research time drops from 15-20 minutes to under 1 minute per prospect, saving teams 750+ hours weekly. For a 10-person sales team researching 50 prospects weekly, this translates to 125-167 hours saved—equivalent to 3-4 full-time employees' work capacity. The agent learns from rep edits to improve draft quality over time, creating a feedback loop that enhances personalization. All activities are automatically logged to contact timelines, creating a complete record of engagement without manual data entry. Response rates increase 34% when outreach is personalized based on prospect behavior and firmographic data. Deal velocity accelerates 20% as reps spend more time in discovery calls rather than researching accounts manually."

**Problems:**
- 12 sentences in one paragraph
- 210 words—cognitive overload
- 6+ distinct ideas mixed together
- No visual breaks or hierarchy
- Main value buried in the middle
- Impossible to scan

✅ **After (Chunked with BLUF structure):**

**Time Savings (BLUF):**
The Prospecting Agent reduces research time from 15-20 minutes to under 1 minute per prospect—saving teams 750+ hours weekly.

**What It Does:**
The agent automates prospect research, personalizes outreach messages, and manages send workflows—freeing reps from manual work to focus on selling.

**How It Works:**
It queries Breeze Intelligence for firmographic data, analyzes company news, reviews CRM interactions, and identifies key stakeholders. Based on this research, it generates contextually relevant outreach messages.

**Scale Impact:**
For a 10-person sales team researching 50 prospects weekly, this saves 125-167 hours—equivalent to 3-4 full-time employees' work capacity.

**Continuous Improvement:**
The agent learns from rep edits to improve draft quality over time, creating a feedback loop that enhances personalization.

**Results:**
- Response rates increase 34% with personalized outreach
- Deal velocity accelerates 20%
- All activities logged automatically to contact timelines

**Why better:**
- 6 paragraphs instead of 1
- Each develops one idea
- BLUF structure—time savings first
- Clear headings for scanning
- Logical progression
- 60% easier to scan and understand

---

### Example 2: Buried Main Point → BLUF Structure

❌ **Before (Main point at end):**
"The agent queries multiple data sources including Breeze Intelligence, analyzes firmographic data, reviews recent company news, identifies key stakeholders, and examines prior CRM interactions to build comprehensive prospect profiles. Based on this research, it drafts personalized outreach messages tailored to the prospect's role, company situation, and recent activities. This entire process, which would take a rep 15-20 minutes manually, is completed by the agent in under 1 minute."

**Problem:** Most important information (time savings) comes last. Readers must wade through details before understanding value.

✅ **After (BLUF structure):**
"The agent completes research in under 1 minute—compared to 15-20 minutes manually. It queries Breeze Intelligence for firmographic data, analyzes company news, reviews CRM interactions, and drafts personalized outreach based on findings."

**Why better:**
- Value statement first (BLUF)
- Supporting details follow
- 50% fewer words (39 vs. 78)
- Readers immediately understand benefit

---

### Example 3: Multiple Ideas → Separated Paragraphs

❌ **Before (4 distinct ideas in one paragraph):**
"The agent monitors 200+ target accounts simultaneously, tracking website visits, job changes, funding announcements, and competitive activity. Manual monitoring at this scale is unfeasible—an SDR would spend 40-50 hours weekly on research alone. Response rates increase 34% when outreach is personalized based on behavioral signals. Teams report 40% more time spent in discovery calls and demos."

**Problem:** Four distinct ideas (capacity, manual alternative, response rates, time allocation) bundled together without logical connection.

✅ **After (Separated by idea):**

**Monitoring Capacity:**
The agent monitors over 200 target accounts simultaneously—tracking website visits, job changes, funding announcements, and competitive activity.

**Manual Alternative:**
Manual monitoring at this scale is unfeasible. An SDR would spend 40-50 hours weekly on research alone.

**Impact on Response Rates:**
Response rates increase 34% when outreach is personalized based on behavioral signals.

**Time Reallocation:**
Teams report 40% more time spent in discovery calls and demos.

**Why better:**
- Each paragraph develops one idea
- Clear relationships between ideas
- Easy to scan and find specific information
- Logical flow: capability → alternative → results → outcome

---

## Summary: The Paragraph Structure Rules

### Rule 1: One Idea Per Paragraph
Each paragraph should develop exactly one complete thought. If you introduce a new idea, start a new paragraph.

### Rule 2: Optimal Length Is 3-5 Sentences
Target 3-5 sentences per paragraph. Maximum 7-8 before cognitive overload occurs.

### Rule 3: Use BLUF Structure
State your main point first (topic sentence), then provide supporting details. Don't bury conclusions at the end.

### Rule 4: Chunk Complex Information
Break dense content into smaller, scannable units with headings and white space.

### Rule 5: Front-Load Key Information
Put important information at the beginning of documents, sections, paragraphs, and sentences.

### Rule 6: Create Visual Breaks
Ensure adequate white space every 75-100 words. Readers need visual breaks to process information.

### Rule 7: Test for Scannability
Can readers quickly scan your content and find what they need? If not, add headings and break up dense paragraphs.

---

## Quick Reference: Fixing Common Problems

**Problem:** Paragraph exceeds 8 sentences
**Solution:** Find natural break point, create two paragraphs

**Problem:** Multiple ideas in one paragraph
**Solution:** Separate each idea into its own paragraph with topic sentence

**Problem:** Main point comes at the end
**Solution:** Apply BLUF—move conclusion to the beginning

**Problem:** Dense wall of text
**Solution:** Add headings, break into chunks, increase white space

**Problem:** Readers can't scan content
**Solution:** Use BLUF for topic sentences, add subheadings every 2-3 paragraphs

**Remember:** Respect the reader's cognitive capacity. Short paragraphs with clear hierarchy are easier to scan, understand, and remember than dense blocks of text—no matter how well-written the prose.
