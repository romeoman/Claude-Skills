# Quick Reference: Words & Phrases to Watch

This is a comprehensive list of problematic words and phrases organized by category for quick reference during editing.

---

## Filler Words (Delete These)

### Intensifiers (Usually Add Nothing)
- really
- very
- quite
- extremely
- absolutely
- totally
- completely
- utterly
- truly
- definitely
- certainly
- literally (when not literal)
- actually
- basically
- essentially
- particularly
- especially
- incredibly
- remarkably

**Example:**
- ❌ "This is really very important"
- ✅ "This is critical"

---

## Hedging Words (Remove Unless Justified)

### Uncertainty Words
- probably
- possibly
- potentially
- perhaps
- maybe
- somewhat
- rather
- fairly
- pretty (as in "pretty good")
- kind of
- sort of
- might
- could
- may
- appears to
- seems to
- tends to

### Hedging Phrases
- "I think that..."
- "I believe..."
- "In my opinion..."
- "It seems..."
- "It appears..."
- "It could be argued that..."
- "One might say..."
- "To some extent..."
- "In some ways..."

**Example:**
- ❌ "This might potentially help you improve"
- ✅ "This improves performance by 40%"

---

## Corporate Jargon (Replace with Specific Language)

### Business Buzzwords
- synergy
- leverage (as a verb)
- paradigm shift
- game-changer
- disruptive
- innovative (without specifics)
- cutting-edge
- state-of-the-art
- best-in-class
- world-class
- industry-leading
- next-generation
- revolutionary
- groundbreaking
- transformative
- robust
- scalable
- seamless
- holistic
- strategic
- proactive
- actionable
- impactful
- meaningful
- value-add
- bandwidth (metaphorical)
- bandwidth (metaphorical)
- drill down
- circle back
- touch base
- take offline
- move the needle
- low-hanging fruit
- quick win
- win-win
- best practices
- core competencies
- key learnings
- thought leadership

### Vague Action Words (Need Specifics)
- optimize
- streamline
- enhance
- facilitate
- enable
- empower
- drive
- deliver
- unlock
- maximize
- leverage
- utilize

**Replace with specifics:**
- "optimize performance" → "reduce load time from 5s to 1s"
- "enhance user experience" → "increase retention by 40%"
- "streamline processes" → "cut approval time from 3 days to 4 hours"
- "drive results" → "increase revenue by $2M annually"

---

## Business Buzzword Clichés (Replace with Specifics)

### The Core Business Clichés
These appear in almost every business article. Replace them:

**Common terms:**
- "competitive edge" → "competitive advantage"
- "pain points" → "challenges" or specific problem
- "high-value" → "key" or specify value ($500K+ accounts)
- "capacity" (work capacity) → "capability"
- "best" → "ideal" or "optimal"
- "matters" → "is important" or specific reason
- "elevated" → "increased" or "higher"
- "similar" → "comparable"
- "full visibility" → "complete visibility"
- "precision" (in business) → "accuracy"
- "chosen" → "selected"
- "cohort" (non-statistical) → "group"
- "thresholds" → "limits" or "levels"
- "misconception" → "misunderstanding"
- "impossible" → "unfeasible" or "impractical"

### Marketing & Tech Jargon Clichés
- "24/7" → "constantly" or "continuously"
- "2x" → "double" or "twice"
- "200+" → "over 200" or "more than 200"
- "10K+" → "over 10,000"
- "5x" → "five times" or "400% increase"
- "game-changer" / "game-changing" → specific benefit
- "cutting-edge" / "bleeding-edge" → "new" or specific capability
- "seamless" / "seamlessly" → delete or "smooth" / specific integration
- "unified" → often delete or be specific
- "robust" → specific quality (reliable, comprehensive)
- "leverage" (as verb) → "use" or specific action
- "optimize" → specific improvement with metric
- "streamline" → specific time/cost reduction
- "enhance" → specific improvement with metric

### Time & Process Clichés
- "over time" → "with experience" or "gradually"
- "fast" (scale fast) → "quickly"
- "at the end of the day" → delete or "ultimately"
- "moving forward" / "going forward" → delete or "next"
- "in today's fast-paced world" → delete or specific context
- "in today's digital age" → delete

### Corporate Meeting Clichés
- "touch base" → "discuss" or "meet"
- "circle back" → "revisit" or "return to"
- "think outside the box" → "find creative solutions"
- "low-hanging fruit" → "easy opportunities" or "quick wins"
- "on the same page" → "aligned" or "agreed"
- "take it offline" → "discuss separately"
- "drill down" → "examine" or "analyze"
- "move the needle" → "make progress" or "improve metrics"
- "bring to the table" → "contribute" or "offer"
- "loop in" → "include" or "inform"
- "ping me" → "contact me" or "send me a message"

### AI-Specific Clichés (ChatGPT/GPT Era - 2023+)

*Research shows "delve" increased 400% after ChatGPT release. These are AI writing "tells."*

**The AI Top 10 Words (Avoid in Business Writing):**
1. **delve** → examine, explore, analyze, review, investigate
2. **comprehensive** → thorough, complete, detailed, or remove
3. **leverage** (as verb) → use, apply, employ, utilize
4. **robust** → strong, effective, reliable, dependable
5. **paramount** → essential, critical, vital, crucial
6. **meticulous** → careful, thorough, detailed, or remove
7. **pivotal** → critical, key, important, significant
8. **harness** → use, control, direct, employ
9. **landscape** (metaphor) → market, field, industry, domain, sector
10. **unlock the potential** → enable, allow, make possible, or specify benefit

**AI Intensifier Overuse (appears 2+ times/paragraph):**
- crucial → essential, important, necessary
- vital → essential, necessary, important
- pivotal → key, critical, important
- paramount → essential, critical, most important
- fundamental → basic, core, essential
- notably → significantly (or remove)
- testament to → proof of, evidence of

**AI Metaphor Clusters:**
- "in the realm of" → in, within
- "in the space of" → in the field of
- "in the landscape of" → in the market of
- "unlock the potential" → enable, allow
- "tap into" → access, use
- "harness the power" → use, employ

**AI Sentence Patterns (Red Flags):**
- "It's important to note that..." → DELETE
- "In today's fast-paced world..." → DELETE or specify
- "In the realm of..." → in, within
- "A deeper understanding of..." → understanding, knowledge of
- "Testament to..." → proof of, shows
- "Additionally..." (overused) → vary transitions
- Three-item lists in every sentence (X, Y, and Z)
- Excessive em dashes—like this—in every paragraph

**AI Transformation Verbs:**
- "elevate your" → improve, enhance + metric
- "transform the way you" → change how you + specific
- "reimagine" → redesign, rethink, rebuild
- "revolutionize" → change significantly + proof
- "propel" → help, drive, push
- "empower" → enable, allow, help
- "enable" (overused) → allow, let, help
- "facilitate" → help, enable, support
- "maximize" → increase, optimize + specific metric
- "optimize" → improve + specific metric

**AI Academic Pretension:**
- "delve into" → examine, explore
- "comprehensive analysis" → thorough analysis
- "robust framework" → effective framework
- "meticulous attention" → careful attention
- "paramount importance" → critical, essential
- "pivotal moment" → critical moment
- "fundamental aspect" → basic element

**AI Filler Phrases:**
- "It's worth noting that" → DELETE
- "It should be emphasized that" → DELETE
- "In the context of" → in, for
- "With regard to" → about, regarding
- "For the purpose of" → to, for
- "In an effort to" → to

### Emphatic Clichés to Remove
- "NOT" (ALL CAPS) → restructure or use "optional" / "is not"
- "Example:" as introduction → delete, integrate naturally
- "(Not Sequential Steps)" → delete parenthetical, clarify in main text
- "It's no secret that" → delete, state the fact
- "To be honest" / "To tell the truth" → delete (implies you're usually dishonest)

### Copywriting & Marketing Clichés (SaaS/B2B)

*Research shows marketing jargon decreases trust by 17% and lowers deal closure rates by 23%.*

**Transformation Verbs (Vague Benefits):**
- elevate → improve, enhance + metric
- streamline → simplify, speed up + metric
- propel → help, drive + specific outcome
- accelerate → increase, speed up + metric
- skyrocket → double, triple, increase X%
- transform → change, improve + specific
- revolutionize → change significantly + proof
- disrupt → challenge, change + how
- optimize → improve + specific metric
- maximize → increase + specific metric
- enhance → improve + specific metric

**Empty Superlatives (Prove or Remove):**
- world-class → cite rankings or remove
- industry-leading → #1 in [metric] or remove
- best-in-class → highest-rated or remove
- cutting-edge → 2024 release, new technology
- next-level → specific improvement
- game-changer → specific impact + proof
- revolutionary → significant change + proof
- groundbreaking → first to market or remove
- innovative → what's new specifically
- state-of-the-art → newest version or remove
- bleeding-edge → latest technology
- next-generation → version 2.0 or newer

**Vague Marketing Promises:**
- "drive results" → "increase revenue by $X"
- "boost performance" → "reduce load time by X%"
- "improve efficiency" → "save X hours weekly"
- "increase productivity" → "complete X% more work"
- "deliver value" → specific benefit
- "generate ROI" → "achieve X% return"
- "create impact" → specific outcome

**Marketing Shorthand (Write Out):**
- 24/7 → constantly, continuously, always available
- 2x → double, twice, two times
- 3x → triple, three times
- 5x → five times, 400% increase
- 10x → ten times, 900% increase
- 100+ → over 100, more than 100
- 200+ → over 200, more than 200
- 10K+ → over 10,000, more than 10,000
- 1M+ → over 1 million

**Startup/VC Clichés:**
- "scale fast" → grow quickly, expand rapidly
- "move fast and break things" → rapid development
- "disrupt the industry" → change the market
- "10x thinking" → ambitious goals
- "moonshot" → ambitious project
- "unicorn" → billion-dollar company
- "pivot" → change strategy (use sparingly)
- "growth hacking" → growth strategies

**Vague Tech Marketing:**
- seamless integration → specific integrations listed
- unified platform → single platform
- end-to-end solution → complete system
- turnkey solution → ready-to-use
- fully integrated → connects with [specific tools]
- plug-and-play → quick setup
- enterprise-grade → specific security/reliability features

### Sales Jargon & Culture Clichés

*Sales-specific language that undermines professionalism.*

**Sales Team Language:**
- hungry → motivated, driven, results-focused
- rockstar → professional, expert, top performer
- ninja → specialist, expert (just stop)
- guru → expert, specialist
- wizard → expert, specialist
- crush quota → exceed targets, surpass goals
- smash targets → achieve goals, meet objectives
- always be closing (ABC) → relationship-building
- boomerang email → follow-up email
- A players → top performers, high achievers

**Aggressive Sales Terms:**
- "crush it" → achieve goals, succeed
- "kill it" → perform well, excel
- "dominate" → lead, excel in
- "destroy the competition" → outperform competitors
- "blow past quotas" → exceed targets
- "annihilate objections" → address concerns

**Corporate Culture Red Flags:**
- "we're a family" → collaborative environment, supportive team
- "rockstar culture" → high-performance environment
- "work hard, play hard" → balanced team culture
- "wear many hats" → diverse responsibilities
- "fast-paced environment" → dynamic workplace
- "self-starter" → independent worker

**Sales Meeting Clichés:**
- "touch base" → meet, discuss, talk
- "circle back" → revisit, return to, follow up
- "offline" (take offline) → separately, outside meeting
- "loop in" → include, inform, add
- "ping me" → contact me, message me
- "boomerang this" → send back, return
- "tee this up" → prepare, set up
- "table this" → postpone, delay
- "park that idea" → save for later
- "put a pin in it" → revisit later

**Service Industry Clichés:**
- white glove treatment → personalized service, dedicated support
- concierge service → personalized assistance
- VIP treatment → premium service
- red carpet treatment → special attention

### Cliché Red Flags (Quick Scan)
When you see these, STOP and replace:
- **"delve"** → Always use: examine, explore, analyze
- **"comprehensive"** → Remove or use: thorough, complete
- **"leverage"** → Always use: use, apply, employ
- **"robust"** → Use: strong, effective, reliable
- **"pain points"** → Always replace with "challenges" or specific problem
- **"game-changer" / "game-changing"** → Always replace with specific benefit
- **"24/7"** → Always write as "constantly" or "continuously"
- **"2x" / "10x" / "5x"** → Always write out: "double," "ten times," "five times"
- **"best"** → Usually replace with "ideal" or "optimal"
- **"at the end of the day"** → Always delete
- **"moving forward"** → Usually delete
- **"seamless" / "seamlessly"** → Usually delete or be specific
- **"revolutionize" / "disrupt"** → Specify the change or remove
- **"elevate" / "streamline" / "optimize"** → Add specific metrics

**Example:**
- ❌ "Let's leverage our synergies to drive game-changing solutions that delve into pain points. At the end of the day, we need to think outside the box to get 2x results 24/7."
- ✅ "Let's combine our resources to create solutions that solve data fragmentation challenges. We need creative approaches to double results continuously."

### AI Detection Quick Test

**Count these words in your writing:**
delve, comprehensive, crucial, robust, paramount, landscape, harness, unlock

**Scoring:**
- **0-1:** Likely human-written
- **2-3:** Possibly AI-assisted or heavily influenced
- **4+:** Likely AI-generated (needs human editing)

**Other AI Tells:**
- Every sentence has "X, Y, and Z" structure
- Overuse of em dashes—like this—throughout
- Phrases: "It's important to note," "In today's fast-paced world"
- Multiple intensifiers per paragraph: crucial, vital, paramount, pivotal

---

## Wordy Phrases (Shorten These)

### Replace Long Phrases (The Core 25)
These appear in 80% of wordy writing. Memorize these:

- "in order to" → "to" (always)
- "due to the fact that" → "because" (always)
- "despite the fact that" → "although"
- "in spite of the fact that" → "although"
- "at this point in time" → "now"
- "at the present time" → "now"
- "in the near future" → "soon"
- "in the event that" → "if"
- "for the purpose of" → "to"
- "with regard to" → "about"
- "in regard to" → "about"
- "with respect to" → "about"
- "in terms of" → "for" or "in"
- "has the ability to" → "can"
- "is able to" → "can"
- "is capable of" → "can"
- "in the process of" → [delete]
- "during the course of" → "during"
- "until such time as" → "until"
- "on a regular basis" → "regularly"
- "on an annual basis" → "annually"
- "on the part of" → "by"
- "for the most part" → "mostly"
- "in the majority of cases" → "usually"
- "a number of" → "several" or specific number
- "a majority of" → "most"

### Delete These Throat-Clearing Phrases (Always)
- "it is important to note that" → [delete]
- "it should be noted that" → [delete]
- "it is worth noting that" → [delete]
- "the fact of the matter is" → [delete]
- "what I mean to say is" → [delete]
- "allow me to explain" → [delete]
- "let me start by saying" → [delete]

### Brevity Red Flags (Quick Scan)
When you see these, STOP and edit:
- **"in order to"** → Always "to"
- **"the fact that"** → Usually removable
- **"it is/was [adjective] that"** → Often removable
- **"there is/are"** → Often rewriteable
- **"which is/was"** → Often removable
- **"that is/was"** → Often removable
- **"in the process of"** → Always removable
- **"is able to/has the ability to"** → Always "can"

### Weak Verb Phrases
- "give consideration to" → "consider"
- "make a decision" → "decide"
- "make a determination" → "determine"
- "reach a conclusion" → "conclude"
- "conduct an analysis" → "analyze"
- "perform an assessment" → "assess"
- "provide assistance" → "assist" or "help"
- "make improvements" → "improve"
- "take action" → "act"
- "take into consideration" → "consider"
- "come to an agreement" → "agree"
- "is in agreement with" → "agrees with"
- "arrive at a decision" → "decide"
- "make a recommendation" → "recommend"

**Example:**
- ❌ "In order to give consideration to the fact that we need to make a decision"
- ✅ "To consider this decision"

---

## Redundant Phrases (Delete Modifier)

- "absolutely essential" → "essential"
- "actual fact" → "fact"
- "added bonus" → "bonus"
- "advance planning" → "planning"
- "ask the question" → "ask"
- "basic fundamentals" → "fundamentals"
- "close proximity" → "proximity"
- "completely eliminate" → "eliminate"
- "consensus of opinion" → "consensus"
- "each and every" → "each" or "every"
- "end result" → "result"
- "exact same" → "same"
- "false pretense" → "pretense"
- "final outcome" → "outcome"
- "first and foremost" → "first" or delete
- "free gift" → "gift"
- "future plans" → "plans"
- "general consensus" → "consensus"
- "join together" → "join"
- "mutual cooperation" → "cooperation"
- "new innovation" → "innovation"
- "past history" → "history"
- "personal opinion" → "opinion"
- "plan ahead" → "plan"
- "repeat again" → "repeat"
- "return back" → "return"
- "revert back" → "revert"
- "specific example" → "example"
- "sudden crisis" → "crisis"
- "surrounding circumstances" → "circumstances"
- "true fact" → "fact"
- "unexpected surprise" → "surprise"
- "uniformly consistent" → "consistent"
- "usual custom" → "custom"
- "whether or not" → "whether"

---

## Passive Voice Indicators (Convert to Active)

### Common Passive Constructions
- "is done by"
- "was completed by"
- "are managed by"
- "were created by"
- "has been approved by"
- "will be handled by"
- "can be seen"
- "is considered"
- "is believed"
- "is thought to be"
- "is assumed"
- "are required"
- "was determined"
- "were identified"
- "has been shown"

### "By Zombies" Test
If you can add "by zombies" after the verb, it's passive:
- ❌ "The report was written [by zombies]" → PASSIVE
- ✅ "She wrote the report [by zombies]" → ACTIVE (doesn't make sense)

**Examples:**
- ❌ "The strategy was developed by our team"
- ✅ "Our team developed the strategy"

- ❌ "Results are achieved through implementation"
- ✅ "Implementation achieves results"

---

## Throat-Clearing Phrases (Delete These)

### Unnecessary Preambles
- "First of all,"
- "To begin with,"
- "Allow me to explain..."
- "Let me start by saying..."
- "I would like to point out that..."
- "I think it's important to mention that..."
- "It should be noted that..."
- "It's worth mentioning that..."
- "What I'm trying to say is..."
- "The point I'm trying to make is..."
- "If you ask me,"
- "In my humble opinion,"
- "For what it's worth,"
- "To be honest,"
- "To tell you the truth,"
- "If I'm being completely honest,"

**Example:**
- ❌ "First of all, I would like to point out that it's worth mentioning that this strategy works"
- ✅ "This strategy works"

---

## Repetitive Transitions (Vary These)

### Overused Transitions
If you use the same transition more than twice in a document, vary it:

**Addition:**
- Additionally
- Furthermore
- Moreover
- Also
- In addition
- What's more
- Besides
- As well as

**Variety:** "First... Next... Then... Finally..."

**Contrast:**
- However
- Nevertheless
- Nonetheless
- On the other hand
- Conversely
- In contrast
- Yet
- Still

**Variety:** Use different ones throughout

**Result:**
- Therefore
- Thus
- Consequently
- As a result
- Hence
- Accordingly

**Variety:** Mix with simple sentence structure instead

---

## Common Grammar Issues

### Incorrect Word Usage
- "could of" → "could have"
- "should of" → "should have"
- "would of" → "would have"
- "alot" → "a lot"
- "alright" → "all right"
- "irregardless" → "regardless"

### Commonly Confused Words
- affect (verb) vs effect (noun, usually)
- than (comparison) vs then (time)
- their (possessive) vs there (location) vs they're (they are)
- your (possessive) vs you're (you are)
- its (possessive) vs it's (it is)
- whose (possessive) vs who's (who is)
- lose (verb) vs loose (adjective)
- accept (verb) vs except (preposition)
- advice (noun) vs advise (verb)
- compliment (praise) vs complement (complete)
- principal (main) vs principle (rule)
- stationary (not moving) vs stationery (paper)

---

## Numbers and Statistics Guidelines

### Always Include
- Baseline: "from X to Y"
- Timeframe: "in 30 days", "within 8 weeks"
- Source: ([_Source Name_](URL))

### Avoid Vague Quantifiers
Replace with specific numbers:
- "many" → "47"
- "several" → "5"
- "a lot of" → "2,000+"
- "numerous" → "23"
- "a few" → "3"
- "most" → "78%"
- "some" → "31%"

**Example:**
- ❌ "Many teams see significant improvements"
- ✅ "78% of teams report 40% faster processing ([_Study Name_](URL))"

---

## Industry-Specific Terms

### SaaS/Tech
Keep: API, CRM, SaaS, UI/UX, ROI
Explain: Middleware, webhook, microservices

### Marketing
Keep: SEO, CTR, CPC, CAC, LTV
Explain: MQL, SQL, attribution modeling

### Finance
Keep: ROI, EBITDA, P&L
Explain: WACC, DCF, basis points

**Rule:** First mention = explain or link to definition

---

## Style Consistency Checks

### Formatting
- **Dashes:** En dash (–) for ranges: 3–5 hours
- **Quotes:** Curly quotes: "don't" not "don't"
- **Apostrophes:** Curly: it's not it's
- **Contractions:** Consistent throughout
- **Numbers:** Spell out one through nine, use digits for 10+
- **Percentages:** Always use % symbol: 40% not forty percent
- **Time:** 2pm or 2 p.m. (be consistent)

### Capitalization
- "HubSpot" not "Hubspot"
- "RevOps" not "Rev Ops" or "revops"
- "X" not "Twitter" (current name)
- "iPhone" not "Iphone"
- "eCommerce" or "e-commerce" (pick one)

---

## Quick Scan Checklist

When editing quickly, scan for these red flags:

**Word-level:**
- [ ] "really", "very", "quite" → DELETE
- [ ] "in order to" → CHANGE TO "to"
- [ ] "at this point in time" → CHANGE TO "now"
- [ ] "leverage", "synergy", "paradigm" → REPLACE
- [ ] "probably", "maybe", "might" → REMOVE or JUSTIFY

**Sentence-level:**
- [ ] Sentences over 25 words → BREAK UP
- [ ] "was done by" → FLIP TO ACTIVE
- [ ] "It is important to note that" → DELETE
- [ ] Same word used 3x in paragraph → VARY

**Paragraph-level:**
- [ ] Paragraphs over 5 sentences → SPLIT
- [ ] Same transition used 3+ times → VARY
- [ ] No concrete numbers → ADD METRICS
- [ ] Generic adjectives → ADD SPECIFICS

---

## Emergency Speed-Edit List

When you only have 2 minutes, fix these first:

1. **Spelling and grammar errors** (credibility killers)
2. **Really, very, quite** (delete all)
3. **Passive voice** (flip to active)
4. **Long sentences** (break up 25+ words)
5. **Clichés** (leverage, synergy, game-changer)
6. **Vague claims** (add specific numbers)
7. **Weak verbs** (strengthen or delete)
8. **Repeated words** (within 2 sentences)

---

## Context-Dependent Decisions

### When to Keep "Weak" Words

**Keep hedging when:**
- Making predictions: "This may work for smaller teams"
- Citing uncertain research: "Some studies suggest"
- Acknowledging limitations: "This approach might not work for all industries"

**Keep jargon when:**
- Writing for expert audience who expects it
- Using industry-standard terminology
- Explaining would take more words than it's worth

**Keep passive voice when:**
- Actor is unknown: "The building was vandalized"
- Focus is on action, not actor: "The policy was updated"
- Scientific writing standards: "The sample was heated"

**Trust your judgment on these edge cases.**

---

## Final Quality Indicators

**Good editing shows:**
- ✅ Every word earns its place
- ✅ Specific numbers replace vague claims
- ✅ Active voice dominates (90%+)
- ✅ Sentences average 15-20 words
- ✅ No business jargon without specifics
- ✅ Natural, conversational flow
- ✅ Clear, scannable structure

**Over-editing shows:**
- ❌ Sounds robotic or stiff
- ❌ Lost the writer's voice
- ❌ Too formal for context
- ❌ Overly simplified (loses nuance)
- ❌ Changed the meaning
- ❌ All personality stripped out

---

This quick reference is meant to be scanned, not read linearly. Use Ctrl+F to find specific words or phrases during editing sessions.
